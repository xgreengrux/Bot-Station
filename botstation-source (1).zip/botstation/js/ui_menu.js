/* Bot Station - menu screens: title, party lobby, chat widget. */
(function (g) {
'use strict';
const BS = g.BS, UI = BS.UI = {};
const $ = UI.$ = id => document.getElementById(id);
const el = BS.el = (tag, cls, txt, parent) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; if (parent) parent.appendChild(e); return e; };
const col = i => BS.COLORS[i % BS.COLORS.length][1];
UI.col = col;
const store = { get: k => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } } };
UI.store = store;

UI.screen = id => { for (const s of ['title', 'lobby', 'browser']) $(s).classList.toggle('hidden', s !== id); };
UI.toast = (txt, ms) => { const t = $('toast'); t.textContent = txt; t.classList.add('show'); clearTimeout(UI._tt); UI._tt = setTimeout(() => t.classList.remove('show'), ms || 2600); };

/* --------------------------------------------------------------- chat box */
// A scrolling log plus an input. `log` is an array the caller owns; call .push(msg) to append.
UI.chatBox = (parent, onSend, opts) => {
  opts = opts || {};
  const box = el('div', 'chatbox' + (opts.cls ? ' ' + opts.cls : ''), null, parent), logEl = el('div', 'chatlog', null, box);
  const form = el('form', 'chatform', null, box), inp = el('input', null, null, form);
  inp.maxLength = 140; inp.placeholder = opts.placeholder || 'Type a message…'; inp.autocomplete = 'off';
  const btn = el('button', 'btn', 'Send', form); btn.type = 'submit';
  form.onsubmit = e => { e.preventDefault(); const t = inp.value.trim(); if (t) onSend(t); inp.value = ''; if (opts.blurOnSend) inp.blur(); };
  inp.addEventListener('keydown', e => { if (e.key === 'Escape') inp.blur(); });
  const api = {
    box, input: inp,
    add(name, color, text, ghost) {
      const row = el('div', 'chatmsg' + (ghost ? ' ghost' : ''), null, logEl);
      if (name) { const n = el('b', null, name + ': ', row); n.style.color = color || '#fff'; }
      el('span', null, text, row);
      while (logEl.childNodes.length > 80) logEl.removeChild(logEl.firstChild);
      logEl.scrollTop = logEl.scrollHeight;
    },
    clear() { logEl.innerHTML = ''; }
  };
  return api;
};

/* ------------------------------------------------------------------ title */
UI.buildTitle = app => {
  const t = $('title'); t.innerHTML = '';
  const card = el('div', 'card title-card', null, t);
  el('div', 'logo', 'BOT STATION', card);
  el('p', 'tag', 'A social-deduction party game for 4–10 players. One of the bots is a saboteur.', card);
  const name = el('input', 'inp', null, card); name.id = 'tName'; name.placeholder = 'Your name'; name.maxLength = 12; name.value = store.get('bs-name');
  const create = el('button', 'btn big primary', 'Create party', card); create.id = 'tCreate';
  const priv = el('label', 'privrow', null, card), pcb = el('input', null, null, priv); pcb.type = 'checkbox'; pcb.id = 'tPrivate'; pcb.checked = store.get('bs-private') === '1';
  el('span', null, 'Private party (hide it from Browse parties)', priv);
  pcb.onchange = () => store.set('bs-private', pcb.checked ? '1' : '');
  el('div', 'or', 'or join a friend', card);
  const row = el('div', 'joinrow', null, card), code = el('input', 'inp code', null, row); code.id = 'tCode'; code.placeholder = 'CODE'; code.maxLength = 5; code.autocapitalize = 'characters';
  const join = el('button', 'btn big', 'Join', row); join.id = 'tJoin';
  const browse = el('button', 'btn big wide', '🔍 Browse public parties', card); browse.id = 'tBrowse';
  browse.onclick = () => { const n = name.value.trim(); if (n) store.set('bs-name', n); app.openBrowser(); };
  const msg = el('div', 'msg', '', card); msg.id = 'tMsg';
  const how = el('details', 'how', null, card); el('summary', null, 'How to play', how);
  el('p', null, 'Technicians finish tasks around the station. The saboteur sneaks around eliminating them, sabotaging systems and hiding in the vents. Found a body or suspect someone? Call a meeting, discuss, and vote.', how);
  el('p', null, 'Technicians win by finishing every task or ejecting all saboteurs. The saboteur wins by matching the technicians in number or letting a sabotage run out the clock.', how);
  el('p', null, 'Move: WASD / arrows (or drag). Use: E / Space. Report: R. Eliminate: Q. Vent: V. Sabotage: X. Map: M / Tab.', how);
  const go = fn => () => { const n = name.value.trim(); if (!n) { name.focus(); return UI.status('Pick a name first.', true); } store.set('bs-name', n); fn(n); };
  create.onclick = go(n => app.create(n, { public: !pcb.checked }));
  join.onclick = go(n => app.join(code.value, n));
  code.oninput = () => { code.value = BS.Net.parseCode(code.value); };
  [name, code].forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') (code.value ? join : create).click(); }));
  const hashCode = BS.Net.parseCode((location.hash || '').slice(1));
  if (hashCode.length === 5) { code.value = hashCode; UI.status('You were invited to party ' + hashCode + '. Enter a name and press Join.'); join.classList.add('primary'); create.classList.remove('primary'); }
};
UI.status = (m, err) => { const e = $('tMsg'); if (!e) return; e.textContent = m || ''; e.className = 'msg' + (err ? ' err' : ''); };
UI.busy = b => ['tCreate', 'tJoin', 'tName', 'tCode', 'tBrowse', 'tPrivate'].forEach(i => { if ($(i)) $(i).disabled = b; });

/* ------------------------------------------------------------------ lobby */
UI.buildLobby = app => {
  const L = $('lobby'); L.innerHTML = '';
  const top = el('div', 'lb-top', null, L);
  const left = el('div', null, null, top);
  el('div', 'lb-label', 'PARTY CODE', left);
  const code = el('button', 'lb-code', '-----', left); code.id = 'lbCode'; code.title = 'Click to copy the invite link';
  code.onclick = () => app.copyInvite();
  const vis = el('button', 'vis', '', left); vis.id = 'lbVis';
  vis.onclick = () => app.send({ k: 'visibility', value: !(app.S.lobby && app.S.lobby.pub) });
  const right = el('div', 'lb-actions', null, top);
  const inv = el('button', 'btn', 'Copy invite link', right); inv.onclick = () => app.copyInvite();
  const leave = el('button', 'btn danger', 'Leave party', right); leave.onclick = () => app.leave();

  const main = el('div', 'lb-main', null, L);
  const pc = el('section', 'panel-s', null, main); el('h3', null, 'Players', pc); el('div', 'players', null, pc).id = 'lbPlayers';
  const you = el('section', 'panel-s', null, main); el('h3', null, 'Your bot', you);
  const nm = el('input', 'inp', null, you); nm.id = 'lbName'; nm.maxLength = 12; nm.placeholder = 'Name';
  let nt; nm.oninput = () => { clearTimeout(nt); nt = setTimeout(() => { if (nm.value.trim()) app.send({ k: 'look', name: nm.value }); }, 350); };
  el('div', 'lb-label', 'COLOUR', you); el('div', 'swatches', null, you).id = 'lbColors';
  el('div', 'lb-label', 'HAT', you); el('div', 'hats', null, you).id = 'lbHats';
  const st = el('section', 'panel-s', null, main); el('h3', null, 'Game settings', st); el('div', 'settings', null, st).id = 'lbSettings';
  const ch = el('section', 'panel-s chatpanel', null, main); el('h3', null, 'Party chat', ch);
  UI.lobbyChat = UI.chatBox(ch, t => app.send({ k: 'chat', text: t }), { placeholder: 'Say something to your party…' });

  const foot = el('div', 'lb-foot', null, L);
  const start = el('button', 'btn big primary', 'START GAME', foot); start.id = 'lbStart';
  start.onclick = () => app.send({ k: app.S.lobby && app.S.lobby.phase === 'countdown' ? 'cancel' : 'start' });
  el('div', 'lb-note', '', foot).id = 'lbNote';
  el('div', 'countdown hidden', '', L).id = 'lbCd';
};

UI.updateLobby = app => {
  const S = app.S, L = S.lobby; if (!L) return;
  const leader = S.id === L.leader, me = L.players.find(p => p.id === S.id) || {};
  $('lbCode').textContent = L.code;
  const vis = $('lbVis'), listed = !!L.pub, canVis = leader && (L.phase === 'lobby' || L.phase === 'countdown');
  vis.textContent = listed ? '🌐 Public party' : '🔒 Private party'; vis.className = 'vis ' + (listed ? 'on' : 'off') + (canVis ? ' can' : ''); vis.disabled = !canVis;
  vis.title = listed ? (leader ? 'Listed in Browse parties with your players’ names. Click to make it private.' : 'This party is listed in Browse parties.')
    : (leader ? 'Hidden from Browse parties (friends need the code or link). Click to list it.' : 'This party is private: only people with the code can join.');
  const grid = $('lbPlayers'); grid.innerHTML = '';
  for (let i = 0; i < L.max; i++) {
    const p = L.players[i], c = el('div', 'pcard' + (p ? '' : ' empty') + (p && !p.conn ? ' off' : ''), null, grid);
    if (!p) { el('span', null, 'waiting…', c); continue; }
    c.appendChild(BS.R.icon(col(p.color), p.hat, 54));
    const nm = el('div', 'pn', p.name, c); if (p.id === S.id) el('small', null, ' (you)', nm);
    if (p.id === L.leader) el('span', 'crown', '👑', c);
    if (leader && p.id !== S.id) { const k = el('button', 'kick', '✕', c); k.title = 'Kick ' + p.name; k.onclick = () => app.send({ k: 'kick', id: p.id }); }
  }
  const sw = $('lbColors'); sw.innerHTML = '';
  BS.COLORS.forEach((cc, i) => { const taken = L.players.some(p => p.color === i && p.id !== S.id), b = el('button', 'sw' + (me.color === i ? ' sel' : '') + (taken ? ' taken' : ''), '', sw);
    b.style.background = cc[1]; b.title = cc[0]; b.disabled = taken; b.onclick = () => app.send({ k: 'look', color: i }); });
  const hs = $('lbHats'); hs.innerHTML = '';
  BS.HATS.forEach((n, i) => { const b = el('button', 'hatb' + (me.hat === i ? ' sel' : ''), n, hs); b.onclick = () => app.send({ k: 'look', hat: i }); });
  const nm = $('lbName'); if (document.activeElement !== nm && me.name) nm.value = me.name;

  const box = $('lbSettings'); box.innerHTML = '';
  const editable = leader && L.phase === 'lobby';
  BS.SETTINGS.forEach(d => {
    const v = L.settings[d.k], row = el('div', 'srow', null, box); el('span', null, d.label, row);
    const ctl = el('div', 'sctl', null, row);
    const send = nv => app.send({ k: 'settings', key: d.k, value: nv });
    if (d.type === 'num') {
      const dec = el('button', 'mini', '−', ctl), val = el('b', null, v + (d.unit || ''), ctl), inc = el('button', 'mini', '+', ctl);
      dec.disabled = inc.disabled = !editable; dec.onclick = () => send(v - d.step); inc.onclick = () => send(v + d.step);
    } else if (d.type === 'bool') { const b = el('button', 'mini tog' + (v ? ' on' : ''), v ? 'On' : 'Off', ctl); b.disabled = !editable; b.onclick = () => send(!v); }
    else { const idx = d.opts.findIndex(o => o[0] === v), b = el('button', 'mini wide', d.opts[idx][1], ctl); b.disabled = !editable; b.onclick = () => send(d.opts[(idx + 1) % d.opts.length][0]); }
  });

  const n = L.players.filter(p => p.conn).length, st = $('lbStart'), note = $('lbNote'), cd = $('lbCd');
  if (L.phase === 'countdown') {
    cd.classList.remove('hidden'); cd.textContent = Math.max(1, Math.ceil(L.cd));
    st.textContent = 'CANCEL'; st.disabled = !leader; note.textContent = 'Starting…';
  } else {
    cd.classList.add('hidden');
    st.textContent = 'START GAME'; st.disabled = !leader || n < L.min;
    note.textContent = leader ? (n < L.min ? 'Need at least ' + L.min + ' players (' + n + ' so far). Share the code!' : 'Everyone ready? Press start.') : 'Waiting for the party leader to start…';
  }
};
})(window);
