/* Bot Station - client core: party flows, connection handling, server messages -> local state. */
(function (g) {
'use strict';
const BS = g.BS, C = BS.C, UI = BS.UI, Net = BS.Net, $ = UI.$, col = UI.col;
const App = BS.App = {};
const S = App.S = {
  screen: 'title', link: null, host: null, hostHandle: null, stopTick: null, leaving: false, reconnecting: false, lastRx: 0,
  token: '', name: '', id: 0, code: '', leader: 0, lobby: null, color: Math.floor(Math.random() * 12), hat: 0,
  inGame: false, phase: '', role: 'crew', alive: true, mates: [], tasks: [], tasksVisible: true, set: BS.defaultSettings(),
  pub: null, watch: null, browse: { list: [], st: { state: 'connecting', up: 0, total: 0, ready: false } }, joinFrom: '',
  players: new Map(), x: 0, y: 0, face: 1, moving: false, vent: -1, others: new Map(), bodies: [], fx: [],
  sab: null, doors: new Set(), kcd: 0, scd: 0, dcd: 0, ecd: 0, tp: 0, emerg: 1, panel: null, overlay: null, admin: null, ptr: null
};
try { S.token = sessionStorage.getItem('bs-token') || ''; } catch (e) { /* ignore */ }
if (!S.token) { S.token = Math.random().toString(36).slice(2) + Date.now().toString(36); try { sessionStorage.setItem('bs-token', S.token); } catch (e) { /* ignore */ } }

const nameOf = id => (S.players.get(id) || {}).name || 'Someone';
const show = (id, on) => $(id).classList.toggle('hidden', !on);
App.send = m => { if (S.link) { try { S.link.send(m); } catch (e) { /* link closed */ } } };
const sendJoin = () => App.send({ k: 'join', name: S.name, color: S.color, hat: S.hat, token: S.token });

/* ------------------------------------------------------------ party flows */
function attach(link) {
  S.link = link; S.lastRx = performance.now();
  link.onMessage = m => { S.lastRx = performance.now(); onMsg(m); };
  link.onClose = () => { if (S.link === link) onLinkClose(); };
}

App.create = (name, opts) => {
  opts = opts || {};
  S.name = name; UI.busy(true); UI.status('Creating your party…');
  S.hostHandle = Net.hostParty({
    onOpen: code => {
      if (S.host) return;
      S.code = code;
      const host = S.host = new BS.Host({ code, public: opts.public !== false });
      const pair = Net.loopback(); host.addLink(pair[0]);
      S.pub = BS.Registry.publish(code, () => host.publicInfo());     // lists the party in the browser while it is public
      let last = performance.now();
      S.stopTick = Net.ticker(() => { const n = performance.now(); host.tick(Math.min(0.1, (n - last) / 1000)); last = n; if (S.pub) S.pub.tick(); }, 33);
      attach(pair[1]); sendJoin();
    },
    onLink: link => { if (S.host) S.host.addLink(link); },
    onError: msg => App.toTitle(msg)
  });
};

App.join = (code, name, ui) => {
  ui = ui || { busy: UI.busy, status: UI.status };            // where progress and errors are shown (title screen or party browser)
  S.name = name; ui.busy(true); ui.status('Connecting…');
  Net.joinParty(code, { onOpen: link => { attach(link); sendJoin(); }, onError: msg => { ui.busy(false); ui.status(msg, true); } });
};

/* ----------------------------------------------------------- party browser */
App.openBrowser = msg => {
  App.closeBrowser();
  S.screen = 'browser'; S.browse = { list: [], st: { state: 'connecting', up: 0, total: 0, ready: false } };
  UI.screen('browser'); UI.openBrowser(App, msg);
  S.watch = BS.Registry.watch({ onChange: (list, st) => { S.browse = { list, st }; UI.updateBrowser(App); } });
};
App.closeBrowser = () => { if (S.watch) { try { S.watch.close(); } catch (e) { /* ignore */ } S.watch = null; } };
App.retryBrowser = () => { if (S.watch) S.watch.retry(); };
App.leaveBrowser = () => { App.closeBrowser(); S.screen = 'title'; UI.screen('title'); };
App.joinFromBrowser = (code, name) => { S.joinFrom = 'browser'; App.join(code, name, { busy: UI.browserBusy, status: UI.browserStatus }); };
g.addEventListener('pagehide', () => { if (S.pub) { S.pub.close(); S.pub = null; } App.closeBrowser(); });

App.tryResume = () => {
  let code = '';
  try { code = sessionStorage.getItem('bs-party') || ''; } catch (e) { /* ignore */ }
  const name = UI.store.get('bs-name');
  if (!code || !name) return;
  S.name = name; UI.busy(true); UI.status('Reconnecting to party ' + code + '…');
  Net.joinParty(code, {
    onOpen: link => { attach(link); sendJoin(); },
    onError: () => { try { sessionStorage.removeItem('bs-party'); } catch (e) { /* ignore */ } UI.busy(false); UI.status(''); }
  });
};

App.leave = () => {
  S.leaving = true;
  if (S.host) S.host.closeParty('The party leader left, so the party was closed.'); else App.send({ k: 'leave' });
  setTimeout(() => App.toTitle(''), 80);
};

App.copyInvite = () => {
  const url = location.origin + location.pathname + location.search + '#' + S.code;
  const done = () => UI.toast('Invite link copied! Friends can paste it, or just enter code ' + S.code + '.', 3500);
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, () => g.prompt('Copy this invite link:', url));
  else g.prompt('Copy this invite link:', url);
};

function onLinkClose() {
  if (S.leaving || S.screen === 'title' || S.host) return;
  try { if (S.link) S.link.close(); } catch (e) { /* ignore */ }
  S.link = null;
  if (S.reconnecting) return;
  S.reconnecting = true; show('conn', true);
  const t0 = performance.now();
  const attempt = () => {
    if (!S.reconnecting) return;
    if (performance.now() - t0 > 30000) return App.toTitle('Lost connection to the party.');
    Net.joinParty(S.code, { onOpen: link => { S.reconnecting = false; show('conn', false); attach(link); sendJoin(); }, onError: () => setTimeout(attempt, 1500) });
  };
  attempt();
}
setInterval(() => {
  if (!S.link || S.host || S.screen === 'title') return;
  App.send({ k: 'ping', t: Date.now() });
  if (performance.now() - S.lastRx > 9000) onLinkClose();
}, 2000);

App.toTitle = (msg, dest) => {
  S.reconnecting = false; S.leaving = false; S.joinFrom = '';
  if (S.pub) { S.pub.close(); S.pub = null; }                  // take the party off the public list
  App.closeBrowser();
  if (S.stopTick) S.stopTick(); S.stopTick = null;
  if (S.hostHandle) { try { S.hostHandle.close(); } catch (e) { /* ignore */ } } S.hostHandle = null;
  try { if (S.link) S.link.close(); } catch (e) { /* ignore */ }
  S.link = null; S.host = null; S.inGame = false; S.lobby = null; S.screen = 'title'; S.code = '';
  try { sessionStorage.removeItem('bs-party'); } catch (e) { /* ignore */ }
  App.closeOverlays && App.closeOverlays();
  UI.hideMeeting(); UI.hideEject(); UI.hideOver(); UI.hideIntro();
  show('hud', false); show('conn', false);
  UI.busy(false); UI.status(dest === 'browser' ? '' : msg || '', dest !== 'browser' && !!msg);
  if (dest === 'browser') App.openBrowser(msg); else UI.screen('title');
  if (location.hash) history.replaceState(null, '', location.pathname + location.search);
};

/* ----------------------------------------------------------- messages in */
function onMsg(m) {
  switch (m.k) {
    case 'welcome':
      S.id = m.id; S.code = m.code; S.joinFrom = ''; App.closeBrowser();
      if (!S.host) { try { sessionStorage.setItem('bs-party', m.code); } catch (e) { /* ignore */ } }
      break;
    case 'reject': App.toTitle(m.why, S.joinFrom); break;      // a join from the party browser returns there, with the reason
    case 'kicked': App.toTitle('You were kicked from the party.'); break;
    case 'closed': App.toTitle(m.why || 'The party was closed.'); break;
    case 'toast': UI.toast(m.text); break;
    case 'deny': UI.toast(m.why); break;
    case 'lobby': onLobby(m); break;
    case 'chat': onChat(m); break;
    case 'begin': onBegin(m); break;
    case 'go': S.phase = 'play'; UI.hideIntro(); BS.Sfx.play('go'); break;
    case 's': onSnap(m); break;
    case 'fix': S.x = m.x; S.y = m.y; break;
    case 'vent': S.vent = m.v; S.x = m.x; S.y = m.y; BS.Sfx.play('vent'); App.renderVentBar && App.renderVentBar(); break;
    case 'died': S.alive = false; S.vent = -1; if (App.closeOverlays) App.closeOverlays(); UI.died(S, m.by); BS.Sfx.play('kill'); break;
    case 'task': { const tk = S.tasks.find(t => t.id === m.task); if (tk) tk.done[m.step] = true; UI.tasks(S); BS.Sfx.play('task'); break; }
    case 'tp': S.tp = m.v; UI.progress(m.v); break;
    case 'sabmsg': onSab(m); break;
    case 'admin': S.admin = m; break;
    case 'meet': onMeet(m); break;
    case 'voted': UI.meetVoted(m.id); break;
    case 'resume': onResume(m); break;
    case 'over': S.phase = 'over'; UI.over(m, App); break;
    case 'drop': UI.toast(nameOf(m.id) + ' lost connection…'); break;
    case 'gone': UI.toast(nameOf(m.id) + ' left the game.'); break;
    default: break;
  }
}

function onLobby(m) {
  S.lobby = m; S.leader = m.leader;
  if (m.phase === 'lobby' || m.phase === 'countdown') S.players = new Map();
  m.players.forEach(p => { S.players.set(p.id, Object.assign(S.players.get(p.id) || {}, p)); if (p.id === S.id) { S.color = p.color; S.hat = p.hat; S.name = p.name; } });
  if (m.phase === 'lobby' || m.phase === 'countdown') {
    if (S.inGame) { S.inGame = false; App.closeOverlays(); UI.hideMeeting(); UI.hideEject(); UI.hideOver(); UI.hideIntro(); show('hud', false); }
    if (S.screen !== 'lobby') { S.screen = 'lobby'; UI.screen('lobby'); UI.lobbyChat.clear(); UI.toast('Party ' + m.code + ' — share the code or invite link!', 3500); }
    UI.updateLobby(App);
  }
}

function onChat(m) {
  const n = nameOf(m.from), c = col((S.players.get(m.from) || {}).color | 0);
  if (!S.inGame) UI.lobbyChat.add(n, c, m.text);
  else if (S.phase === 'meeting') UI.meetChat(S, m);
  else if (App.ghostChat) App.ghostChat.add(n, c, m.text, true);
}

function onBegin(m) {
  S.inGame = true; S.screen = 'game'; S.id = m.me; S.role = m.role; S.alive = m.alive; S.mates = m.mates; S.tasks = m.tasks; S.set = m.settings;
  S.players = new Map(m.players.map(p => [p.id, p])); const me = S.players.get(S.id) || {}; S.color = me.color | 0; S.hat = me.hat | 0; S.name = me.name || S.name;
  S.x = m.x; S.y = m.y; S.vent = -1; S.others = new Map(); S.bodies = []; S.fx = []; S.sab = null; S.doors = new Set();
  S.kcd = S.scd = S.dcd = S.ecd = 0; S.tp = m.tp; S.emerg = m.emerg; S.phase = m.phase; S.admin = null; S.moving = false;
  UI.screen(null); show('hud', true); UI.hideOver(); UI.hideMeeting(); UI.hideEject(); show('conn', false);
  if (App.ghostChat) App.ghostChat.clear();
  UI.tasks(S); UI.progress(S.tp); UI.alert(S);
  if (m.phase === 'intro' && !m.rejoin) { UI.intro(S); BS.Sfx.play('go'); } else UI.hideIntro();
  history.replaceState(null, '', location.pathname + location.search);
}

function addFx(e) {
  const now = performance.now(), near = Math.hypot(e[1] - S.x, e[2] - S.y) < 500;
  S.fx.push({ k: e[0], x: e[1], y: e[2], col: col(e[3] | 0), t0: now, dur: e[0] === 'kill' ? 650 : 520, seed: Math.random() * 6 });
  if (near) BS.Sfx.play(e[0] === 'kill' ? 'kill' : 'vent');
}

function onSnap(m) {
  const now = performance.now();
  S.sab = m.sab; S.doors = new Set(m.dr); S.ecd = m.ecd;
  if (m.kcd !== undefined) { S.kcd = m.kcd; S.scd = m.scd; S.dcd = m.dcd; }
  const seen = new Set();
  for (const r of m.pl) {
    seen.add(r[0]);
    let o = S.others.get(r[0]);
    if (!o) { o = { id: r[0], x: r[1], y: r[2] }; S.others.set(r[0], o); }
    o.tx = r[1]; o.ty = r[2]; o.ghost = !!(r[3] & 1); o.face = r[3] & 2 ? -1 : 1; o.moving = !!(r[3] & 4); o.visual = !!(r[3] & 8); o.mate = !!(r[3] & 16); o.seen = now;
  }
  for (const id of [...S.others.keys()]) if (!seen.has(id)) S.others.delete(id);
  S.bodies = m.bd;
  if (m.ev) m.ev.forEach(addFx);
  UI.alert(S);
}

function onSab(m) {
  const T = { reactor: 'REACTOR MELTDOWN! Two players must hold the Core Consoles.', lights: 'Lights out!', comms: 'Communications are down!', fixed: 'Sabotage repaired.', doorsup: 'Doors reopened.' };
  if (m.s === 'doors') UI.toast('Doors locked: ' + BS.ROOMS[m.room].name);
  else UI.toast(T[m.s] || '', 3200);
  if (m.s === 'reactor' || m.s === 'lights' || m.s === 'comms') BS.Sfx.play('sab');
  if (m.s === 'comms' && S.panel && S.panel.task) App.closeOverlays();
  setTimeout(() => UI.tasks(S), 60);
}

function onMeet(m) {
  if (S.phase !== 'meeting') {
    S.phase = 'meeting'; if (App.closeOverlays) App.closeOverlays(); S.vent = -1; S.moving = false; S.others.clear(); UI.hideEject(); UI.hideIntro();
    const v = $('ventbar'); v.innerHTML = '';
  }
  if (m.body === 0 && m.caller === S.id && m.st === 'discuss') S.emerg = Math.max(0, S.emerg - 1);
  UI.meeting(m, App);
}

function onResume(m) {
  UI.hideMeeting(); UI.hideEject();
  S.phase = 'play'; S.x = m.x; S.y = m.y; S.alive = m.alive; S.others.clear(); S.bodies = []; S.vent = -1; S.fx = [];
  UI.tasks(S);
}
})(window);
