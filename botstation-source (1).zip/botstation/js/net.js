/* Bot Station - networking.
   A "link" is { send(obj), close(), onMessage, onClose }. Three transports produce links:
     peer     - PeerJS / WebRTC between browsers (the real thing; needs no game server)
     local    - BroadcastChannel between tabs of one browser (testing / same-computer play, add ?local to the URL)
     loopback - in-process pair, used by the party leader's own client to talk to its own host */
(function (g) {
'use strict';
const BS = g.BS, Net = BS.Net = {};
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const PREFIX = 'botstation-';
const clone = o => JSON.parse(JSON.stringify(o));

// Optional: point at your own PeerServer, e.g. { host: 'peer.example.com', port: 443, secure: true, path: '/' }
BS.PEER_OPTIONS = BS.PEER_OPTIONS || {};

Net.mode = () => (/[?&]local\b/.test(g.location ? g.location.search : '') ? 'local' : 'peer');
Net.makeCode = () => Array.from({ length: 5 }, () => ALPHA[Math.floor(Math.random() * ALPHA.length)]).join('');
Net.parseCode = s => String(s || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);

/* ---------------------------------------------------------------- loopback */
Net.loopback = () => {
  const mk = () => ({ onMessage: null, onClose: null, closed: false });
  const a = mk(), b = mk();
  const wire = (x, y) => {
    x.send = m => { const c = clone(m); setTimeout(() => { if (!y.closed && y.onMessage) y.onMessage(c); }, 0); };
    x.close = () => {
      if (x.closed) return;
      x.closed = true;
      setTimeout(() => { if (x.onClose) x.onClose(); if (!y.closed) { y.closed = true; if (y.onClose) y.onClose(); } }, 0);
    };
  };
  wire(a, b); wire(b, a);
  return [a, b];                           // [host side, client side]
};

/* -------------------------------------------------------------------- peer */
function wrapConn(conn) {
  let dead = false;
  const link = {
    onMessage: null, onClose: null,
    send(m) { if (conn.open) conn.send(m); },
    close() { try { conn.close(); } catch (e) { /* ignore */ } }
  };
  const gone = () => { if (!dead) { dead = true; if (link.onClose) link.onClose(); } };
  conn.on('data', d => { if (link.onMessage) link.onMessage(d); });
  conn.on('close', gone);
  conn.on('error', gone);
  return link;
}
const needPeer = cb => {
  if (g.Peer) return true;
  cb.onError('Could not load the networking library. Check your connection or ad blocker and reload.');
  return false;
};

/* Create a party: tries random codes until one is free. cb.onOpen(code), cb.onLink(link), cb.onError(msg) */
Net.hostParty = (cb, tries) => {
  tries = tries || 0;
  const code = Net.makeCode();
  if (Net.mode() === 'local') {
    const bc = new g.BroadcastChannel('bs-' + code), links = new Map();
    const mk = id => ({
      onMessage: null, onClose: null,
      send(m) { bc.postMessage({ to: id, t: 'msg', data: m }); },
      close() { bc.postMessage({ to: id, t: 'bye' }); links.delete(id); }
    });
    bc.onmessage = e => {
      const d = e.data;
      if (!d || d.to !== 'host') return;
      if (d.t === 'hello') { const l = mk(d.from); links.set(d.from, l); bc.postMessage({ to: d.from, t: 'ack' }); cb.onLink(l); }
      else if (d.t === 'msg') { const l = links.get(d.from); if (l && l.onMessage) l.onMessage(d.data); }
      else if (d.t === 'bye') { const l = links.get(d.from); links.delete(d.from); if (l && l.onClose) l.onClose(); }
    };
    setTimeout(() => cb.onOpen(code), 0);
    return { close() { bc.close(); } };
  }
  if (!needPeer(cb)) return null;
  const peer = new g.Peer(PREFIX + code, Object.assign({ debug: 0 }, BS.PEER_OPTIONS));
  const handle = { close() { try { peer.destroy(); } catch (e) { /* ignore */ } } };
  peer.on('open', () => cb.onOpen(code));
  peer.on('connection', conn => { conn.on('open', () => cb.onLink(wrapConn(conn))); });
  peer.on('disconnected', () => { try { peer.reconnect(); } catch (e) { /* ignore */ } });
  peer.on('error', e => {
    if (e.type === 'unavailable-id' && tries < 6) { handle.close(); Object.assign(handle, Net.hostParty(cb, tries + 1) || {}); return; }
    if (e.type === 'peer-unavailable' || e.type === 'webrtc') return;       // a single guest failing to connect is not fatal
    cb.onError(e.type === 'network' || e.type === 'server-error' || e.type === 'socket-error'
      ? 'Could not reach the matchmaking server. Check your connection and try again.'
      : 'Could not create a party (' + e.type + ').');
  });
  return handle;
};

/* Join a party by code. cb.onOpen(link), cb.onError(msg) */
Net.joinParty = (code, cb) => {
  code = Net.parseCode(code);
  if (code.length !== 5) { setTimeout(() => cb.onError('Enter the 5-letter party code.'), 0); return null; }
  let done = false, cleanup = () => {};
  const fail = m => { if (!done) { done = true; clearTimeout(timer); cleanup(); cb.onError(m); } };
  const timer = setTimeout(() => fail('Could not reach that party. Check the code and try again.'), 15000);
  const ok = link => { if (!done) { done = true; clearTimeout(timer); cb.onOpen(link); } };

  if (Net.mode() === 'local') {
    const bc = new g.BroadcastChannel('bs-' + code), me = 'c' + Math.random().toString(36).slice(2);
    const link = {
      onMessage: null, onClose: null,
      send(m) { bc.postMessage({ to: 'host', from: me, t: 'msg', data: m }); },
      close() { bc.postMessage({ to: 'host', from: me, t: 'bye' }); bc.close(); }
    };
    bc.onmessage = e => {
      const d = e.data;
      if (!d || d.to !== me) return;
      if (d.t === 'ack') ok(link);
      else if (d.t === 'msg' && link.onMessage) link.onMessage(d.data);
      else if (d.t === 'bye' && link.onClose) link.onClose();
    };
    bc.postMessage({ to: 'host', from: me, t: 'hello' });
    setTimeout(() => fail('No party with that code in this browser.'), 1500);
    return { close() { link.close(); } };
  }
  if (!needPeer({ onError: fail })) return null;
  const peer = new g.Peer(Object.assign({ debug: 0 }, BS.PEER_OPTIONS));
  cleanup = () => { try { peer.destroy(); } catch (e) { /* ignore */ } };
  peer.on('open', () => {
    const conn = peer.connect(PREFIX + code, { serialization: 'json', reliable: true });
    conn.on('open', () => { const l = wrapConn(conn); const close = l.close; l.close = () => { close(); try { peer.destroy(); } catch (e) { /* ignore */ } }; ok(l); });
    conn.on('error', () => fail('Could not connect to that party.'));
  });
  peer.on('error', e => fail(e.type === 'peer-unavailable' ? 'No party found with code ' + code + '.' : 'Connection problem (' + e.type + '). Try again.'));
  return { close() { clearTimeout(timer); try { peer.destroy(); } catch (e) { /* ignore */ } } };
};

/* ------------------------------------------------------------------ ticker */
// Browsers throttle timers in background tabs to ~1 Hz, which would freeze a hosted game when the
// leader switches tabs. A worker's timer is not throttled the same way, so tick from there.
Net.ticker = (fn, ms) => {
  let stop = () => {};
  try {
    const src = 'let t=setInterval(()=>postMessage(0),' + ms + ');onmessage=()=>{clearInterval(t);close();}';
    const w = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
    w.onmessage = () => fn();
    stop = () => { try { w.postMessage(1); w.terminate(); } catch (e) { /* ignore */ } };
  } catch (e) {
    const t = setInterval(fn, ms);
    stop = () => clearInterval(t);
  }
  return () => stop();
};
})(typeof window !== 'undefined' ? window : globalThis);
