/* Bot Station - a tiny MQTT 3.1.1 client over WebSocket (QoS 0 only).
   It is used for exactly one thing: the public party list (see registry.js). Supports CONNECT with a last-will,
   retained PUBLISH, SUBSCRIBE and keep-alive pings. Works in browsers and in Node 22+ (global WebSocket). */
(function (g) {
'use strict';
const BS = g.BS = g.BS || {};
const enc = new TextEncoder(), dec = new TextDecoder();
const CONNACK = 2, PUBLISH = 3, SUBACK = 9;

/* ---------------------------------------------------------------- encoding */
const varint = n => { const o = []; do { let d = n % 128; n = Math.floor(n / 128); if (n > 0) d |= 128; o.push(d); } while (n > 0); return o; };
const str = s => { const b = enc.encode(s); return [b.length >> 8, b.length & 255, ...b]; };
const packet = (b0, body) => {
  const rl = varint(body.length), out = new Uint8Array(1 + rl.length + body.length);
  out[0] = b0; out.set(rl, 1); out.set(body, 1 + rl.length);
  return out;
};
const E = {
  connect(o) {
    const will = o.will, user = o.username != null && o.username !== '', pass = user && o.password != null;
    const flags = 0x02 | (will ? 0x04 | (will.retain ? 0x20 : 0) : 0) | (user ? 0x80 : 0) | (pass ? 0x40 : 0);
    const ka = o.keepalive | 0;
    const body = [...str('MQTT'), 4, flags, ka >> 8, ka & 255, ...str(o.clientId)];
    if (will) { const m = enc.encode(will.payload || ''); body.push(...str(will.topic), m.length >> 8, m.length & 255, ...m); }
    if (user) body.push(...str(o.username));
    if (pass) body.push(...str(o.password));
    return packet(0x10, body);
  },
  publish: (topic, payload, retain) => packet(0x30 | (retain ? 1 : 0), [...str(topic), ...enc.encode(payload || '')]),
  subscribe: (id, filter) => packet(0x82, [id >> 8, id & 255, ...str(filter), 0]),
  pingreq: () => new Uint8Array([0xc0, 0]),
  disconnect: () => new Uint8Array([0xe0, 0])
};

/* ------------------------------------------------------- stream -> packets */
// A WebSocket frame may hold several MQTT packets or only part of one, so parse a byte stream.
class Parser {
  constructor(onPacket) { this.buf = new Uint8Array(0); this.onPacket = onPacket; }
  push(chunk) {
    const nb = new Uint8Array(this.buf.length + chunk.length); nb.set(this.buf); nb.set(chunk, this.buf.length); this.buf = nb;
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      let mult = 1, len = 0, i = 1, d, n = 0;
      do {
        if (i >= b.length) return;
        d = b[i++]; len += (d & 127) * mult; mult *= 128;
        if (++n > 4) throw new Error('malformed length');
      } while (d & 128);
      if (b.length < i + len) return;
      this.buf = b.subarray(i + len);
      this.onPacket(b[0], b.subarray(i, i + len));
    }
  }
}

/* ------------------------------------------------------------------ client */
/* new Client(url, { clientId, keepalive, username, password, will:{topic,payload,retain},
                     onOpen(), onMessage(topic, payload, retained), onClose(reason), onSub(ok) }) */
class Client {
  constructor(url, o) {
    this.o = o; this.connected = false; this.dead = false; this.pid = 0; this.lastRx = this.lastTx = Date.now();
    this.ka = o.keepalive || 30;
    this.parser = new Parser((b0, body) => this.onPacket(b0, body));
    let ws;
    try { ws = new g.WebSocket(url, 'mqtt'); } catch (e) { setTimeout(() => this.fail('open'), 0); return; }
    ws.binaryType = 'arraybuffer'; this.ws = ws;
    this.connTimer = setTimeout(() => this.fail('timeout'), o.connectTimeout || 10000);
    ws.onopen = () => this.raw(E.connect(Object.assign({ keepalive: this.ka }, o)));
    ws.onmessage = e => {
      if (typeof e.data === 'string') return;
      this.lastRx = Date.now();
      try { this.parser.push(new Uint8Array(e.data)); } catch (err) { this.fail('protocol'); }
    };
    ws.onerror = () => this.fail('error');  // browsers follow with a close event; Node's WebSocket does not, so don't wait for it
    ws.onclose = () => this.fail('closed');
    this.timer = setInterval(() => this.pulse(), 1000);
  }
  raw(bytes) { if (this.ws && this.ws.readyState === 1) { this.ws.send(bytes); this.lastTx = Date.now(); return true; } return false; }
  // keep-alive: ping when quiet, give up when the broker has been silent for 1.5x the interval
  pulse() {
    if (!this.connected || this.dead) return;
    const now = Date.now();
    if (now - this.lastRx > this.ka * 1500) return this.fail('timeout');
    if (now - this.lastTx >= this.ka * 500) this.raw(E.pingreq());
  }
  onPacket(b0, body) {
    const type = b0 >> 4;
    if (type === CONNACK) {
      if (body.length < 2) return this.fail('protocol');
      if (body[1] !== 0) return this.fail('refused:' + body[1]);
      this.connected = true; clearTimeout(this.connTimer);
      if (this.o.onOpen) this.o.onOpen();
    } else if (type === PUBLISH) {
      const qos = (b0 >> 1) & 3, tl = (body[0] << 8) | body[1], topic = dec.decode(body.subarray(2, 2 + tl));
      let p = 2 + tl;
      if (qos > 0) { const id = (body[p] << 8) | body[p + 1]; p += 2; if (qos === 1) this.raw(new Uint8Array([0x40, 2, id >> 8, id & 255])); }
      if (this.o.onMessage) this.o.onMessage(topic, dec.decode(body.subarray(p)), !!(b0 & 1));
    } else if (type === SUBACK) {
      if (this.o.onSub) this.o.onSub(body.length > 2 && body[2] < 0x80);
    }
  }
  subscribe(filter) { this.pid = (this.pid % 65535) + 1; return this.raw(E.subscribe(this.pid, filter)); }
  publish(topic, payload, retain) { return this.connected && this.raw(E.publish(topic, payload, retain)); }
  fail(reason) {
    if (this.dead) return;
    this.dead = true; this.connected = false; clearTimeout(this.connTimer); clearInterval(this.timer);
    try { this.ws.close(); } catch (e) { /* ignore */ }
    if (this.o.onClose) this.o.onClose(reason);
  }
  // graceful: send DISCONNECT first (the broker then discards the last-will); otherwise just drop the socket
  close(graceful) {
    if (this.dead) return;
    if (graceful && this.connected) this.raw(E.disconnect());
    this.dead = true; this.connected = false; clearTimeout(this.connTimer); clearInterval(this.timer);
    try { this.ws.close(); } catch (e) { /* ignore */ }
  }
}

BS.Mqtt = { Client, Parser, encode: E };
})(typeof window !== 'undefined' ? window : globalThis);
