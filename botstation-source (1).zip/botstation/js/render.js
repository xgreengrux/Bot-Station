/* Bot Station - canvas rendering: robots, the station, fog of war. Pure drawing; no game logic. */
(function (g) {
'use strict';
const BS = g.BS, C = BS.C, R = BS.R = {};
const TAU = Math.PI * 2;

const shade = (hex, a) => {
  const n = parseInt(hex.slice(1), 16);
  const f = v => Math.max(0, Math.min(255, Math.round(a < 0 ? v * (1 + a) : v + (255 - v) * a)));
  return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
};
const rr = (c, x, y, w, h, r) => { c.beginPath(); c.roundRect(x, y, w, h, r); };
R.shade = shade;

/* ------------------------------------------------------------------ hats */
function hat(c, id, bob, t, col) {
  c.save(); c.translate(0, -15 + bob); c.lineWidth = 2; c.strokeStyle = '#1a2036'; c.fillStyle = '#ffd34d';
  if (id === 1) { c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -9); c.stroke(); c.beginPath(); c.arc(0, -10, 3, 0, TAU); c.fill(); c.stroke(); }
  else if (id === 2) {
    for (const s of [-1, 1]) { c.beginPath(); c.moveTo(s * 4, 0); c.lineTo(s * 8, -9); c.stroke(); c.beginPath(); c.arc(s * 8, -10, 2.6, 0, TAU); c.fill(); c.stroke(); }
  } else if (id === 3) {
    c.fillStyle = '#e5484d'; rr(c, -2.5, -6, 5, 6, 1); c.fill(); c.stroke();
    c.fillStyle = '#f4f6ff'; c.beginPath(); c.ellipse(0, -7, Math.abs(Math.cos(t * 22)) * 11 + 1.5, 2, 0, 0, TAU); c.fill(); c.stroke();
  } else if (id === 4) { c.strokeStyle = '#ffd34d'; c.lineWidth = 3; c.beginPath(); c.ellipse(0, -9, 9, 3, 0, 0, TAU); c.stroke(); }
  else if (id === 5) {
    c.fillStyle = shade(col, -0.4); c.beginPath(); c.arc(0, 0, 11, Math.PI, 0); c.fill(); c.stroke();
    c.fillRect(-1, -1, 13, 3); c.strokeRect(-1, -1, 13, 3);
  }
  c.restore();
}

/* ---------------------------------------------------------------- robots */
R.drawBot = (c, x, y, o) => {
  const f = o.face || 1, t = o.t || 0, col = o.color, run = o.moving && !o.ghost;
  const bob = run ? Math.sin(t * 16 + (o.seed || 0)) * 1.6 : 0;
  c.save(); c.translate(x, y);
  if (o.ghost) c.globalAlpha = 0.5;
  c.lineWidth = 2; c.strokeStyle = 'rgba(10,14,28,.9)';
  if (!o.ghost) {
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 15, 13, 4.5, 0, 0, TAU); c.fill();
    const lo = run ? Math.sin(t * 16 + (o.seed || 0)) * 3.5 : 0;
    c.fillStyle = shade(col, -0.45);
    rr(c, -9, 9 + Math.max(0, lo), 7, 6, 2); c.fill(); rr(c, 2, 9 + Math.max(0, -lo), 7, 6, 2); c.fill();
  }
  c.fillStyle = shade(col, -0.35); rr(c, f > 0 ? -18 : 12, -6 + bob, 6, 13, 3); c.fill(); c.stroke();      // back module
  c.fillStyle = col; rr(c, -13, -15 + bob, 26, o.ghost ? 24 : 27, 9); c.fill(); c.stroke();
  c.fillStyle = shade(col, -0.22); c.save(); rr(c, -13, -15 + bob, 26, o.ghost ? 24 : 27, 9); c.clip(); c.fillRect(-13, 3 + bob, 26, 12); c.restore();
  c.fillStyle = shade(col, 0.45); rr(c, f > 0 ? -9 : 4, -12 + bob, 5, 3, 1.5); c.fill();                  // shine
  c.fillStyle = '#bfe6ff'; rr(c, f > 0 ? -3 : -13, -9 + bob, 16, 10, 5); c.fill(); c.stroke();           // visor
  c.fillStyle = 'rgba(255,255,255,.75)'; rr(c, f > 0 ? 0 : -9, -7.5 + bob, 6, 2.5, 1.2); c.fill();
  if (o.ghost) { c.fillStyle = 'rgba(180,210,255,.55)'; c.beginPath(); c.moveTo(-13, 8 + bob); for (let i = 0; i < 5; i++) c.lineTo(-13 + i * 6.5 + 3.2, (i % 2 ? 8 : 13) + bob); c.lineTo(13, 8 + bob); c.fill(); }
  hat(c, o.hat | 0, bob, t, col);
  c.restore();
  if (o.name) {
    c.save(); c.font = 'bold 12px system-ui,sans-serif'; c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = 'rgba(0,0,0,.75)';
    c.globalAlpha = o.ghost ? 0.7 : 1; c.fillStyle = o.nameColor || '#fff';
    c.strokeText(o.name, x, y - 29); c.fillText(o.name, x, y - 29); c.restore();
  }
};

R.drawBody = (c, x, y, col) => {
  c.save(); c.translate(x, y); c.lineWidth = 2; c.strokeStyle = 'rgba(10,14,28,.9)';
  c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(0, 10, 16, 5, 0, 0, TAU); c.fill();
  c.fillStyle = shade(col, -0.2); rr(c, -13, -1, 26, 13, [0, 0, 7, 7]); c.fill(); c.stroke();                 // legs/lower half
  c.save(); c.translate(7, -9); c.rotate(0.55); c.fillStyle = col; rr(c, -12, -9, 24, 15, 7); c.fill(); c.stroke();
  c.strokeStyle = '#1a2036'; c.lineWidth = 2; for (const s of [-5, 4]) { c.beginPath(); c.moveTo(s - 2, -5); c.lineTo(s + 2, 0); c.moveTo(s + 2, -5); c.lineTo(s - 2, 0); c.stroke(); }
  c.restore();
  c.strokeStyle = '#ffd34d'; c.lineWidth = 2; c.beginPath(); c.moveTo(-14, -3); c.lineTo(-9, -8); c.lineTo(-12, -9); c.lineTo(-6, -15); c.stroke();   // spark
  c.restore();
};

/* ----------------------------------------------------------------- world */
const OBS_DRAW = {
  machine: (c, o, t) => { c.fillStyle = '#3a425e'; rr(c, o.x, o.y, o.w, o.h, 6); c.fill(); c.fillStyle = '#242a40'; c.fillRect(o.x + 8, o.y + 8, o.w - 16, o.h * 0.4);
    for (let i = 0; i < 4; i++) { c.fillStyle = (Math.floor(t * 2 + i) % 3) ? '#4ade80' : '#f87171'; c.fillRect(o.x + 10 + i * 14, o.y + o.h - 16, 8, 8); } },
  planter: (c, o) => { c.fillStyle = '#5a4630'; rr(c, o.x, o.y + o.h * 0.4, o.w, o.h * 0.6, 5); c.fill();
    for (let i = 0; i < o.w / 16; i++) { c.fillStyle = i % 2 ? '#3fae5a' : '#2f8f4a'; c.beginPath(); c.arc(o.x + 10 + i * 16, o.y + o.h * 0.35, 11, 0, TAU); c.fill(); } },
  core: (c, o, t) => { c.fillStyle = '#4a2a35'; rr(c, o.x, o.y, o.w, o.h, 14); c.fill(); const p = 0.6 + Math.sin(t * 3) * 0.2;
    const gr = c.createRadialGradient(o.x + o.w / 2, o.y + o.h / 2, 4, o.x + o.w / 2, o.y + o.h / 2, o.w / 2); gr.addColorStop(0, 'rgba(255,190,90,' + p + ')'); gr.addColorStop(1, 'rgba(255,80,60,0)');
    c.fillStyle = gr; c.fillRect(o.x - 30, o.y - 30, o.w + 60, o.h + 60); c.fillStyle = '#ffb347'; c.beginPath(); c.ellipse(o.x + o.w / 2, o.y + o.h / 2, o.w * 0.26, o.h * 0.3, 0, 0, TAU); c.fill(); },
  bed: (c, o) => { c.fillStyle = '#cfe3ee'; rr(c, o.x, o.y, o.w, o.h, 6); c.fill(); c.fillStyle = '#89b4c9'; c.fillRect(o.x + 28, o.y + 4, o.w - 32, o.h - 8); c.fillStyle = '#fff'; rr(c, o.x + 4, o.y + 6, 20, o.h - 12, 4); c.fill(); },
  table: (c, o) => { c.fillStyle = '#4a5578'; c.beginPath(); c.ellipse(o.x + o.w / 2, o.y + o.h / 2, o.w / 2, o.h / 2, 0, 0, TAU); c.fill(); c.fillStyle = '#5d6a92'; c.beginPath(); c.ellipse(o.x + o.w / 2, o.y + o.h / 2, o.w / 2 - 10, o.h / 2 - 10, 0, 0, TAU); c.fill(); },
  console: (c, o, t) => { c.fillStyle = '#2c3354'; rr(c, o.x, o.y, o.w, o.h, 5); c.fill(); c.fillStyle = '#6ee7f9'; c.globalAlpha = 0.55 + Math.sin(t * 2 + o.x) * 0.15; c.fillRect(o.x + 6, o.y + 6, o.w - 12, o.h - 14); c.globalAlpha = 1; },
  crate: (c, o) => { c.fillStyle = '#8a6a3c'; rr(c, o.x, o.y, o.w, o.h, 4); c.fill(); c.strokeStyle = '#5e4624'; c.lineWidth = 3; c.strokeRect(o.x + 3, o.y + 3, o.w - 6, o.h - 6); c.beginPath(); c.moveTo(o.x, o.y); c.lineTo(o.x + o.w, o.y + o.h); c.stroke(); },
  generator: (c, o, t) => { c.fillStyle = '#4b5563'; rr(c, o.x, o.y, o.w, o.h, 10); c.fill(); c.fillStyle = '#9ca3af'; c.fillRect(o.x + 8, o.y + 10, o.w - 16, 10);
    c.fillStyle = (Math.floor(t * 3) % 2) ? '#facc15' : '#a16207'; c.beginPath(); c.arc(o.x + o.w / 2, o.y + o.h - 18, 7, 0, TAU); c.fill(); },
  bank: (c, o, t) => { c.fillStyle = '#374151'; rr(c, o.x, o.y, o.w, o.h, 4); c.fill(); for (let i = 0; i < 8; i++) { c.fillStyle = (Math.floor(t + i) % 4) ? '#34d399' : '#134e3a'; c.fillRect(o.x + 8 + i * 19, o.y + 10, 13, o.h - 20); } }
};

const STATION_ICON = id => id === 'button' ? 'button' : id === 'admin' ? 'admin' : id.startsWith('melt') ? 'melt' : id === 'lights_panel' ? 'lights' : id === 'comms_panel' ? 'comms' : 'panel';
function station(c, id, s, t) {
  const k = STATION_ICON(id);
  c.save(); c.translate(s.x, s.y);
  if (k === 'button') {
    c.fillStyle = '#2a3150'; c.beginPath(); c.arc(0, 0, 19, 0, TAU); c.fill();
    c.fillStyle = '#c23a40'; c.beginPath(); c.arc(0, -2, 13, 0, TAU); c.fill(); c.fillStyle = '#ff6b70'; c.beginPath(); c.arc(-3, -6, 5, 0, TAU); c.fill();
  } else if (k === 'admin') {
    c.fillStyle = '#2a3150'; rr(c, -22, -14, 44, 28, 5); c.fill(); c.fillStyle = '#6ee7f9'; c.globalAlpha = 0.7; c.fillRect(-18, -10, 36, 20); c.globalAlpha = 1;
    c.fillStyle = '#0b1b33'; for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) c.fillRect(-14 + i * 11, -7 + j * 9, 8, 6);
  } else {
    c.fillStyle = k === 'melt' ? '#5a3040' : '#2a3150'; rr(c, -15, -11, 30, 22, 4); c.fill();
    c.fillStyle = k === 'melt' ? '#ffb347' : k === 'lights' ? '#fde68a' : k === 'comms' ? '#a78bfa' : '#38bdf8';
    c.fillRect(-11, -7, 22, 9); c.fillStyle = (Math.floor(t * 2 + s.x) % 2) ? '#4ade80' : '#166534'; c.fillRect(-11, 5, 5, 3); c.fillStyle = '#f87171'; c.fillRect(-3, 5, 5, 3);
  }
  c.restore();
}

R.drawWorld = (c, S, t) => {
  c.fillStyle = '#05070d'; c.fillRect(0, 0, C.W, C.H);
  const rects = BS.ROOMS.concat(BS.HALLS);
  c.fillStyle = '#4b5679'; rects.forEach(r => c.fillRect(r.x - 12, r.y - 12, r.w + 24, r.h + 24));
  c.fillStyle = '#272d44'; BS.HALLS.forEach(r => c.fillRect(r.x - 1, r.y - 1, r.w + 2, r.h + 2));
  BS.ROOMS.forEach(r => {
    c.fillStyle = r.c; c.fillRect(r.x, r.y, r.w, r.h);
    c.strokeStyle = 'rgba(255,255,255,.045)'; c.lineWidth = 1; c.beginPath();
    for (let x = r.x + 40; x < r.x + r.w; x += 40) { c.moveTo(x, r.y); c.lineTo(x, r.y + r.h); }
    for (let y = r.y + 40; y < r.y + r.h; y += 40) { c.moveTo(r.x, y); c.lineTo(r.x + r.w, y); }
    c.stroke();
    c.fillStyle = 'rgba(255,255,255,.13)'; c.font = '800 20px system-ui,sans-serif'; c.textAlign = 'left'; c.fillText(r.name.toUpperCase(), r.x + 14, r.y + r.h - 14);
  });
  BS.OBS.forEach(o => { c.save(); OBS_DRAW[o.k](c, o, t); c.restore(); });
  for (const id in BS.ST) station(c, id, BS.ST[id], t);
  BS.VENTS.forEach(v => { c.fillStyle = '#10131f'; c.beginPath(); c.ellipse(v.x, v.y, 17, 10, 0, 0, TAU); c.fill(); c.strokeStyle = '#59627f'; c.lineWidth = 2; c.stroke();
    c.strokeStyle = '#2e3550'; c.beginPath(); for (let i = -9; i <= 9; i += 6) { c.moveTo(v.x + i, v.y - 6); c.lineTo(v.x + i, v.y + 6); } c.stroke(); });
  // task markers
  const pulse = (Math.sin(t * 5) + 1) / 2;
  const mark = (x, y, col, txt) => { c.save(); c.translate(x, y - 30 - pulse * 3); c.fillStyle = col; c.strokeStyle = '#1a2036'; c.lineWidth = 2; c.beginPath(); c.arc(0, 0, 10, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#1a2036'; c.font = 'bold 14px system-ui'; c.textAlign = 'center'; c.fillText(txt, 0, 5); c.restore(); };
  if (S.tasksVisible) S.tasks.forEach(tk => { const def = BS.TASKS.find(d => d.id === tk.id);
    def.steps.forEach((st, i) => { if (tk.done[i] || (def.ordered && tk.done.slice(0, i).some(d => !d))) return; mark(BS.ST[st.st].x, BS.ST[st.st].y, '#ffd34d', '!'); }); });
  const sab = S.sab;
  if (sab) {
    const ring = id => { const s = BS.ST[id]; c.strokeStyle = 'rgba(255,70,70,' + (0.4 + pulse * 0.6) + ')'; c.lineWidth = 4; c.beginPath(); c.arc(s.x, s.y, 26 + pulse * 6, 0, TAU); c.stroke(); mark(s.x, s.y, '#ff5a5a', '!'); };
    if (sab.k === 'reactor') { ring('melt_a'); ring('melt_b'); } else if (sab.k === 'lights') ring('lights_panel'); else if (sab.k === 'comms') ring('comms_panel');
  }
  // closed doors
  S.doors.forEach(id => { const d = BS.DOORS[id]; c.fillStyle = '#2b1013'; c.fillRect(d.x - 2, d.y - 2, d.w + 4, d.h + 4); c.save(); c.beginPath(); c.rect(d.x, d.y, d.w, d.h); c.clip();
    c.strokeStyle = '#ef4444'; c.lineWidth = 5; c.beginPath(); for (let i = -80; i < 200; i += 14) { c.moveTo(d.x + i, d.y + 100); c.lineTo(d.x + i + 100, d.y); } c.stroke(); c.restore(); });
};

/* ------------------------------------------------------------------- fog */
R.drawFog = (ctx, fogCtx, w, h, cam, S, radius, poly) => {
  fogCtx.globalCompositeOperation = 'source-over'; fogCtx.clearRect(0, 0, w, h);
  fogCtx.fillStyle = 'rgba(3,5,10,0.94)'; fogCtx.fillRect(0, 0, w, h);
  fogCtx.globalCompositeOperation = 'destination-out';
  const sx = (S.x - cam.x) * cam.s + w / 2, sy = (S.y - cam.y) * cam.s + h / 2;
  fogCtx.save(); fogCtx.beginPath();
  poly.forEach((p, i) => { const x = (p[0] - cam.x) * cam.s + w / 2, y = (p[1] - cam.y) * cam.s + h / 2; if (i) fogCtx.lineTo(x, y); else fogCtx.moveTo(x, y); });
  fogCtx.closePath(); fogCtx.clip();
  const gr = fogCtx.createRadialGradient(sx, sy, radius * cam.s * 0.35, sx, sy, radius * cam.s);
  gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.7, 'rgba(0,0,0,0.9)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  fogCtx.fillStyle = gr; fogCtx.fillRect(0, 0, w, h); fogCtx.restore();
  ctx.drawImage(fogCtx.canvas, 0, 0, w, h);
};

/* --------------------------------------------------------------- effects */
R.drawEffect = (c, e, now) => {
  const a = (now - e.t0) / e.dur; if (a >= 1) return false;
  c.save(); c.translate(e.x, e.y);
  if (e.k === 'kill') { for (let i = 0; i < 10; i++) { const ang = i / 10 * TAU + e.seed, d = a * 46; c.fillStyle = i % 2 ? '#ffd34d' : e.col; c.globalAlpha = 1 - a; c.beginPath(); c.arc(Math.cos(ang) * d, Math.sin(ang) * d - a * 10, 4 * (1 - a) + 1, 0, TAU); c.fill(); } }
  else { c.globalAlpha = (1 - a) * 0.8; c.fillStyle = '#9aa4c2'; for (let i = 0; i < 5; i++) { const ang = i / 5 * TAU + e.seed; c.beginPath(); c.arc(Math.cos(ang) * a * 22, Math.sin(ang) * a * 12 - a * 14, 6 + a * 8, 0, TAU); c.fill(); } }
  c.restore(); return true;
};

/* mini robot icon for DOM use (lobby cards, meeting, results) */
R.icon = (col, hatId, size, ghost) => {
  const cv = document.createElement('canvas'); cv.width = cv.height = size * 2; cv.style.width = cv.style.height = size + 'px';
  const c = cv.getContext('2d'); const k = cv.width / 44; c.scale(k, k); R.drawBot(c, 22, 29, { color: col, hat: hatId, ghost, face: 1 }); return cv;
};
})(window);
