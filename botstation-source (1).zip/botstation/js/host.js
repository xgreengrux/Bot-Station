/* Bot Station - authoritative host, part 1: party, lobby and connections.
   The party leader's browser runs this; every other player connects to it. */
(function (g) {
'use strict';
const BS = g.BS, C = BS.C;
const clean = BS.clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f<>&"]/g, '').trim().slice(0, n);

class Host {
  constructor(o) {
    o = o || {};
    this.code = o.code || 'TEST';
    this.minPlayers = o.minPlayers || C.MIN_PLAYERS;
    this.rng = o.rng || Math.random;
    this.onClosed = o.onClosed || null;
    this.public = o.public !== false;       // listed in the party browser (the leader can switch this in the lobby)
    this.idleTimeout = o.idleTimeout !== undefined ? o.idleTimeout : 12;   // seconds of silence before a remote player counts as dropped
    this.idleCheck = 0;
    this.settings = BS.defaultSettings();
    this.players = new Map();
    this.nextId = 1;
    this.leader = 0;
    this.phase = 'lobby';     // lobby | countdown | intro | play | meeting | over
    this.time = 0;
    this.countdown = 0;
    this.snapAcc = 0;
    this.closed = false;
    this.errors = 0;
    this.G = null;
  }

  /* ---------------------------------------------------------- plumbing */
  connected() { let n = 0; for (const p of this.players.values()) if (p.conn) n++; return n; }
  send(p, m) { if (p && p.conn && p.link) { try { p.link.send(m); } catch (e) { /* link already gone */ } } }
  all(m, f) { for (const p of this.players.values()) if (!f || f(p)) this.send(p, m); }

  addLink(link) {
    if (this.closed) { try { link.close(); } catch (e) { /* ignore */ } return; }
    const h = { link, p: null };
    link.onMessage = m => { try { this.onMsg(h, m); } catch (e) { this.errors++; console.error('[host]', e); } };
    link.onClose = () => { try { this.onLinkClose(h); } catch (e) { this.errors++; console.error('[host]', e); } };
  }

  onMsg(h, m) {
    if (!m || typeof m !== 'object' || typeof m.k !== 'string') return;
    if (m.k === 'join') return this.onJoin(h, m);
    const p = h.p;
    if (!p || p.link !== h.link) return;
    p.seen = this.time;
    const fn = this['m_' + m.k];
    if (typeof fn === 'function') fn.call(this, p, m);
  }

  reject(h, why) {
    try { h.link.send({ k: 'reject', why }); } catch (e) { /* ignore */ }
    setTimeout(() => { try { h.link.close(); } catch (e) { /* ignore */ } }, 50);
  }

  freeColor(want, except) {
    const used = new Set();
    for (const p of this.players.values()) if (p !== except) used.add(p.color);
    if (Number.isInteger(want) && want >= 0 && want < BS.COLORS.length && !used.has(want)) return want;
    for (let i = 0; i < BS.COLORS.length; i++) if (!used.has(i)) return i;
    return 0;
  }

  onJoin(h, m) {
    if (h.p) return;
    const token = clean(m.token, 48);
    let p = null;
    if (token) for (const q of this.players.values()) if (q.token === token) p = q;

    if (p) {                                   // reconnecting player
      if (p.gone) return this.reject(h, 'You were removed from this game.');
      if (p.link && p.link !== h.link) { const old = p.link; p.link = null; try { old.close(); } catch (e) { /* ignore */ } }
      p.link = h.link; p.conn = true; p.dropAt = 0; p.seen = this.time; h.p = p;
      this.send(p, { k: 'welcome', id: p.id, code: this.code, rejoin: true });
      this.sendLobby();
      if (this.G && this.phase !== 'lobby' && this.phase !== 'countdown') this.sendState(p);
      return;
    }
    if (this.phase !== 'lobby' && this.phase !== 'countdown') return this.reject(h, 'A game is already in progress.');
    if (this.players.size >= C.MAX_PLAYERS) return this.reject(h, 'This party is full.');

    const id = this.nextId++;
    p = {
      id, token, link: h.link, conn: true, dropAt: 0, chatAt: -9, seen: this.time,
      name: clean(m.name, 12) || 'Bot' + id,
      color: this.freeColor(m.color | 0), hat: Math.max(0, Math.min(BS.HATS.length - 1, m.hat | 0)),
      role: 'crew', alive: true, gone: false, x: 0, y: 0, vent: -1, tasks: [], open: null
    };
    h.p = p;
    this.players.set(id, p);
    if (!this.leader) this.leader = id;
    this.send(p, { k: 'welcome', id, code: this.code, rejoin: false });
    this.resetCountdown();
    this.sendLobby();
  }

  onLinkClose(h) {
    const p = h.p;
    if (!p || p.link !== h.link) return;
    p.link = null; p.conn = false;
    if (this.phase === 'lobby' || this.phase === 'countdown' || this.phase === 'over') this.removePlayer(p);
    else { p.dropAt = this.time + C.GRACE; this.all({ k: 'drop', id: p.id }); }
  }

  removePlayer(p) {
    if (!this.players.has(p.id)) return;
    if (p.id === this.leader) return this.closeParty('The party leader left, so the party was closed.');
    this.players.delete(p.id);
    this.resetCountdown();
    this.sendLobby();
  }

  closeParty(why) {
    if (this.closed) return;
    this.all({ k: 'closed', why });
    this.closed = true;
    if (this.onClosed) this.onClosed(why);
  }

  resetCountdown() {
    if (this.phase !== 'countdown') return;
    if (this.connected() < this.minPlayers) this.phase = 'lobby';
    else this.countdown = C.START_CD;
  }

  /* ------------------------------------------------------------ lobby */
  lobbyMsg() {
    return {
      k: 'lobby', code: this.code, phase: this.phase, leader: this.leader, min: this.minPlayers, max: C.MAX_PLAYERS,
      cd: this.phase === 'countdown' ? Math.max(0, this.countdown) : 0, settings: this.settings, pub: this.public,
      players: [...this.players.values()].filter(p => !p.gone).map(p => ({ id: p.id, name: p.name, color: p.color, hat: p.hat, conn: p.conn }))
    };
  }
  sendLobby() { this.all(this.lobbyMsg()); }

  // What the public party list shows about this party (null = do not list). Names are already sanitised in onJoin/m_look.
  publicInfo() {
    if (this.closed || !this.public) return null;
    const list = [...this.players.values()].filter(p => !p.gone), lead = this.players.get(this.leader);
    return {
      c: this.code, ph: this.phase === 'lobby' ? 'lobby' : this.phase === 'countdown' ? 'countdown' : 'game',
      n: list.length, max: C.MAX_PLAYERS, min: this.minPlayers, ld: lead ? lead.name : '',
      p: list.map(p => [p.name, p.color, p.hat, p.conn ? 1 : 0])
    };
  }

  m_visibility(p, m) {
    if (p.id !== this.leader || (this.phase !== 'lobby' && this.phase !== 'countdown')) return;
    this.public = !!m.value;
    this.sendLobby();
  }

  m_look(p, m) {
    if (this.phase !== 'lobby' && this.phase !== 'countdown') return;
    if (m.name !== undefined) p.name = clean(m.name, 12) || p.name;
    if (m.color !== undefined) p.color = this.freeColor(m.color | 0, p);
    if (m.hat !== undefined) p.hat = Math.max(0, Math.min(BS.HATS.length - 1, m.hat | 0));
    this.sendLobby();
  }

  m_settings(p, m) {
    if (p.id !== this.leader || (this.phase !== 'lobby' && this.phase !== 'countdown')) return;
    const v = BS.cleanSetting(m.key, m.value);
    if (v === undefined) return;
    this.settings[m.key] = v;
    this.sendLobby();
  }

  m_start(p) {
    if (p.id !== this.leader || this.phase !== 'lobby') return;
    if (this.connected() < this.minPlayers) return this.send(p, { k: 'toast', text: 'Need at least ' + this.minPlayers + ' players to start.' });
    this.phase = 'countdown'; this.countdown = C.START_CD;
    this.sendLobby();
  }

  m_cancel(p) {
    if (p.id !== this.leader || this.phase !== 'countdown') return;
    this.phase = 'lobby'; this.sendLobby();
  }

  m_kick(p, m) {
    if (p.id !== this.leader || (this.phase !== 'lobby' && this.phase !== 'countdown')) return;
    const t = this.players.get(m.id | 0);
    if (!t || t === p) return;
    this.send(t, { k: 'kicked' });
    const l = t.link; t.link = null; t.conn = false;
    this.players.delete(t.id);
    if (l) setTimeout(() => { try { l.close(); } catch (e) { /* ignore */ } }, 50);
    this.resetCountdown();
    this.sendLobby();
  }

  m_again(p) {
    if (p.id !== this.leader || this.phase !== 'over') return;
    for (const q of [...this.players.values()]) if (!q.conn || q.gone) this.players.delete(q.id);
    this.G = null; this.phase = 'lobby';
    for (const q of this.players.values()) { q.role = 'crew'; q.alive = true; q.vent = -1; q.open = null; q.tasks = []; }
    this.sendLobby();
  }

  m_leave(p) {
    const l = p.link; p.link = null; p.conn = false;
    if (l) setTimeout(() => { try { l.close(); } catch (e) { /* ignore */ } }, 50);
    if (this.phase === 'lobby' || this.phase === 'countdown' || this.phase === 'over') this.removePlayer(p);
    else if (p.id === this.leader) this.closeParty('The party leader left, so the party was closed.');
    else this.dropPlayer(p);
  }

  m_chat(p, m) {
    const text = clean(m.text, 140);
    if (!text || this.time - p.chatAt < 0.35) return;
    p.chatAt = this.time;
    const inGame = !!this.G && this.phase !== 'over';
    let ghost = false;
    if (inGame) {
      if (!p.alive) ghost = true;
      else if (this.phase !== 'meeting' || !this.G.meet || this.G.meet.st === 'result') return;
    }
    this.all({ k: 'chat', from: p.id, text, ghost }, q => !ghost || !q.alive);
  }

  m_ping(p, m) { this.send(p, { k: 'pong', t: m.t }); }

  /* ------------------------------------------------------------- tick */
  tick(dt) {
    if (this.closed) return;
    this.time += dt;
    if (this.idleTimeout && this.time - this.idleCheck >= 1) {
      this.idleCheck = this.time;
      for (const p of [...this.players.values()]) {
        if (!p.conn || p.id === this.leader || this.time - p.seen <= this.idleTimeout) continue;
        const l = p.link;
        this.onLinkClose({ link: l, p });
        try { l.close(); } catch (e) { /* ignore */ }
      }
    }
    if (this.phase === 'countdown') {
      const before = Math.ceil(this.countdown);
      this.countdown -= dt;
      if (this.countdown <= 0) this.startGame();
      else if (Math.ceil(this.countdown) !== before) this.sendLobby();
    } else if (this.G) this.tickGame(dt);
  }
}

BS.Host = Host;
if (typeof module !== 'undefined') module.exports = Host;
})(typeof window !== 'undefined' ? window : globalThis);
