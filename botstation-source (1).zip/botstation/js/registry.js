/* Bot Station - the public party list ("party browser").
   There is no game server, so public parties announce themselves on a shared bulletin board: a free public MQTT broker.
     - A public party's leader keeps a *retained* message on  botstation/v1/parties/<CODE>  up to date (players, status).
       A last-will clears it if the leader's connection dies; leaving or closing the party clears it explicitly.
     - The party browser subscribes to botstation/v1/parties/+ : the broker hands over every retained message at once,
       then live changes. Searching is done locally over the player names in those messages.
   Several brokers are used at the same time (publish to all, read from all) so one outage does not hide parties.
   Under ?local the same code runs over BroadcastChannel (same-computer play and tests): no network at all.
   Entries are unauthenticated hints: joining still goes through the real party. */
(function (g) {
'use strict';
const BS = g.BS = g.BS || {}, R = BS.Registry = {};
const ROOT = 'botstation/v1/parties/';
const HEARTBEAT = 25000;      // a public party re-announces itself at least this often
const TTL = 75000;            // a listing nobody refreshed for this long is dropped (3 missed heartbeats)
const TOMB = 8000;            // after a "gone" message, ignore stragglers for this long
const PHASES = ['lobby', 'countdown', 'game'];
Object.assign(R, { ROOT, HEARTBEAT, TTL, TOMB });

// Free public brokers that speak MQTT over secure WebSockets. Point this at your own broker if you prefer:
//   BS.REGISTRY_BROKERS = [{ url: 'wss://example.com:8884/mqtt', username: '...', password: '...' }]
BS.REGISTRY_BROKERS = BS.REGISTRY_BROKERS || [
  { url: 'wss://broker.emqx.io:8084/mqtt' },
  { url: 'wss://broker.hivemq.com:8884/mqtt' }
];
R.now = () => Date.now();
R.brokers = () => {
  const search = g.location ? g.location.search : '';
  const m = /[?&]broker=([^&]+)/.exec(search);          // test hook, loopback only so a crafted link cannot redirect players
  if (m) { const urls = decodeURIComponent(m[1]).split(',').filter(u => /^wss?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(u)); if (urls.length) return urls.map(url => ({ url })); }
  if (BS.Net && BS.Net.mode() === 'local') return [{ url: 'local' }];
  return BS.REGISTRY_BROKERS;
};

/* ---------------------------------------------------------- pure helpers */
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f<>&"]/g, '').trim().slice(0, n);
const int = (v, lo, hi, d) => { v = Number(v); return Number.isFinite(v) ? Math.max(lo, Math.min(hi, Math.floor(v))) : d; };

// Turn an announcement from the wire into a safe party record (or null). Never trust what other browsers publish.
R.sanitize = (o, code) => {
  if (!o || typeof o !== 'object' || o.v !== 1 || !Array.isArray(o.p)) return null;
  const players = o.p.slice(0, 10).map(a => Array.isArray(a) ? { name: clean(a[0], 12) || '?', color: int(a[1], 0, 11, 0), hat: int(a[2], 0, 5, 0), conn: a[3] !== 0 } : null).filter(Boolean);
  if (!players.length) return null;
  const max = int(o.max, 1, 10, 10);
  return { code, q: int(o.q, 0, 1e12, 0), phase: PHASES.includes(o.ph) ? o.ph : 'game', max, min: int(o.min, 1, 10, 4), players: players.slice(0, max), leader: clean(o.ld, 12) || players[0].name };
};
R.joinable = p => p.phase !== 'game' && p.players.length < p.max;
// open parties first, then fullest first, then by code (stable order while people watch the list)
R.sort = list => list.slice().sort((a, b) => (R.joinable(b) - R.joinable(a)) || (b.players.length - a.players.length) || (a.code < b.code ? -1 : a.code > b.code ? 1 : 0));

// "alice, bob" -> ['alice','bob']
R.terms = q => String(q || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
// Does a party match the search? mode 'any': at least one term matches; 'all': every term matches.
// A term matches a player's name (substring) or the start of the party code (3+ letters). Returns which players matched.
R.match = (party, terms, mode) => {
  if (!terms.length) return { ok: true, hits: [], code: false };
  const hits = new Set(); let codeHit = false, matched = 0;
  for (const t of terms) {
    let found = false;
    party.players.forEach((p, i) => { if (p.name.toLowerCase().includes(t)) { hits.add(i); found = true; } });
    if (t.length >= 3 && party.code.toLowerCase().startsWith(t)) { codeHit = true; found = true; }
    if (found) matched++;
  }
  return { ok: mode === 'all' ? matched === terms.length : matched > 0, hits: [...hits].sort((x, y) => x - y), code: codeHit };
};
R.topicMatch = (filter, topic) => {
  const f = filter.split('/'), t = topic.split('/');
  for (let i = 0; i < f.length; i++) {
    if (f[i] === '#') return true;
    if (i >= t.length || (f[i] !== '+' && f[i] !== t[i])) return false;
  }
  return f.length === t.length;
};

/* ---------------------------------------------------------------- drivers */
// A driver is one connection to one "broker": { subscribe(filter), publish(topic, payload, retain), pulse(), close(graceful) }
// created with handlers { clientId, will, onOpen, onSub, onMessage(topic, payload, retained), onClose(reason) }.
const rid = () => Math.random().toString(36).slice(2, 10);

function mqttDriver(cfg, h) {
  const c = new BS.Mqtt.Client(cfg.url, { clientId: h.clientId, keepalive: 30, username: cfg.username, password: cfg.password, will: h.will, onOpen: h.onOpen, onSub: h.onSub, onMessage: h.onMessage, onClose: h.onClose });
  return { subscribe: f => c.subscribe(f), publish: (t, p, r) => c.publish(t, p, r), pulse: () => c.pulse(), close: gr => c.close(gr), abort: () => c.fail('abort') };
}

// Same-computer stand-in for a broker: tabs talk over BroadcastChannel, each tab remembers what it published
// with "retain" and hands it to newcomers; a closing tab clears its own entries (the last-will).
function localDriver(cfg, h) {
  const bc = new g.BroadcastChannel('bs-registry-v1'), me = rid(), mine = new Map(), subs = [];
  let dead = false;
  const post = m => { try { bc.postMessage(m); } catch (e) { /* channel closed */ } };
  const bye = () => { mine.forEach((v, t) => post({ t: 'pub', topic: t, payload: '' })); if (h.will) post({ t: 'pub', topic: h.will.topic, payload: h.will.payload || '' }); mine.clear(); };
  const hide = () => bye();
  bc.onmessage = e => {
    const m = e.data;
    if (!m || dead || (m.to && m.to !== me)) return;
    if (m.t === 'pub' && subs.some(f => R.topicMatch(f, m.topic))) h.onMessage(m.topic, m.payload, !!m.retained);
    else if (m.t === 'sub') mine.forEach((payload, topic) => post({ t: 'pub', topic, payload, retained: true, to: m.from }));
  };
  if (g.addEventListener) g.addEventListener('pagehide', hide);
  setTimeout(() => { if (!dead) h.onOpen(); }, 0);
  const stop = () => { dead = true; if (g.removeEventListener) g.removeEventListener('pagehide', hide); try { bc.close(); } catch (e) { /* ignore */ } };
  return {
    subscribe(f) { subs.push(f); post({ t: 'sub', from: me }); setTimeout(() => { if (!dead && h.onSub) h.onSub(true); }, 0); return true; },
    publish(topic, payload, retain) { if (retain) { if (payload === '') mine.delete(topic); else mine.set(topic, payload); } post({ t: 'pub', topic, payload }); return true; },
    pulse() {},
    close(graceful) { if (!graceful) bye(); stop(); },
    abort() { bye(); stop(); setTimeout(() => h.onClose('abort'), 0); }
  };
}

// One connection to one broker that reconnects by itself (1s, 2s, 4s ... 20s, with jitter).
class Conn {
  constructor(cfg, h) { this.cfg = cfg; this.h = h; this.state = 'down'; this.fails = 0; this.gen = 0; this.d = null; this.closed = false; this.timer = 0; this.connect(); }
  connect() {
    if (this.closed) return;
    const gen = ++this.gen, make = this.cfg.url === 'local' ? localDriver : mqttDriver;
    this.state = 'connecting';
    this.d = (R.driver || make)(this.cfg, {
      clientId: 'bs-' + rid() + rid(), will: this.h.will,
      onOpen: () => { if (gen !== this.gen) return; this.state = 'up'; this.fails = 0; if (this.h.filter) this.d.subscribe(this.h.filter); if (this.h.onUp) this.h.onUp(this); },
      onSub: ok => { if (gen === this.gen && this.h.onSub) this.h.onSub(this, ok); },
      onMessage: (t, p, r) => { if (gen === this.gen && this.h.onMessage) this.h.onMessage(t, p, r, this); },
      onClose: why => { if (gen !== this.gen) return; this.state = 'down'; this.fails++; this.d = null; if (this.h.onDown) this.h.onDown(this, why); this.schedule(); }
    });
  }
  schedule() { if (!this.closed) this.timer = setTimeout(() => this.connect(), Math.min(20000, 1000 * Math.pow(2, Math.min(this.fails - 1, 5))) * (0.75 + Math.random() * 0.5)); }
  retryNow() { if (!this.closed && this.state === 'down') { clearTimeout(this.timer); this.connect(); } }
  publish(t, p, r) { return this.state === 'up' && !!this.d.publish(t, p, r); }
  pulse() { if (this.state === 'up' && this.d && this.d.pulse) this.d.pulse(); }
  close(graceful) { this.closed = true; this.gen++; clearTimeout(this.timer); const d = this.d; this.d = null; this.state = 'down'; if (d) { try { d.close(graceful); } catch (e) { /* ignore */ } } }
}
R.Conn = Conn;

/* -------------------------------------------------------------- publisher */
// The party leader's side. getInfo() returns the party summary, or null when the party is private/closed.
// Call tick() often (it throttles itself): it republishes on change and as a heartbeat.
R.publish = (code, getInfo, opts) => {
  opts = opts || {};
  const topic = ROOT + code, will = { topic, payload: '', retain: true };
  let seq = 0, last = '', lastBody = '', lastPub = 0, lastCheck = 0, listed = false, closed = false, conns = [];
  // After a (re)connect announce at once, with a newer seq: a browser that just processed our old connection's
  // last-will then accepts it immediately instead of treating it as a straggler.
  const restamp = () => { const o = JSON.parse(last); o.q = ++seq; return (last = JSON.stringify(o)); };
  // Connections exist only while the party is public: a private party never talks to a broker.
  const open = () => { if (!conns.length) conns = (opts.brokers || R.brokers()).map(cfg => new Conn(cfg, { will, onUp: c => { if (last && listed) c.publish(topic, restamp(), true); } })); };
  const shut = () => { conns.forEach(c => c.close(true)); conns = []; };
  const send = payload => conns.forEach(c => c.publish(topic, payload, true));
  return {
    get conns() { return conns; },
    get listed() { return listed; },
    get seq() { return seq; },
    up: () => conns.filter(c => c.state === 'up').length,
    tick() {
      if (closed) return;
      const now = R.now();
      if (now - lastCheck < 1000) return;
      lastCheck = now;
      const info = getInfo();
      if (!info) { if (listed) { send(''); listed = false; last = lastBody = ''; } shut(); return; }
      open();
      conns.forEach(c => c.pulse());
      info.v = 1; info.q = 0;
      const body = JSON.stringify(info);
      if (body !== lastBody || now - lastPub >= HEARTBEAT) { lastBody = body; info.q = ++seq; last = JSON.stringify(info); lastPub = now; listed = true; send(last); }
    },
    close() {
      if (closed) return;
      closed = true;
      if (listed) send('');                      // clear the listing before hanging up (a clean hang-up discards the last-will)
      listed = false;
      shut();
    }
  };
};

/* ---------------------------------------------------------------- browser */
// cb.onChange(list, status) with status { state: 'connecting'|'live'|'error', up, total, ready }.
R.watch = (cb, opts) => {
  opts = opts || {};
  const entries = new Map(), tomb = new Map();
  let closed = false, ready = false, emitT = 0;
  const status = () => {
    const up = conns.filter(c => c.state === 'up').length;
    return { state: up ? 'live' : conns.every(c => c.fails > 0) ? 'error' : 'connecting', up, total: conns.length, ready: ready || (!up && conns.every(c => c.fails > 0)) };
  };
  const list = () => R.sort([...entries.values()].map(e => e.info));
  const emit = () => { if (closed || emitT) return; emitT = setTimeout(() => { emitT = 0; if (!closed) cb.onChange(list(), status()); }, 0); };
  const markReady = () => { if (!ready) { ready = true; emit(); } };
  const onMessage = (topic, payload) => {
    const code = topic.indexOf(ROOT) === 0 ? topic.slice(ROOT.length) : '';
    if (!/^[A-Z]{5}$/.test(code)) return;
    const now = R.now();
    if (payload === '') {
      const old = entries.get(code);
      if (entries.delete(code)) emit();
      tomb.set(code, { t: now, q: old ? old.info.q : Infinity });      // never seen: ignore everything for a moment (no ghosts)
      return;
    }
    let info = null;
    try { info = R.sanitize(JSON.parse(payload), code); } catch (e) { /* not ours */ }
    if (!info) return;
    const t = tomb.get(code);
    if (t && now - t.t < TOMB && info.q <= t.q) return;             // a late duplicate of what was just cleared
    const old = entries.get(code);
    if (old && info.q < old.info.q) return;                     // an older copy arriving late from the slower broker
    if (!old && entries.size >= 200) return;                    // never let junk grow without bound
    entries.set(code, { info, seen: now });
    emit();
  };
  const sweep = () => {
    const now = R.now(); let changed = false;
    for (const [c, e] of entries) if (now - e.seen > TTL) { entries.delete(c); changed = true; }
    for (const [c, t] of tomb) if (now - t.t > TOMB) tomb.delete(c);
    if (changed) emit();
  };
  const conns = (opts.brokers || R.brokers()).map(cfg => new Conn(cfg, {
    filter: ROOT + '+',
    onUp: () => emit(),
    onSub: () => setTimeout(markReady, 600),                    // give the retained burst a moment before saying "nothing here"
    onDown: () => { emit(); },
    onMessage
  }));
  const sweepT = setInterval(sweep, 3000), failT = setTimeout(markReady, 7000);
  return {
    conns, list, status, sweep,
    retry() { conns.forEach(c => c.retryNow()); emit(); },
    close() { closed = true; clearInterval(sweepT); clearTimeout(failT); clearTimeout(emitT); conns.forEach(c => c.close(true)); }
  };
};
})(typeof window !== 'undefined' ? window : globalThis);
