/* Bot Station - gameplay client: input, movement, context actions, HUD, render loop, boot. */
(function (g) {
'use strict';
const BS = g.BS, C = BS.C, App = BS.App, S = App.S, UI = BS.UI, R = BS.R, el = BS.el, $ = UI.$, col = UI.col;
const cv = $('cv'), ctx = cv.getContext('2d'), fog = document.createElement('canvas'), fctx = fog.getContext('2d');
let W = 0, H = 0, DPR = 1;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function resize() {
  DPR = Math.min(2, g.devicePixelRatio || 1); W = g.innerWidth; H = g.innerHeight;
  cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR); cv.style.width = W + 'px'; cv.style.height = H + 'px';
  fog.width = W; fog.height = H;
}
g.addEventListener('resize', resize); resize();

/* ------------------------------------------------------------------ input */
const keys = {};
const typing = e => e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName);
g.addEventListener('keydown', e => {
  if (typing(e)) return;
  const k = e.key.toLowerCase(); keys[k] = true;
  if (!S.inGame) return;
  if (k === 'escape') return App.closeOverlays();
  if (S.phase !== 'play') return;
  if (k === 'enter' && !S.alive && App.ghostChat) { App.ghostChat.input.focus(); e.preventDefault(); return; }
  if ((k === 'e' || k === ' ') && !S.panel) App.doUse();
  else if (k === 'q') App.doKill();
  else if (k === 'r') App.doReport();
  else if (k === 'v') App.doVent();
  else if (k === 'x') App.doSab();
  else if (k === 'm' || k === 'tab') App.toggleMap();
  if (k === ' ' || k === 'tab' || k.startsWith('arrow')) e.preventDefault();
});
g.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });
g.addEventListener('blur', () => { for (const k in keys) keys[k] = false; S.ptr = null; });
cv.addEventListener('contextmenu', e => e.preventDefault());
cv.addEventListener('pointerdown', e => { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); if (!S.inGame) return; S.ptr = { ox: e.clientX, oy: e.clientY, x: e.clientX, y: e.clientY }; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } });
cv.addEventListener('pointermove', e => { if (S.ptr) { S.ptr.x = e.clientX; S.ptr.y = e.clientY; } });
['pointerup', 'pointercancel'].forEach(t => cv.addEventListener(t, () => { S.ptr = null; }));

function inputDir() {
  let dx = 0, dy = 0;
  if (keys.a || keys.arrowleft) dx -= 1; if (keys.d || keys.arrowright) dx += 1;
  if (keys.w || keys.arrowup) dy -= 1; if (keys.s || keys.arrowdown) dy += 1;
  if (S.ptr) { const ax = S.ptr.x - S.ptr.ox, ay = S.ptr.y - S.ptr.oy, d = Math.hypot(ax, ay); if (d > 14) { const m = Math.min(1, d / 60); dx = ax / d * m; dy = ay / d * m; } }
  const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
  return [dx, dy];
}

/* ------------------------------------------------- what is near me (HUD) */
function findUse() {
  let best = null, bd = 1e9;
  const consider = (st, o) => { const s = BS.ST[st], d = Math.hypot(s.x - S.x, s.y - S.y); if (d <= C.USE_RANGE && d < bd) { bd = d; best = Object.assign({ st }, o); } };
  const comms = S.sab && S.sab.k === 'comms';
  if (S.alive) {
    if (S.sab) {
      if (S.sab.k === 'reactor') { consider('melt_a', { type: 'hold', label: 'STABILIZE' }); consider('melt_b', { type: 'hold', label: 'STABILIZE' }); }
      else if (S.sab.k === 'lights') consider('lights_panel', { type: 'fix', s: 'lights', label: 'FIX LIGHTS' });
      else consider('comms_panel', { type: 'fix', s: 'comms', label: 'FIX COMMS' });
    }
    consider('button', { type: 'button', label: 'EMERGENCY', off: S.emerg <= 0 || S.ecd > 0 || !!S.sab });
    consider('admin', { type: 'admin', label: 'ADMIN' });
  }
  if (!comms) S.tasks.forEach(tk => {
    const def = BS.TASKS.find(d => d.id === tk.id);
    def.steps.forEach((step, i) => {
      if (tk.done[i] || (def.ordered && tk.done.slice(0, i).some(d => !d))) return;
      consider(step.st, { type: 'task', task: tk.id, step: i, game: step.game, params: step.p, label: 'USE', title: def.name, hint: step.label || '', fake: tk.fake });
    });
  });
  return best;
}
function nearby() {
  const r = { use: null, body: null, victim: null, vent: -1 };
  if (S.phase !== 'play' || S.vent >= 0) return r;
  if (S.alive || S.role === 'crew') r.use = findUse();
  if (S.alive) {
    let bd = C.REPORT_RANGE; for (const b of S.bodies) { const d = Math.hypot(b[1] - S.x, b[2] - S.y); if (d <= bd) { bd = d; r.body = b; } }
    if (S.role === 'imp') {
      bd = C.KILL_RANGE; for (const o of S.others.values()) { if (o.ghost || o.mate) continue; const d = Math.hypot(o.x - S.x, o.y - S.y); if (d <= bd) { bd = d; r.victim = o; } }
      bd = C.VENT_RANGE; for (const v of BS.VENTS) { const d = Math.hypot(v.x - S.x, v.y - S.y); if (d <= bd) { bd = d; r.vent = v.id; } }
    }
  }
  return r;
}

/* ---------------------------------------------------------------- actions */
function closePanel(done) {
  if (S.panel) { try { S.panel.ctrl.destroy(); } catch (e) { /* ignore */ } if (!done) App.send({ k: 'close' }); }
  S.panel = null; UI.closePanel();
}
App.closeOverlays = () => { closePanel(false); UI.closeMap(); S.overlay = null; clearInterval(S.adminT); };

function openTask(u) {
  App.send({ k: 'open', st: u.st });
  const fix = u.type === 'fix', st = BS.ST[u.st];
  const box = UI.panel((fix ? (u.s === 'lights' ? 'Lighting Breaker' : 'Dish Controls') : u.title) + ' — ' + st.n, fix ? 'Repair the system for everyone.' : u.hint, () => closePanel(false));
  S.panel = { st: u.st, task: !fix, ctrl: BS.Mini.open(box, fix ? (u.s === 'lights' ? 'switches' : 'code') : u.game, fix ? null : u.params, () => {
    if (fix) App.send({ k: 'done', fix: u.s }); else if (!u.fake) App.send({ k: 'done', task: u.task, step: u.step });
    closePanel(true);
  }) };
}

function openReactor(st) {
  App.send({ k: 'open', st });
  const box = UI.panel(BS.ST[st].n, 'Hold the button. A teammate must hold the other Core Console at the same time!', () => closePanel(false));
  const info = el('div', 'mg-disp', '', box), btn = el('button', 'btn big holdbtn', 'HOLD', box);
  let held = false;
  const set = on => { if (held !== on) { held = on; App.send({ k: 'hold', st, on }); btn.classList.toggle('on', on); } };
  btn.onpointerdown = e => { e.preventDefault(); set(true); }; btn.onpointerup = btn.onpointerleave = () => set(false);
  const kd = e => { if (e.code === 'Space') { e.preventDefault(); set(true); } }, ku = e => { if (e.code === 'Space') set(false); };
  g.addEventListener('keydown', kd); g.addEventListener('keyup', ku);
  const t = setInterval(() => {
    if (!S.sab || S.sab.k !== 'reactor') return closePanel(true);
    const h = S.sab.h || [0, 0]; info.textContent = 'Reactor Core: ' + (h[0] ? 'HELD' : 'waiting') + '   |   Engine Bay: ' + (h[1] ? 'HELD' : 'waiting') + '   |   ' + S.sab.left + 's left';
  }, 150);
  S.panel = { st, ctrl: { destroy() { set(false); clearInterval(t); g.removeEventListener('keydown', kd); g.removeEventListener('keyup', ku); } } };
}

function openAdmin() {
  S.overlay = 'admin'; S.admin = null; UI.map(App, 'admin'); App.send({ k: 'admin' });
  clearInterval(S.adminT); S.adminT = setInterval(() => App.send({ k: 'admin' }), 1000);
}

App.doUse = () => {
  if (S.phase !== 'play' || S.panel || S.overlay || S.vent >= 0) return;
  const u = findUse();
  if (!u) return;
  if (u.off) return UI.toast(S.sab ? 'You cannot call a meeting during a sabotage.' : S.emerg <= 0 ? 'No emergency meetings left.' : 'The emergency button is recharging…');
  if (u.type === 'button') return App.send({ k: 'button' });
  if (u.type === 'admin') return openAdmin();
  if (u.type === 'hold') return openReactor(u.st);
  openTask(u);
};
App.doKill = () => { const n = nearby(); if (S.role === 'imp' && S.alive && n.victim && S.kcd <= 0 && S.phase === 'play') { App.send({ k: 'kill', t: n.victim.id }); S.kcd = S.set.killCd; } };
App.doReport = () => { const n = nearby(); if (n.body && S.phase === 'play') App.send({ k: 'report' }); };
App.doVent = () => {
  if (S.role !== 'imp' || !S.alive || S.phase !== 'play') return;
  if (S.vent >= 0) return App.send({ k: 'vent', to: -1 });
  if (nearby().vent >= 0) App.send({ k: 'vent' });
};
App.doSab = () => { if (S.role !== 'imp' || S.phase !== 'play' || S.panel) return; S.overlay = 'sab'; UI.map(App, 'sab'); };
App.toggleMap = () => { if (S.panel) return; if (S.overlay === 'map') return App.closeOverlays(); App.closeOverlays(); S.overlay = 'map'; UI.map(App, 'map'); };

App.renderVentBar = () => {
  const bar = $('ventbar'); bar.innerHTML = '';
  if (S.vent < 0) return;
  el('span', null, 'In the vents — ', bar);
  BS.VENTS[S.vent].links.forEach(id => { const v = BS.VENTS[id], b = el('button', 'btn', '→ ' + BS.ROOMS[BS.roomAt(v.x, v.y)].name, bar); b.onclick = () => App.send({ k: 'vent', to: id }); });
  el('button', 'btn danger', 'Exit vent', bar).onclick = () => App.send({ k: 'vent', to: -1 });
};

/* -------------------------------------------------------------------- HUD */
const txt = (e, t) => { if (e._t !== t) { e._t = t; e.textContent = t; } };
const vis = (e, on) => { if (e._v !== on) { e._v = on; e.classList.toggle('hidden', !on); } };
const dis = (e, d) => { if (e._d !== d) { e._d = d; e.disabled = d; } };
function buildHud() {
  const b = $('btns');
  const mk = (id, label, fn) => { const x = el('button', 'hbtn', label, b); x.id = id; x.onclick = fn; return x; };
  mk('bSab', 'SABOTAGE', App.doSab); mk('bVent', 'VENT', App.doVent); mk('bKill', 'ELIMINATE', App.doKill);
  mk('bReport', 'REPORT', App.doReport); mk('bUse', 'USE', App.doUse); mk('bMap', 'MAP', App.toggleMap);
  const gc = $('ghostchat'); App.ghostChat = UI.chatBox(gc, t => App.send({ k: 'chat', text: t }), { cls: 'ghostbox', blurOnSend: true, placeholder: 'Ghost chat — press Enter to type (only ghosts see this)…' });
  const mute = el('button', 'hbtn small', '🔊', $('btns')); mute.title = 'Mute / unmute'; mute.onclick = () => { BS.Sfx.muted = !BS.Sfx.muted; mute.textContent = BS.Sfx.muted ? '🔇' : '🔊'; };
}
function updateHud() {
  const n = nearby(), play = S.phase === 'play', imp = S.role === 'imp', inVent = S.vent >= 0;
  vis($('bUse'), play && !inVent && (S.alive || S.role === 'crew')); const u = n.use;
  txt($('bUse'), u ? u.label : 'USE'); dis($('bUse'), !u || !!u.off);
  vis($('bReport'), play && S.alive && !inVent); dis($('bReport'), !n.body);
  vis($('bKill'), play && imp && S.alive && !inVent); dis($('bKill'), !n.victim || S.kcd > 0); txt($('bKill'), S.kcd > 0 ? 'ELIMINATE ' + Math.ceil(S.kcd) : 'ELIMINATE');
  vis($('bVent'), play && imp && S.alive); txt($('bVent'), inVent ? 'EXIT' : 'VENT'); dis($('bVent'), !inVent && n.vent < 0);
  vis($('bSab'), play && imp); vis($('bMap'), play && !inVent);
  vis($('ventbar'), play && inVent);
  vis($('ghostchat'), !S.alive && play);
  $('hud').classList.toggle('dead', !S.alive);
}

/* ---------------------------------------------------------------- update */
function update(dt, now) {
  for (const k of ['kcd', 'scd', 'dcd', 'ecd']) S[k] = Math.max(0, S[k] - dt);
  const k = Math.min(1, dt * 14);
  for (const o of S.others.values()) { o.x += (o.tx - o.x) * k; o.y += (o.ty - o.y) * k; }
  S.moving = false;
  if (S.phase === 'play' && S.vent < 0 && !S.panel && !S.overlay) {
    const d = inputDir();
    if (d[0] || d[1]) {
      const sp = C.SPEED * S.set.speed * (S.alive ? 1 : C.GHOST_MULT) * dt;
      if (S.alive) { const p = BS.move(S.x, S.y, d[0] * sp, d[1] * sp, S.doors); S.x = p[0]; S.y = p[1]; }
      else { S.x = clamp(S.x + d[0] * sp, 20, C.W - 20); S.y = clamp(S.y + d[1] * sp, 20, C.H - 20); }
      S.moving = true; if (Math.abs(d[0]) > 0.1) S.face = d[0] > 0 ? 1 : -1;
    }
  }
  if (S.moving) S.needSend = true;
  if (S.needSend && S.phase === 'play' && now - (S.lastSend || 0) > 50) {
    App.send({ k: 'pos', x: Math.round(S.x * 10) / 10, y: Math.round(S.y * 10) / 10, f: S.face < 0 ? 1 : 0, m: S.moving ? 1 : 0 }); S.lastSend = now; S.needSend = S.moving;
  }
  if (S.panel && S.panel.st) { const s = BS.ST[S.panel.st]; if (Math.hypot(s.x - S.x, s.y - S.y) > C.USE_RANGE + 40) closePanel(false); }
}

/* ------------------------------------------------------------------ draw */
const MENU = { stars: Array.from({ length: 120 }, () => ({ x: Math.random(), y: Math.random(), s: Math.random() * 2 + 0.4, v: Math.random() * 0.5 + 0.1 })),
  bots: Array.from({ length: 7 }, (_, i) => ({ c: BS.COLORS[(i * 5) % 12][1], hat: i % 6, x: Math.random(), y: Math.random(), vx: (Math.random() - 0.5) * 0.02, vy: (Math.random() - 0.5) * 0.015, r: Math.random() * 6, s: 1.4 + Math.random() })) };
function drawMenu(t) {
  const gr = ctx.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#0a0f24'); gr.addColorStop(1, '#14102b'); ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#fff'; MENU.stars.forEach(s => { ctx.globalAlpha = 0.35 + s.s / 4; ctx.fillRect(((s.x - t * s.v * 0.02) % 1 + 1) % 1 * W, s.y * H, s.s, s.s); }); ctx.globalAlpha = 1;
  MENU.bots.forEach(b => { const x = ((b.x + t * b.vx) % 1 + 1) % 1 * W, y = ((b.y + t * b.vy) % 1 + 1) % 1 * H; ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(t * 0.4 + b.r) * 0.5 + b.r); ctx.scale(b.s, b.s); ctx.globalAlpha = 0.5; R.drawBot(ctx, 0, 0, { color: b.c, hat: b.hat, t }); ctx.restore(); });
}
let polyKey = '', poly = null;
function draw(now) {
  const t = now / 1000;
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  if (!S.inGame) return drawMenu(t);
  ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
  const sc = Math.max(0.55, Math.min(1.5, Math.min(W / 1000, H / 620))), hw = W / 2 / sc, hh = H / 2 / sc;
  const cam = { x: hw * 2 >= C.W ? C.W / 2 : clamp(S.x, hw, C.W - hw), y: hh * 2 >= C.H ? C.H / 2 : clamp(S.y, hh, C.H - hh), s: sc };
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.scale(sc, sc); ctx.translate(-cam.x, -cam.y);
  R.drawWorld(ctx, S, t);
  S.bodies.forEach(b => R.drawBody(ctx, b[1], b[2], col((S.players.get(b[0]) || {}).color | 0)));
  const list = [];
  S.others.forEach(o => list.push([o.y, () => {
    const p = S.players.get(o.id) || {};
    if (o.visual) { ctx.strokeStyle = 'rgba(74,222,128,' + (0.5 + Math.sin(t * 8) * 0.4) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(o.x, o.y, 24, 0, 7); ctx.stroke(); }
    R.drawBot(ctx, o.x, o.y, { color: col(p.color | 0), hat: p.hat, face: o.face, moving: o.moving && Math.hypot(o.tx - o.x, o.ty - o.y) > 1, ghost: o.ghost, name: p.name, nameColor: o.mate ? '#ff6b6b' : '#fff', t, seed: o.id });
  }]));
  if (S.vent < 0) list.push([S.y, () => R.drawBot(ctx, S.x, S.y, { color: col(S.color), hat: S.hat, face: S.face, moving: S.moving, ghost: !S.alive, name: S.name, nameColor: S.role === 'imp' ? '#ff6b6b' : '#fff', t, seed: S.id })]);
  list.sort((a, b) => a[0] - b[0]).forEach(l => l[1]());
  if (S.vent >= 0) { ctx.strokeStyle = 'rgba(255,255,255,' + (0.5 + Math.sin(t * 6) * 0.3) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(S.x, S.y, 22, 14, 0, 0, 7); ctx.stroke(); }
  S.fx = S.fx.filter(e => R.drawEffect(ctx, e, now));
  ctx.restore();
  if (S.alive) {
    const lights = !!(S.sab && S.sab.k === 'lights'), rad = BS.visionOf(S.role, true, S.set, lights) * 1.0;
    const key = Math.round(S.x / 3) + ',' + Math.round(S.y / 3) + ',' + Math.round(rad) + ',' + [...S.doors].join('.');
    if (key !== polyKey) { polyKey = key; poly = BS.visionPoly(S.x, S.y, rad, S.doors, 110); }
    R.drawFog(ctx, fctx, W, H, cam, S, rad, poly);
  }
  if (S.sab && S.sab.k === 'reactor') { ctx.fillStyle = 'rgba(255,0,0,' + (0.05 + 0.07 * (Math.sin(t * 6) + 1) / 2) + ')'; ctx.fillRect(0, 0, W, H); }
  if (S.ptr && S.phase === 'play') {
    ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(S.ptr.ox, S.ptr.oy, 46, 0, 7); ctx.stroke();
    const ax = S.ptr.x - S.ptr.ox, ay = S.ptr.y - S.ptr.oy, d = Math.min(46, Math.hypot(ax, ay)), a = Math.atan2(ay, ax);
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.arc(S.ptr.ox + Math.cos(a) * d, S.ptr.oy + Math.sin(a) * d, 18, 0, 7); ctx.fill();
  }
}

/* ------------------------------------------------------------------- boot */
UI.buildTitle(App); UI.buildLobby(App); UI.buildBrowser(App); buildHud(); UI.screen('title');
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (S.inGame) { update(dt, now); updateHud(); }
  draw(now);
}
requestAnimationFrame(frame);
App.tryResume();
g.__BS = { S, App };      // handy for debugging and automated tests
})(window);
