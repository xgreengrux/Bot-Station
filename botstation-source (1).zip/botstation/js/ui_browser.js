/* Bot Station - the party browser screen: a live list of public parties, a name search, and Join buttons. */
(function (g) {
'use strict';
const BS = g.BS, UI = BS.UI, R = BS.Registry, $ = UI.$, el = BS.el, col = UI.col;
const PAGE = 40;                                              // rows drawn at once; "Show more" reveals the rest
const view = UI.bw = { q: '', mode: 'any', built: false, limit: PAGE, cache: new Map() };

UI.buildBrowser = app => {
  const root = $('browser'); root.innerHTML = ''; view.built = true; view.cache = new Map(); view.limit = PAGE;
  const card = el('div', 'card bw-card', null, root);
  const head = el('div', 'bw-head', null, card);
  const back = el('button', 'btn', '← Back', head); back.id = 'bwBack'; back.onclick = () => app.leaveBrowser();
  el('h2', null, 'Find a party', head);
  el('span', 'bw-live', '', head).id = 'bwLive';

  const who = el('label', 'bw-who', null, card); el('span', null, 'Your name', who);
  const nm = el('input', 'inp', null, who); nm.id = 'bwName'; nm.maxLength = 12; nm.placeholder = 'Pick a name to join';
  nm.addEventListener('input', () => nm.classList.remove('bad'));
  nm.addEventListener('change', () => { if (nm.value.trim()) UI.store.set('bs-name', nm.value.trim()); });
  el('div', 'msg', '', card).id = 'bwMsg';

  const sr = el('div', 'bw-search', null, card), box = el('div', 'bw-box', null, sr);
  const q = el('input', 'inp', null, box); q.id = 'bwQuery'; q.placeholder = 'Search players or party code…'; q.autocomplete = 'off'; q.spellcheck = false; q.value = view.q;
  q.setAttribute('aria-label', 'Search for players or a party code');
  const clr = el('button', 'bw-clear', '✕', box); clr.id = 'bwClear'; clr.title = 'Clear search'; clr.type = 'button'; clr.setAttribute('aria-label', 'Clear search');
  const research = () => { view.limit = PAGE; UI.updateBrowser(app); };
  q.oninput = () => { view.q = q.value; research(); };
  q.addEventListener('keydown', e => { if (e.key === 'Escape') { q.value = view.q = ''; research(); } });
  clr.onclick = () => { q.value = view.q = ''; q.focus(); research(); };
  const seg = el('div', 'seg', null, sr); seg.title = 'With several names: find parties with any of them, or with all of them';
  [['any', 'Any name'], ['all', 'All names']].forEach(([k, t]) => { const b = el('button', 'seg-b', t, seg); b.dataset.mode = k; b.type = 'button'; b.onclick = () => { view.mode = k; research(); }; });
  el('div', 'bw-hint', 'Looking for friends? Type their names, separated by commas. Private parties are never listed.', card);

  el('div', 'bw-list', null, card).id = 'bwList';
  const foot = el('div', 'bw-foot', null, card);
  el('span', 'bw-count', '', foot).id = 'bwCount';
  const mk = el('button', 'btn', 'Create a party instead', foot); mk.onclick = () => { app.leaveBrowser(); const t = $('tName'); if (t) t.focus(); };
};

UI.browserStatus = (m, err) => { const e = $('bwMsg'); if (!e) return; e.textContent = m || ''; e.className = 'msg' + (err ? ' err' : ''); };
UI.browserBusy = b => { const r = $('browser'); if (r) r.classList.toggle('busy', !!b); const n = $('bwName'); if (n) n.disabled = !!b; };

UI.openBrowser = (app, msg) => {
  if (!view.built || !$('bwList')) UI.buildBrowser(app);
  const nm = $('bwName'); if (!nm.value) nm.value = UI.store.get('bs-name');
  UI.browserBusy(false); UI.browserStatus(msg || '', !!msg);
  UI.updateBrowser(app);
  if (g.matchMedia && g.matchMedia('(pointer:fine)').matches) $('bwQuery').focus();
};

// a name chip for each player, the ones that match the search emphasised
const chip = (p, hit, parent) => {
  const c = el('span', 'chip' + (hit ? ' hit' : '') + (p.conn ? '' : ' off'), null, parent);
  c.appendChild(BS.R.icon(col(p.color), p.hat, 26)); el('span', null, p.name, c);
  return c;
};

const rowEl = (app, p, m, open, full) => {
  const row = el('div', 'bparty' + (open ? '' : ' closed'), null); row.dataset.code = p.code;
  el('div', 'bp-code' + (m.code ? ' hit' : ''), p.code, row);
  const main = el('div', 'bp-main', null, row), top = el('div', 'bp-top', null, main);
  el('span', 'bp-leader', '👑 ' + p.leader, top);
  el('span', 'pill pl-' + (full ? 'full' : p.phase), (full ? 'Full' : p.phase === 'game' ? 'In game' : p.phase === 'countdown' ? 'Starting…' : 'In lobby') + ' · ' + p.players.length + '/' + p.max, top);
  const pl = el('div', 'bp-players', null, main); p.players.forEach((x, i) => chip(x, m.hits.indexOf(i) >= 0, pl));
  const act = el('div', 'bp-act', null, row), b = el('button', 'btn' + (open ? ' primary' : ''), open ? 'Join' : full ? 'Full' : 'In game', act);
  b.disabled = !open; b.title = open ? 'Join party ' + p.code : full ? 'This party is full' : 'A game is already in progress';
  b.onclick = () => {
    const nm = $('bwName'), name = nm.value.trim();
    if (!name) { nm.classList.add('bad'); nm.focus(); return UI.browserStatus('Pick a name first.', true); }
    UI.store.set('bs-name', name); UI.browserStatus('');
    app.joinFromBrowser(p.code, name);
  };
  return row;
};

UI.updateBrowser = app => {
  const S = app.S, list = $('bwList'); if (!list || S.screen !== 'browser') return;
  const { list: all, st } = S.browse, terms = R.terms(view.q), filtering = terms.length > 0;
  $('bwQuery').value !== view.q && ($('bwQuery').value = view.q);
  $('bwClear').classList.toggle('hidden', !view.q);
  document.querySelectorAll('#browser .seg-b').forEach(b => b.classList.toggle('on', b.dataset.mode === view.mode));

  const live = $('bwLive');
  if (st.state === 'live') { live.textContent = '● Live'; live.className = 'bw-live on'; live.title = 'Connected to the party list'; }
  else if (st.state === 'error') { live.textContent = '● Offline'; live.className = 'bw-live off'; live.title = 'Could not reach the party list'; }
  else { live.textContent = '● Connecting…'; live.className = 'bw-live'; live.title = ''; }

  const rows = all.map(p => ({ p, m: R.match(p, terms, view.mode) })).filter(x => x.m.ok), shown = rows.slice(0, view.limit);

  // The registry reports again on every heartbeat, so only rows whose content changed are rebuilt: a row the
  // pointer is pressing on must not be swapped out from under it (that would swallow the click).
  const slot = (key, sig, build) => { let n = view.cache.get(key); if (!n || n.sig !== sig) { n = { sig, el: build() }; view.cache.set(key, n); } return n.el; };
  const want = [];
  shown.forEach(({ p, m }) => {
    const open = R.joinable(p), full = p.phase !== 'game' && p.players.length >= p.max;
    const sig = [p.leader, p.phase, p.max, open, full, m.code, m.hits.join(), p.players.map(x => [x.name, x.color, x.hat, x.conn].join('\u0001')).join('\u0002')].join('\u0003');
    want.push([ 'p:' + p.code, slot('p:' + p.code, sig, () => rowEl(app, p, m, open, full)) ]);
  });
  if (!rows.length) {
    const sig = [filtering, all.length, st.state, st.ready, view.q.trim()].join('\u0003');
    want.push([ 'empty', slot('empty', sig, () => {
      const e = el('div', 'bw-empty', null);
      if (filtering && all.length) {
        el('b', null, 'No public party matches “' + view.q.trim() + '”.', e);
        el('span', null, all.length + ' public ' + (all.length === 1 ? 'party is' : 'parties are') + ' hidden by your search.', e);
        const c = el('button', 'btn', 'Clear search', e); c.onclick = () => { view.q = ''; view.limit = PAGE; UI.updateBrowser(app); };
      } else if (st.state === 'error') {
        el('b', null, 'Can’t reach the party list right now.', e);
        el('span', null, 'You can still join a friend with their party code. We keep retrying in the background.', e);
        const r = el('button', 'btn', 'Try again', e); r.onclick = () => app.retryBrowser();
      } else if (!st.ready) el('span', null, 'Looking for parties…', e);
      else { el('b', null, 'No public parties right now.', e); el('span', null, 'Be the first: create a party and it will show up here for everyone.', e); }
      return e;
    }) ]);
  } else if (rows.length > shown.length) {
    const left = rows.length - shown.length;
    want.push([ 'more', slot('more', String(left), () => { const b = el('button', 'btn bw-more', 'Show ' + Math.min(left, PAGE) + ' more' + (left > PAGE ? ' (' + left + ' hidden)' : ''), null); b.onclick = () => { view.limit += PAGE; UI.updateBrowser(app); }; return b; }) ]);
  }
  for (const k of [...view.cache.keys()]) if (!want.some(w => w[0] === k)) view.cache.delete(k);
  let cur = list.firstChild;                                  // put the elements in order, touching only what differs
  want.forEach(w => { if (w[1] === cur) cur = cur.nextSibling; else list.insertBefore(w[1], cur); });
  while (cur) { const nx = cur.nextSibling; list.removeChild(cur); cur = nx; }

  const players = all.reduce((n, p) => n + p.players.length, 0);
  $('bwCount').textContent = st.ready || all.length ? (filtering ? rows.length + ' of ' : '') + all.length + ' public ' + (all.length === 1 ? 'party' : 'parties') + ' · ' + players + ' ' + (players === 1 ? 'player' : 'players') : '';
};
})(window);
