/* Bot Station - shared map, rules and geometry (used by the host simulation and every client) */
(function (g) {
'use strict';
const BS = g.BS = g.BS || {};

const C = BS.C = {
  W: 1740, H: 1480,
  PR: 13,                 // player radius
  SPEED: 175,             // px / second at 1.0x
  GHOST_MULT: 1.2,
  KILL_RANGE: 66, USE_RANGE: 58, REPORT_RANGE: 100, VENT_RANGE: 50,
  VISION: 330, LIGHTS_MULT: 0.25,
  DOOR_W: 16, DOOR_TIME: 10, DOOR_CD: 30,
  REACTOR_TIME: 45,
  MIN_PLAYERS: 4, MAX_PLAYERS: 10,
  GRACE: 25,              // seconds a dropped player may reconnect mid-game
  START_CD: 5             // lobby countdown before a game starts
};

BS.COLORS = [
  ['Red', '#e5484d'], ['Blue', '#3e63dd'], ['Green', '#30a46c'], ['Pink', '#e93d82'],
  ['Orange', '#f76b15'], ['Yellow', '#f5d90a'], ['Black', '#3b3f4a'], ['White', '#e8ebf0'],
  ['Purple', '#8e4ec6'], ['Cyan', '#05a2c2'], ['Lime', '#99d52a'], ['Brown', '#a2724e']
];
BS.HATS = ['None', 'Antenna', 'Twin antennae', 'Propeller', 'Halo', 'Cap'];

/* ------------------------------------------------------------------ map */
BS.ROOMS = [
  { id: 0, name: 'Engine Bay',   x: 80,   y: 80,   w: 400, h: 320, c: '#2c3347' },
  { id: 1, name: 'Greenhouse',   x: 640,  y: 80,   w: 460, h: 320, c: '#283b36' },
  { id: 2, name: 'Reactor Core', x: 1260, y: 80,   w: 400, h: 320, c: '#3b2c35' },
  { id: 3, name: 'Sickbay',      x: 80,   y: 560,  w: 400, h: 360, c: '#2b3b44' },
  { id: 4, name: 'Hub',          x: 640,  y: 560,  w: 460, h: 360, c: '#2e3249' },
  { id: 5, name: 'Bridge',       x: 1260, y: 560,  w: 400, h: 360, c: '#2a2f4e' },
  { id: 6, name: 'Cargo Hold',   x: 80,   y: 1080, w: 400, h: 320, c: '#38342a' },
  { id: 7, name: 'Power Room',   x: 640,  y: 1080, w: 460, h: 320, c: '#39382a' },
  { id: 8, name: 'Comms Deck',   x: 1260, y: 1080, w: 400, h: 320, c: '#2a393d' }
];
// a = left/top room, b = right/bottom room
BS.HALLS = [
  { a: 0, b: 1, x: 480,  y: 195,  w: 160, h: 90 },
  { a: 1, b: 2, x: 1100, y: 195,  w: 160, h: 90 },
  { a: 3, b: 4, x: 480,  y: 695,  w: 160, h: 90 },
  { a: 4, b: 5, x: 1100, y: 695,  w: 160, h: 90 },
  { a: 6, b: 7, x: 480,  y: 1195, w: 160, h: 90 },
  { a: 1, b: 4, x: 825,  y: 400,  w: 90,  h: 160 },
  { a: 4, b: 7, x: 825,  y: 920,  w: 90,  h: 160 },
  { a: 2, b: 5, x: 1415, y: 400,  w: 90,  h: 160 },
  { a: 5, b: 8, x: 1415, y: 920,  w: 90,  h: 160 },
  { a: 3, b: 6, x: 235,  y: 920,  w: 90,  h: 160 }
];
BS.OBS = [
  { x: 150,  y: 150,  w: 110, h: 70,  k: 'machine' }, { x: 330,  y: 250,  w: 100, h: 60,  k: 'machine' },
  { x: 700,  y: 140,  w: 140, h: 48,  k: 'planter' }, { x: 900,  y: 290,  w: 140, h: 48,  k: 'planter' },
  { x: 1380, y: 180,  w: 160, h: 100, k: 'core' },
  { x: 130,  y: 610,  w: 110, h: 50,  k: 'bed' },     { x: 340,  y: 830,  w: 110, h: 50,  k: 'bed' },
  { x: 790,  y: 690,  w: 160, h: 100, k: 'table' },
  { x: 1360, y: 600,  w: 120, h: 40,  k: 'console' }, { x: 1450, y: 800,  w: 120, h: 50,  k: 'console' },
  { x: 150,  y: 1130, w: 90,  h: 70,  k: 'crate' },   { x: 330,  y: 1270, w: 90,  h: 80,  k: 'crate' },
  { x: 720,  y: 1140, w: 70,  h: 150, k: 'generator' },
  { x: 1380, y: 1180, w: 160, h: 50,  k: 'bank' }
];

/* Interaction points. t = type used for drawing. */
const ST = BS.ST = {
  wire_engine:      { x: 120,  y: 350,  n: 'Wiring Panel' },
  align_engine:     { x: 440,  y: 140,  n: 'Thruster Console' },
  fuel_engine:      { x: 260,  y: 350,  n: 'Generator Intake' },
  melt_b:           { x: 440,  y: 350,  n: 'Core Console B' },
  filter_green:     { x: 1050, y: 130,  n: 'Air Filter' },
  trash_green:      { x: 680,  y: 350,  n: 'Waste Chute' },
  melt_a:           { x: 1300, y: 350,  n: 'Core Console A' },
  reboot_reactor:   { x: 1610, y: 130,  n: 'Reactor Terminal' },
  wire_sick:        { x: 440,  y: 610,  n: 'Wiring Panel' },
  scan_sick:        { x: 130,  y: 880,  n: 'Scanner Bed' },
  button:           { x: 870,  y: 812,  n: 'Emergency Button' },
  admin:            { x: 700,  y: 610,  n: 'Admin Table' },
  data_hub:         { x: 1050, y: 880,  n: 'Data Terminal' },
  code_bridge:      { x: 1620, y: 740,  n: 'Door Keypad' },
  asteroid_bridge:  { x: 1610, y: 610,  n: 'Defense Console' },
  calibrate_bridge: { x: 1300, y: 880,  n: 'Scanner Array' },
  divert_bridge:    { x: 1305, y: 605,  n: 'Power Relay' },
  fuel_cargo:       { x: 440,  y: 1130, n: 'Fuel Depot' },
  trash_cargo:      { x: 120,  y: 1360, n: 'Waste Chute' },
  wire_power:       { x: 680,  y: 1360, n: 'Wiring Panel' },
  panels_power:     { x: 900,  y: 1350, n: 'Shield Panels' },
  lights_panel:     { x: 1050, y: 1350, n: 'Lighting Breaker' },
  divert_power:     { x: 1050, y: 1130, n: 'Power Switchboard' },
  comms_panel:      { x: 1610, y: 1350, n: 'Dish Controls' },
  calibrate_comms:  { x: 1300, y: 1350, n: 'Receiver' },
  upload_comms:     { x: 1450, y: 1350, n: 'Upload Terminal' }
};

BS.VENTS = [
  { x: 115,  y: 115 },  { x: 300,  y: 600 },  { x: 445,  y: 1365 },   // 0-2  west chain
  { x: 1620, y: 240 },  { x: 1620, y: 880 },  { x: 1300, y: 1130 },   // 3-5  east chain
  { x: 1060, y: 370 },  { x: 1060, y: 1240 }                          // 6-7  centre pair
];
const VENT_LINKS = [[0, 1], [1, 2], [3, 4], [4, 5], [6, 7]];
BS.VENTS.forEach((v, i) => { v.id = i; v.links = []; });
VENT_LINKS.forEach(([a, b]) => { BS.VENTS[a].links.push(b); BS.VENTS[b].links.push(a); });

/* Door slabs at both ends of every hallway. Locking a room closes the slab at that room's mouth. */
BS.DOORS = [];
BS.ROOM_DOORS = BS.ROOMS.map(() => []);
BS.HALLS.forEach((h, hi) => {
  const horiz = h.w > h.h, W = C.DOOR_W;
  const mk = (room, atEnd) => {
    const d = horiz ? { x: atEnd ? h.x + h.w - W : h.x, y: h.y, w: W, h: h.h }
                    : { x: h.x, y: atEnd ? h.y + h.h - W : h.y, w: h.w, h: W };
    d.id = BS.DOORS.length; d.hall = hi; d.room = room;
    BS.DOORS.push(d); BS.ROOM_DOORS[room].push(d.id);
  };
  mk(h.a, false); mk(h.b, true);
});

/* Ten spots around the Hub table: used for game start and after every meeting. */
BS.RING = Array.from({ length: 10 }, (_, i) => {
  const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
  return [Math.round(870 + Math.cos(a) * 150), Math.round(740 + Math.sin(a) * 130)];
});

/* ----------------------------------------------------------------- tasks */
BS.GAMES = { wires: 1.5, code: 1.5, align: 1, calibrate: 2, clean: 1.5, sequence: 3, targets: 2.5, panels: 1.5, lever: 1, toggle: 0.4, hold: 0 };
BS.TASKS = [
  { id: 'c_wires', name: 'Patch Wiring', cat: 'common', steps: [
    { st: 'wire_engine', game: 'wires', label: 'Connect the wires' },
    { st: 'wire_sick',   game: 'wires', label: 'Connect the wires' },
    { st: 'wire_power',  game: 'wires', label: 'Connect the wires' }] },
  { id: 'c_code', name: 'Enter Door Code', cat: 'common', steps: [{ st: 'code_bridge', game: 'code', label: 'Enter the code' }] },

  { id: 's_align',   name: 'Align Thrusters',  cat: 'short', steps: [{ st: 'align_engine',     game: 'align',     p: { n: 2, labels: ['Pitch', 'Yaw'] } }] },
  { id: 's_calib_a', name: 'Tune Receiver',    cat: 'short', steps: [{ st: 'calibrate_comms',  game: 'calibrate' }] },
  { id: 's_calib_b', name: 'Tune Scanner',     cat: 'short', steps: [{ st: 'calibrate_bridge', game: 'calibrate' }] },
  { id: 's_filter',  name: 'Clean Air Filter', cat: 'short', steps: [{ st: 'filter_green',     game: 'clean' }] },
  { id: 's_reboot',  name: 'Reboot Console',   cat: 'short', steps: [{ st: 'reboot_reactor',   game: 'sequence' }] },
  { id: 's_debris',  name: 'Clear Debris',     cat: 'short', steps: [{ st: 'asteroid_bridge',  game: 'targets' }] },
  { id: 's_panels',  name: 'Prime Panels',     cat: 'short', steps: [{ st: 'panels_power',     game: 'panels' }] },
  { id: 's_scan',    name: 'Body Scan',        cat: 'short', steps: [{ st: 'scan_sick', game: 'hold', p: { secs: 6, auto: true, label: 'Scanning... stay put' } }] },
  { id: 's_trash_g', name: 'Flush Waste',      cat: 'short', steps: [{ st: 'trash_green',      game: 'lever' }] },
  { id: 's_trash_c', name: 'Flush Waste',      cat: 'short', steps: [{ st: 'trash_cargo',      game: 'lever' }] },

  { id: 'l_fuel', name: 'Refuel Generators', cat: 'long', ordered: true, steps: [
    { st: 'fuel_cargo',  game: 'hold', label: 'Fill the canister', p: { secs: 4, auto: false, label: 'Hold to fill' } },
    { st: 'fuel_engine', game: 'hold', label: 'Pour the fuel',     p: { secs: 4, auto: false, label: 'Hold to pour' } }] },
  { id: 'l_data', name: 'Sync Data', cat: 'long', ordered: true, steps: [
    { st: 'data_hub',    game: 'hold', label: 'Download',  p: { secs: 9, auto: true, label: 'Downloading...' } },
    { st: 'upload_comms', game: 'hold', label: 'Upload',   p: { secs: 9, auto: true, label: 'Uploading...' } }] },
  { id: 'l_divert', name: 'Divert Power', cat: 'long', ordered: true, steps: [
    { st: 'divert_power',  game: 'lever',  label: 'Pull the main lever' },
    { st: 'divert_bridge', game: 'toggle', label: 'Accept the power' }] }
];
BS.minTime = step => step.game === 'hold' ? (step.p && step.p.secs ? step.p.secs * 0.85 : 2) : (BS.GAMES[step.game] || 1);

/* -------------------------------------------------------------- settings */
BS.SETTINGS = [
  { k: 'imps',     label: 'Saboteurs',            type: 'num',  min: 1,   max: 3,   step: 1,    def: 1 },
  { k: 'killCd',   label: 'Eliminate cooldown',   type: 'num',  min: 10,  max: 60,  step: 5,    def: 30,  unit: 's' },
  { k: 'speed',    label: 'Player speed',         type: 'num',  min: 0.5, max: 2,   step: 0.25, def: 1,   unit: 'x' },
  { k: 'crewVis',  label: 'Technician vision',    type: 'num',  min: 0.5, max: 2,   step: 0.25, def: 1,   unit: 'x' },
  { k: 'impVis',   label: 'Saboteur vision',      type: 'num',  min: 0.5, max: 3,   step: 0.25, def: 1.5, unit: 'x' },
  { k: 'emerg',    label: 'Emergency meetings',   type: 'num',  min: 0,   max: 9,   step: 1,    def: 1 },
  { k: 'emergCd',  label: 'Emergency cooldown',   type: 'num',  min: 0,   max: 60,  step: 5,    def: 15,  unit: 's' },
  { k: 'discuss',  label: 'Discussion time',      type: 'num',  min: 0,   max: 60,  step: 5,    def: 15,  unit: 's' },
  { k: 'voteTime', label: 'Voting time',          type: 'num',  min: 15,  max: 180, step: 15,   def: 120, unit: 's' },
  { k: 'common',   label: 'Common tasks',         type: 'num',  min: 0,   max: 2,   step: 1,    def: 1 },
  { k: 'short',    label: 'Short tasks',          type: 'num',  min: 0,   max: 6,   step: 1,    def: 2 },
  { k: 'long',     label: 'Long tasks',           type: 'num',  min: 0,   max: 3,   step: 1,    def: 1 },
  { k: 'sabCd',    label: 'Sabotage cooldown',    type: 'num',  min: 10,  max: 60,  step: 5,    def: 30,  unit: 's' },
  { k: 'tbar',     label: 'Task bar updates',     type: 'enum', opts: [['always', 'Always'], ['meetings', 'Meetings only'], ['never', 'Never']], def: 'always' },
  { k: 'confirm',  label: 'Confirm ejects',       type: 'bool', def: true },
  { k: 'anon',     label: 'Anonymous votes',      type: 'bool', def: false }
];
BS.defaultSettings = () => { const s = {}; BS.SETTINGS.forEach(d => { s[d.k] = d.def; }); return s; };
BS.cleanSetting = (k, v) => {
  const d = BS.SETTINGS.find(x => x.k === k);
  if (!d) return undefined;
  if (d.type === 'bool') return !!v;
  if (d.type === 'enum') return d.opts.some(o => o[0] === v) ? v : undefined;
  v = Number(v);
  if (!isFinite(v)) return undefined;
  v = Math.min(d.max, Math.max(d.min, v));
  return Math.round((v - d.min) / d.step) * d.step + d.min;
};
// 4-6 players: 1 saboteur, 7-8: 2, 9+: 3
BS.maxImps = n => (n >= 9 ? 3 : n >= 7 ? 2 : 1);

/* ------------------------------------------------------------- geometry */
const rectList = a => a.map(r => [r.x, r.y, r.x + r.w, r.y + r.h]);
const RECTS = rectList(BS.ROOMS).concat(rectList(BS.HALLS));
const OBS = rectList(BS.OBS);
const DOORR = rectList(BS.DOORS);
const inR = (list, x, y) => {
  for (let i = 0; i < list.length; i++) { const r = list[i]; if (x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) return true; }
  return false;
};
BS.inWalk = (x, y) => inR(RECTS, x, y);
BS.inObs = (x, y) => inR(OBS, x, y);
BS.inLocked = (x, y, locked) => {
  if (!locked || !locked.size) return false;
  for (const id of locked) { const r = DOORR[id]; if (r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) return true; }
  return false;
};
const RING8 = [[1, 0], [.7071, .7071], [0, 1], [-.7071, .7071], [-1, 0], [-.7071, -.7071], [0, -1], [.7071, -.7071]];
const pointOK = (x, y, locked) => BS.inWalk(x, y) && !BS.inObs(x, y) && !BS.inLocked(x, y, locked);
BS.canStand = (x, y, locked) => {
  if (!pointOK(x, y, locked)) return false;
  for (let i = 0; i < 8; i++) if (!pointOK(x + RING8[i][0] * C.PR, y + RING8[i][1] * C.PR, locked)) return false;
  return true;
};
BS.inWorld = (x, y) => x >= 16 && y >= 16 && x <= C.W - 16 && y <= C.H - 16;

// Move with wall sliding. Sub-steps so thin doors cannot be skipped.
BS.move = (x, y, dx, dy, locked) => {
  const len = Math.hypot(dx, dy), n = Math.max(1, Math.ceil(len / 6));
  const sx = dx / n, sy = dy / n;
  for (let i = 0; i < n; i++) {
    if (BS.canStand(x + sx, y + sy, locked)) { x += sx; y += sy; }
    else if (sx && BS.canStand(x + sx, y, locked)) x += sx;
    else if (sy && BS.canStand(x, y + sy, locked)) y += sy;
    else break;
  }
  return [x, y];
};
BS.nearestStand = (x, y, locked) => {
  if (BS.canStand(x, y, locked)) return [x, y];
  for (let r = 6; r <= 200; r += 6)
    for (let k = 0; k < 24; k++) {
      const a = (k / 24) * Math.PI * 2, px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
      if (BS.canStand(px, py, locked)) return [px, py];
    }
  return [BS.RING[0][0], BS.RING[0][1]];
};
BS.roomAt = (x, y) => {
  for (const r of BS.ROOMS) if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return r.id;
  return -1;
};
// Walls (not furniture) and closed doors block sight.
BS.los = (ax, ay, bx, by, locked) => {
  const d = Math.hypot(bx - ax, by - ay), n = Math.ceil(d / 10);
  for (let i = 1; i < n; i++) {
    const t = i / n, px = ax + (bx - ax) * t, py = ay + (by - ay) * t;
    if (!BS.inWalk(px, py) || BS.inLocked(px, py, locked)) return false;
  }
  return true;
};
BS.visionPoly = (x, y, R, locked, n) => {
  n = n || 150;
  const pts = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2, cx = Math.cos(a), cy = Math.sin(a);
    let lo = 0, hi = R, hit = false;
    for (let r = 12; r <= R + 12; r += 12) {
      const rr = Math.min(r, R), px = x + cx * rr, py = y + cy * rr;
      if (!BS.inWalk(px, py) || BS.inLocked(px, py, locked)) { hi = rr; hit = true; break; }
      lo = rr;
      if (rr >= R) break;
    }
    if (hit) {
      for (let k = 0; k < 4; k++) {
        const m = (lo + hi) / 2, px = x + cx * m, py = y + cy * m;
        if (BS.inWalk(px, py) && !BS.inLocked(px, py, locked)) lo = m; else hi = m;
      }
      lo = Math.min(R, lo + 7);
    }
    pts.push([x + cx * lo, y + cy * lo]);
  }
  return pts;
};
Object.values(ST).forEach(s => { s.room = BS.roomAt(s.x, s.y); });
BS.shuffle = (arr, rng) => {
  rng = rng || Math.random;
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
};
BS.dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
BS.visionOf = (role, alive, s, lights) => {
  if (!alive) return 1e9;
  if (role === 'imp') return C.VISION * s.impVis;
  return C.VISION * s.crewVis * (lights ? C.LIGHTS_MULT : 1);
};
})(typeof window !== 'undefined' ? window : globalThis);
