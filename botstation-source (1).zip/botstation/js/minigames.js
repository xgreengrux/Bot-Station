/* Bot Station - task mini-games. Each game builds its UI into `el` and calls done() once solved. */
(function (g) {
'use strict';
const BS = g.BS, M = BS.Mini = {};
const el = (tag, cls, txt, parent) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; if (parent) parent.appendChild(e); return e; };
const rnd = (a, b) => a + Math.random() * (b - a);
const SVGNS = 'http://www.w3.org/2000/svg';
const sv = (tag, attrs, parent) => { const e = document.createElementNS(SVGNS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };

const GAMES = {};

GAMES.wires = (box, p, win, on) => {
  const cols = ['#ef4444', '#3b82f6', '#facc15', '#ec4899'], L = BS.shuffle(cols), Rr = BS.shuffle(cols);
  const svg = sv('svg', { viewBox: '0 0 340 270', class: 'wires' }, box), lines = [], ends = [];
  let linked = 0, drag = null;
  sv('rect', { x: 0, y: 8, width: 34, height: 254, rx: 8, fill: '#1f2640' }, svg); sv('rect', { x: 306, y: 8, width: 34, height: 254, rx: 8, fill: '#1f2640' }, svg);
  const pt = e => { const r = svg.getBoundingClientRect(); return [(e.clientX - r.left) * 340 / r.width, (e.clientY - r.top) * 270 / r.height]; };
  L.forEach((c, i) => {
    const y = 42 + i * 62;
    const knob = sv('rect', { x: 20, y: y - 11, width: 22, height: 22, rx: 5, fill: c, stroke: '#0b1020', 'stroke-width': 3, style: 'cursor:grab;touch-action:none' }, svg);
    knob.addEventListener('pointerdown', e => { if (lines[i] && lines[i].done) return; e.preventDefault(); knob.setPointerCapture(e.pointerId);
      const ln = lines[i] || (lines[i] = sv('line', { stroke: c, 'stroke-width': 10, 'stroke-linecap': 'round' }, svg)); drag = { i, ln, y }; });
    knob.addEventListener('pointermove', e => { if (!drag || drag.i !== i) return; const [x, yy] = pt(e); drag.ln.setAttribute('x1', 40); drag.ln.setAttribute('y1', y); drag.ln.setAttribute('x2', x); drag.ln.setAttribute('y2', yy); });
    knob.addEventListener('pointerup', e => { if (!drag || drag.i !== i) return; const [x, yy] = pt(e); const j = ends.findIndex(en => Math.hypot(en.x - x, en.y - yy) < 26);
      if (j >= 0 && Rr[j] === c && !ends[j].used) { ends[j].used = true; drag.ln.setAttribute('x2', 300); drag.ln.setAttribute('y2', ends[j].y); drag.ln.done = true; if (++linked === 4) win(); }
      else { drag.ln.setAttribute('x2', 40); drag.ln.setAttribute('y2', y); } drag = null; });
  });
  Rr.forEach((c, j) => { const y = 42 + j * 62; ends.push({ x: 300, y }); sv('rect', { x: 298, y: y - 11, width: 22, height: 22, rx: 5, fill: c, stroke: '#0b1020', 'stroke-width': 3 }, svg); });
};

GAMES.code = (box, p, win, on) => {
  const code = Array.from({ length: 5 }, () => Math.floor(Math.random() * 10)).join('');
  el('div', 'mg-big', code, box); const disp = el('div', 'mg-disp', '', box), pad = el('div', 'keypad', null, box);
  let cur = '';
  const press = d => { if (cur.length >= 5) return; cur += d; disp.textContent = cur.replace(/./g, '•  ').trim(); disp.className = 'mg-disp';
    if (cur.length === 5) { if (cur === code) { disp.textContent = 'ACCESS GRANTED'; disp.className = 'mg-disp ok'; win(); } else { disp.textContent = 'WRONG'; disp.className = 'mg-disp bad'; cur = ''; } } };
  ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '←'].forEach(k => { const b = el('button', 'key', k, pad); b.onclick = () => { if (k === 'C') { cur = ''; disp.textContent = ''; } else if (k === '←') { cur = cur.slice(0, -1); disp.textContent = cur.replace(/./g, '•  ').trim(); } else press(k); }; });
  on(document, 'keydown', e => { if (/^\d$/.test(e.key)) press(e.key); else if (e.key === 'Backspace') { cur = cur.slice(0, -1); disp.textContent = cur.replace(/./g, '•  ').trim(); } });
};

GAMES.align = (box, p, win) => {
  const n = (p && p.n) || 2, labels = (p && p.labels) || ['Axis 1', 'Axis 2'], ok = Array(n).fill(false); let t = null;
  for (let i = 0; i < n; i++) {
    const row = el('div', 'slrow', null, box); el('span', null, labels[i], row);
    const track = el('div', 'sltrack', null, row), target = rnd(25, 75), band = el('i', 'slband', null, track); band.style.left = (target - 4) + '%'; band.style.width = '8%';
    const s = el('input', null, null, track); s.type = 'range'; s.min = 0; s.max = 100; s.value = Math.random() < 0.5 ? rnd(2, 15) : rnd(85, 98);
    s.oninput = () => { ok[i] = Math.abs(s.value - target) <= 4; band.className = ok[i] ? 'slband good' : 'slband'; if (ok.every(Boolean)) { clearTimeout(t); t = setTimeout(() => ok.every(Boolean) && win(), 350); } };
  }
};

GAMES.calibrate = (box, p, win, on, own) => {
  const track = el('div', 'caltrack', null, box), zone = el('i', 'calzone', null, track), mk = el('b', 'calmark', null, track), info = el('div', 'mg-disp', '', box), b = el('button', 'btn big', 'LOCK', box);
  let hits = 0, x = 0, dir = 1, speed = 0.9, zl = 0.4, raf;
  const reset = () => { zl = rnd(0.12, 0.68); zone.style.left = zl * 100 + '%'; zone.style.width = '20%'; };
  reset(); info.textContent = 'Lock the marker inside the zone ×3';
  let last = performance.now();
  const loop = now => { const dt = (now - last) / 1000; last = now; x += dir * speed * dt; if (x > 1) { x = 1; dir = -1; } if (x < 0) { x = 0; dir = 1; } mk.style.left = x * 100 + '%'; raf = requestAnimationFrame(loop); };
  raf = requestAnimationFrame(loop); own(() => cancelAnimationFrame(raf));
  b.onclick = () => { if (x >= zl && x <= zl + 0.2) { hits++; speed += 0.35; info.textContent = hits + ' / 3'; if (hits >= 3) { cancelAnimationFrame(raf); win(); } else reset(); } else { hits = 0; speed = 0.9; info.textContent = 'Missed! Back to 0 / 3'; reset(); } };
};

GAMES.clean = (box, p, win) => {
  const field = el('div', 'leaffield', null, box); let left = 8;
  el('div', 'mg-disp', 'Click every leaf to clear the filter', box);
  for (let i = 0; i < left; i++) { const l = el('div', 'leaf', '🍃', field); l.style.left = rnd(4, 82) + '%'; l.style.top = rnd(4, 78) + '%'; l.style.transform = 'rotate(' + rnd(0, 360) + 'deg)';
    l.onpointerdown = () => { if (l.dead) return; l.dead = true; l.style.opacity = 0; l.style.transform += ' translateY(-40px) scale(.4)'; if (--left === 0) win(); }; }
};

GAMES.sequence = (box, p, win, on, own) => {
  const grid = el('div', 'seqgrid', null, box), info = el('div', 'mg-disp', '', box), tiles = []; let seq = [], pos = 0, busy = true, alive = true; own(() => { alive = false; });
  for (let i = 0; i < 9; i++) { const t = el('button', 'seqtile', null, grid); t.onclick = () => tap(i); tiles.push(t); }
  const flash = (i, ms) => new Promise(r => { tiles[i].classList.add('lit'); setTimeout(() => { tiles[i].classList.remove('lit'); setTimeout(r, 120); }, ms); });
  const play = async () => { busy = true; pos = 0; seq = Array.from({ length: 5 }, () => Math.floor(Math.random() * 9)); info.textContent = 'Watch…';
    await new Promise(r => setTimeout(r, 500)); for (const i of seq) { if (!alive) return; await flash(i, 480); } info.textContent = 'Repeat the pattern'; busy = false; };
  const tap = i => { if (busy) return; tiles[i].classList.add('lit'); setTimeout(() => tiles[i].classList.remove('lit'), 140);
    if (seq[pos] !== i) { info.textContent = 'Wrong! Try again'; busy = true; setTimeout(play, 700); return; }
    if (++pos === seq.length) { info.textContent = 'System rebooted'; busy = true; win(); } };
  play();
};

GAMES.targets = (box, p, win, on, own) => {
  const cv = el('canvas', 'tcv', null, box); cv.width = 340; cv.height = 250; const c = cv.getContext('2d'), info = el('div', 'mg-disp', '', box);
  let rocks = [], hit = 0, raf, last = performance.now(), spawn = 0; const need = 9; info.textContent = 'Destroy the debris 0 / ' + need;
  const loop = now => { const dt = Math.min(0.05, (now - last) / 1000); last = now; spawn -= dt;
    if (spawn <= 0 && rocks.length < 6) { spawn = 0.5; const a = Math.random() * 4; rocks.push({ x: Math.random() < 0.5 ? -20 : 360, y: rnd(20, 230), vx: rnd(30, 80) * (Math.random() < 0.5 ? 1 : -1), vy: rnd(-20, 20), r: rnd(14, 24), a }); }
    c.fillStyle = '#080c1c'; c.fillRect(0, 0, 340, 250);
    rocks.forEach(r => { r.x += r.vx * dt; r.y += r.vy * dt; r.a += dt; if (r.x < -40 || r.x > 380) r.vx *= -1; if (r.y < 10 || r.y > 240) r.vy *= -1; c.save(); c.translate(r.x, r.y); c.rotate(r.a); c.fillStyle = '#8a7e72'; c.strokeStyle = '#3f3830'; c.lineWidth = 2;
      c.beginPath(); for (let i = 0; i < 7; i++) { const ang = i / 7 * Math.PI * 2, rr = r.r * (0.8 + 0.25 * Math.sin(i * 3.1)); c.lineTo(Math.cos(ang) * rr, Math.sin(ang) * rr); } c.closePath(); c.fill(); c.stroke(); c.restore(); });
    raf = requestAnimationFrame(loop); };
  raf = requestAnimationFrame(loop); own(() => cancelAnimationFrame(raf));
  cv.onpointerdown = e => { const b = cv.getBoundingClientRect(), x = (e.clientX - b.left) * 340 / b.width, y = (e.clientY - b.top) * 250 / b.height;
    const i = rocks.findIndex(r => Math.hypot(r.x - x, r.y - y) < r.r + 8); if (i >= 0) { rocks.splice(i, 1); info.textContent = 'Destroy the debris ' + (++hit) + ' / ' + need; if (hit >= need) { cancelAnimationFrame(raf); win(); } } };
};

GAMES.panels = (box, p, win) => {
  const grid = el('div', 'pgrid', null, box); const idx = BS.shuffle([0, 1, 2, 3, 4, 5, 6, 7]).slice(0, 5); let left = idx.length;
  el('div', 'mg-disp', 'Prime every red panel', box);
  for (let i = 0; i < 8; i++) { const b = el('button', 'pnl' + (idx.includes(i) ? ' bad' : ''), '', grid); b.onclick = () => { if (b.classList.contains('bad')) { b.classList.remove('bad'); b.classList.add('good'); if (--left === 0) win(); } }; }
};

GAMES.lever = (box, p, win, on, own) => {
  const slot = el('div', 'leverslot', null, box), h = el('div', 'leverknob', null, slot); el('div', 'mg-disp', 'Pull the lever all the way down', box);
  let drag = false, y0 = 0, pos = 0, raf; const max = 150;
  h.onpointerdown = e => { drag = true; y0 = e.clientY - pos; h.setPointerCapture(e.pointerId); cancelAnimationFrame(raf); };
  h.onpointermove = e => { if (!drag) return; pos = Math.max(0, Math.min(max, e.clientY - y0)); h.style.top = pos + 'px'; };
  h.onpointerup = () => { if (!drag) return; drag = false; if (pos >= max - 4) { win(); return; } const back = () => { pos = Math.max(0, pos - 8); h.style.top = pos + 'px'; if (pos > 0) raf = requestAnimationFrame(back); }; back(); };
  own(() => cancelAnimationFrame(raf));
};

GAMES.toggle = (box, p, win) => {
  const b = el('button', 'bigtoggle', 'OFF', box); b.onclick = () => { b.textContent = 'ON'; b.classList.add('on'); win(); };
};

GAMES.switches = (box, p, win) => {
  const row = el('div', 'swrow', null, box), st = Array.from({ length: 5 }, () => Math.random() < 0.5); if (st.every(Boolean)) st[2] = false;
  const draw = () => { sw.forEach((b, i) => { b.className = 'swbtn' + (st[i] ? ' on' : ''); b.textContent = st[i] ? 'ON' : 'OFF'; }); };
  const sw = st.map((_, i) => { const b = el('button', 'swbtn', '', row); b.onclick = () => { st[i] = !st[i]; draw(); if (st.every(Boolean)) win(); }; return b; });
  el('div', 'mg-disp', 'Flip every breaker on', box); draw();
};

GAMES.hold = (box, p, win, on, own) => {
  p = p || {}; const secs = p.secs || 5, auto = !!p.auto; let v = 0, down = false, raf, last = performance.now(), finished = false;
  const bar = el('div', 'holdbar', null, box), fill = el('i', null, null, bar), info = el('div', 'mg-disp', p.label || (auto ? 'Working…' : 'Hold to continue'), box);
  const btn = auto ? null : el('button', 'btn big', 'HOLD', box);
  if (btn) { const dn = e => { e.preventDefault(); down = true; }, up = () => { down = false; }; btn.onpointerdown = dn; btn.onpointerup = up; btn.onpointerleave = up; on(document, 'keydown', e => { if (e.code === 'Space') { e.preventDefault(); down = true; } }); on(document, 'keyup', e => { if (e.code === 'Space') down = false; }); }
  const loop = now => { const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (auto) v += dt / secs; else v = Math.max(0, v + (down ? dt / secs : -dt / secs * 1.5));
    fill.style.width = Math.min(100, v * 100) + '%'; if (v >= 1 && !finished) { finished = true; win(); return; } raf = requestAnimationFrame(loop); };
  raf = requestAnimationFrame(loop); own(() => cancelAnimationFrame(raf));
};

/* open(game, params, onDone) -> { destroy } ; box is an empty element */
M.open = (box, game, params, onDone) => {
  const cleanups = []; let fin = false;
  const on = (t, ev, fn) => { t.addEventListener(ev, fn); cleanups.push(() => t.removeEventListener(ev, fn)); };
  const own = fn => cleanups.push(fn);
  const win = () => { if (fin) return; fin = true; box.classList.add('solved'); setTimeout(() => onDone(), 380); };
  (GAMES[game] || GAMES.toggle)(box, params, win, on, own);
  return { destroy() { cleanups.forEach(f => { try { f(); } catch (e) { /* ignore */ } }); cleanups.length = 0; } };
};
})(window);
