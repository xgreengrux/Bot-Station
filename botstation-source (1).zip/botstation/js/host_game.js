/* Bot Station - authoritative host, part 2: starting a game, movement, tasks, eliminations, sabotage. */
(function (g) {
'use strict';
const BS = g.BS, C = BS.C, H = BS.Host.prototype;
const VISUAL = new Set(['scan_sick', 'asteroid_bridge', 'trash_green', 'trash_cargo']);
const TASK = {}; BS.TASKS.forEach(t => { TASK[t.id] = t; });
const near = (p, s, r) => Math.hypot(p.x - s.x, p.y - s.y) <= r;

H.ev = function (k, x, y, c) { this.G.events.push({ k, x: Math.round(x), y: Math.round(y), c }); };

H.teleport = function (p, x, y) {
  p.x = x; p.y = y; p.posAt = this.time; p.ignoreUntil = this.time + 0.3;
  this.send(p, { k: 'fix', x: Math.round(x), y: Math.round(y) });
};

/* ------------------------------------------------------------- start */
H.startGame = function () {
  const S = this.settings;
  for (const p of [...this.players.values()]) if (!p.conn) this.players.delete(p.id);
  const list = [...this.players.values()];
  const nImp = Math.max(1, Math.min(S.imps, BS.maxImps(list.length)));
  const imps = new Set(BS.shuffle(list, this.rng).slice(0, nImp).map(p => p.id));
  const pool = c => BS.TASKS.filter(t => t.cat === c).map(t => t.id);
  const common = BS.shuffle(pool('common'), this.rng).slice(0, S.common);
  this.G = {
    imps: [...imps], bodies: [], locked: new Set(), doorsLeft: 0, doorCd: 0, sab: null, sabCd: 10,
    emergCd: S.emergCd, introLeft: 5, meet: null, events: [], tpShown: 0, pendingEnd: false
  };
  list.forEach((p, i) => {
    p.role = imps.has(p.id) ? 'imp' : 'crew';
    p.alive = true; p.gone = false; p.vent = -1; p.open = null; p.moving = false; p.face = 1;
    p.posAt = this.time; p.ignoreUntil = 0; p.dropAt = 0;
    const s = BS.nearestStand(BS.RING[i][0], BS.RING[i][1]);
    p.x = s[0]; p.y = s[1];
    p.killCd = 10; p.emerg = S.emerg;
    const ids = common.concat(BS.shuffle(pool('short'), this.rng).slice(0, S.short), BS.shuffle(pool('long'), this.rng).slice(0, S.long));
    p.tasks = ids.map(id => ({ id, done: TASK[id].steps.map(() => false), fake: p.role === 'imp' }));
  });
  this.phase = 'intro';
  this.snapAcc = 0;
  for (const p of list) this.send(p, this.beginMsg(p, false));
};

H.beginMsg = function (p, rejoin) {
  const G = this.G;
  return {
    k: 'begin', rejoin, me: p.id, role: p.role, alive: p.alive, phase: this.phase,
    mates: p.role === 'imp' ? G.imps.filter(i => i !== p.id) : [],
    tasks: p.tasks.map(t => ({ id: t.id, done: t.done.slice(), fake: t.fake })),
    settings: this.settings, players: this.lobbyMsg().players,
    x: Math.round(p.x), y: Math.round(p.y), intro: Math.max(0, G.introLeft), tp: G.tpShown, emerg: p.emerg
  };
};

// Reconnect: replay everything a late client needs.
H.sendState = function (p) {
  this.send(p, this.beginMsg(p, true));
  if (this.phase === 'over' && this.G.over) this.send(p, this.G.over);
  else if (this.G.meet) this.send(p, this.meetMsg());
};

/* ---------------------------------------------------------- movement */
H.m_pos = function (p, m) {
  const G = this.G;
  if (!G || this.phase !== 'play' || p.vent >= 0 || p.gone) return;
  if (this.time < (p.ignoreUntil || 0)) return;
  const x = +m.x, y = +m.y;
  if (!isFinite(x) || !isFinite(y)) return;
  const dtp = Math.min(0.6, Math.max(0.02, this.time - p.posAt));
  p.posAt = this.time;
  const sp = C.SPEED * this.settings.speed * (p.alive ? 1 : C.GHOST_MULT);
  const ok = Math.hypot(x - p.x, y - p.y) <= sp * dtp * 1.6 + 14 &&
             (p.alive ? BS.canStand(x, y, G.locked) : BS.inWorld(x, y));
  if (!ok) return this.send(p, { k: 'fix', x: Math.round(p.x), y: Math.round(p.y) });
  p.x = x; p.y = y; p.face = m.f ? -1 : 1; p.moving = !!m.m;
  if (p.open) {
    const s = BS.ST[p.open.st];
    if (Math.hypot(s.x - x, s.y - y) > C.USE_RANGE + 40) { p.open = null; this.releaseHold(p); }
  }
};

H.pushOutOfDoors = function () {
  const G = this.G;
  for (const p of this.players.values()) {
    if (!p.alive || p.gone || p.vent >= 0 || BS.canStand(p.x, p.y, G.locked)) continue;
    const s = BS.nearestStand(p.x, p.y, G.locked);
    this.teleport(p, s[0], s[1]);
  }
};

/* ------------------------------------------------------------- tasks */
H.m_open = function (p, m) {
  const G = this.G, st = BS.ST[m.st];
  if (!G || this.phase !== 'play' || !st || p.vent >= 0 || p.gone) return;
  if (!p.alive && p.role === 'imp') return;
  if (!near(p, st, C.USE_RANGE + 14)) return;
  p.open = { st: m.st, t0: this.time };
};

H.m_close = function (p) {
  p.open = null;
  this.releaseHold(p);
};

H.m_done = function (p, m) {
  const G = this.G, o = p.open;
  if (!G || this.phase !== 'play' || !o || p.gone) return;
  const el = this.time - o.t0;
  if (m.fix) {                                   // sabotage repairs
    if (p.alive && G.sab) {
      const good = (m.fix === 'lights' && G.sab.k === 'lights' && o.st === 'lights_panel' && el >= 0.8) ||
                   (m.fix === 'comms' && G.sab.k === 'comms' && o.st === 'comms_panel' && el >= 1.0);
      if (good) { p.open = null; this.endSab(); }
    }
    return;
  }
  if (p.role !== 'crew') return;                  // saboteurs can only pretend
  if (G.sab && G.sab.k === 'comms') return this.send(p, { k: 'deny', why: 'Communications are down.' });
  const tk = p.tasks.find(t => t.id === m.task), si = m.step | 0;
  if (!tk) return;
  const step = TASK[tk.id].steps[si];
  if (!step || tk.done[si] || o.st !== step.st) return;
  if (TASK[tk.id].ordered && tk.done.slice(0, si).some(d => !d)) return;
  if (el < BS.minTime(step) * 0.6) return;
  tk.done[si] = true; p.open = null;
  this.send(p, { k: 'task', task: tk.id, step: si });
  if (this.settings.tbar === 'always') { this.G.tpShown = this.progress(); this.all({ k: 'tp', v: this.G.tpShown }); }
  this.maybeEnd();
};

H.m_hold = function (p, m) {
  const G = this.G, s = G && G.sab;
  if (!s || this.phase !== 'play' || s.k !== 'reactor') return;
  if (m.st !== 'melt_a' && m.st !== 'melt_b') return;
  if (!m.on) { if (s.holds[m.st] === p.id) s.holds[m.st] = 0; return; }
  if (!p.alive || p.gone || p.vent >= 0 || !near(p, BS.ST[m.st], C.USE_RANGE + 14)) return;
  if (!s.holds[m.st]) s.holds[m.st] = p.id;
};

H.releaseHold = function (p) {
  const s = this.G && this.G.sab;
  if (s && s.holds) for (const k in s.holds) if (s.holds[k] === p.id) s.holds[k] = 0;
};

H.m_admin = function (p) {
  const G = this.G;
  if (!G || this.phase !== 'play' || p.vent >= 0 || !near(p, BS.ST.admin, C.USE_RANGE + 30)) return;
  if (G.sab && G.sab.k === 'comms') return this.send(p, { k: 'admin', off: true });
  const rooms = BS.ROOMS.map(() => 0);
  for (const q of this.players.values()) {
    if (!q.alive || q.gone || q.vent >= 0) continue;
    const r = BS.roomAt(q.x, q.y);
    if (r >= 0) rooms[r]++;
  }
  this.send(p, { k: 'admin', rooms });
};

/* ----------------------------------------- eliminations, vents, reports */
H.m_kill = function (p, m) {
  const G = this.G;
  if (!G || this.phase !== 'play' || p.role !== 'imp' || !p.alive || p.vent >= 0 || p.killCd > 0) return;
  const t = this.players.get(m.t | 0);
  if (!t || !t.alive || t.gone || t.role === 'imp' || t.vent >= 0) return;
  if (Math.hypot(t.x - p.x, t.y - p.y) > C.KILL_RANGE + 24) return;
  t.alive = false; t.open = null; this.releaseHold(t);
  G.bodies.push({ id: t.id, x: Math.round(t.x), y: Math.round(t.y) });
  this.ev('kill', t.x, t.y, t.color);
  p.open = null; p.killCd = this.settings.killCd;
  const s = BS.nearestStand(t.x, t.y, G.locked);
  this.teleport(p, s[0], s[1]);
  this.send(t, { k: 'died', by: p.id });
  this.maybeEnd();
};

H.m_vent = function (p, m) {
  const G = this.G;
  if (!G || this.phase !== 'play' || p.role !== 'imp' || !p.alive) return;
  if (p.vent < 0) {
    let best = -1, bd = C.VENT_RANGE + 14;
    for (const v of BS.VENTS) { const d = Math.hypot(v.x - p.x, v.y - p.y); if (d < bd) { bd = d; best = v.id; } }
    if (best < 0) return;
    p.vent = best; p.open = null; p.moving = false;
    p.x = BS.VENTS[best].x; p.y = BS.VENTS[best].y;
    this.ev('vent', p.x, p.y, p.color);
  } else if (m.to === -1) {
    const v = BS.VENTS[p.vent];
    p.vent = -1; p.x = v.x; p.y = v.y; p.posAt = this.time;
    this.ev('vent', p.x, p.y, p.color);
  } else if (BS.VENTS[p.vent].links.includes(m.to | 0)) {
    p.vent = m.to | 0; p.x = BS.VENTS[p.vent].x; p.y = BS.VENTS[p.vent].y;
  } else return;
  this.send(p, { k: 'vent', v: p.vent, x: Math.round(p.x), y: Math.round(p.y) });
};

H.m_report = function (p) {
  const G = this.G;
  if (!G || this.phase !== 'play' || !p.alive || p.vent >= 0) return;
  let b = null, bd = C.REPORT_RANGE + 24;
  for (const x of G.bodies) {
    const d = Math.hypot(x.x - p.x, x.y - p.y);
    if (d < bd && BS.los(p.x, p.y, x.x, x.y, G.locked)) { bd = d; b = x; }
  }
  if (b) this.startMeeting(p, b.id);
};

H.m_button = function (p) {
  const G = this.G;
  if (!G || this.phase !== 'play' || !p.alive || p.vent >= 0) return;
  if (p.emerg <= 0 || G.emergCd > 0 || G.sab) return this.send(p, { k: 'deny', why: G.sab ? 'Not during a sabotage!' : 'Emergency button unavailable.' });
  if (!near(p, BS.ST.button, C.USE_RANGE + 14)) return;
  p.emerg--;
  this.startMeeting(p, 0);
};

/* ---------------------------------------------------------- sabotage */
H.m_sab = function (p, m) {
  const G = this.G;
  if (!G || this.phase !== 'play' || p.role !== 'imp' || p.gone) return;
  if (m.s === 'doors') {
    const room = m.room | 0;
    if (room < 0 || room >= BS.ROOMS.length || G.sab || G.doorCd > 0 || G.locked.size) return;
    G.locked = new Set(BS.ROOM_DOORS[room]);
    G.doorsLeft = C.DOOR_TIME; G.doorCd = C.DOOR_TIME + C.DOOR_CD;
    this.pushOutOfDoors();
    return this.all({ k: 'sabmsg', s: 'doors', room });
  }
  if (G.sabCd > 0 || G.sab || G.locked.size) return;
  if (m.s === 'reactor') G.sab = { k: 'reactor', left: C.REACTOR_TIME, holds: { melt_a: 0, melt_b: 0 } };
  else if (m.s === 'lights') G.sab = { k: 'lights' };
  else if (m.s === 'comms') G.sab = { k: 'comms' };
  else return;
  this.all({ k: 'sabmsg', s: m.s });
};

H.endSab = function () {
  const G = this.G;
  G.sab = null; G.sabCd = this.settings.sabCd;
  this.all({ k: 'sabmsg', s: 'fixed' });
};

/* -------------------------------------------------------------- tick */
H.tickGame = function (dt) {
  const G = this.G;
  for (const p of this.players.values()) {
    if (!p.conn && !p.gone && p.dropAt && this.time >= p.dropAt) this.dropPlayer(p);
  }
  if (this.phase === 'intro') {
    G.introLeft -= dt;
    if (G.introLeft <= 0) { this.phase = 'play'; for (const p of this.players.values()) p.posAt = this.time; this.all({ k: 'go' }); }
  } else if (this.phase === 'play') this.tickPlay(dt);
  else if (this.phase === 'meeting') this.tickMeeting(dt);
  if (this.phase === 'intro' || this.phase === 'play') {
    this.snapAcc += dt;
    if (this.snapAcc >= 1 / 15 - 1e-6) { this.snapAcc = 0; this.snapshots(); }
  }
};

H.tickPlay = function (dt) {
  const G = this.G;
  for (const p of this.players.values()) if (p.role === 'imp' && p.killCd > 0) p.killCd = Math.max(0, p.killCd - dt);
  if (G.emergCd > 0) G.emergCd = Math.max(0, G.emergCd - dt);
  if (!G.sab && G.sabCd > 0) G.sabCd = Math.max(0, G.sabCd - dt);
  if (G.doorCd > 0) G.doorCd = Math.max(0, G.doorCd - dt);
  if (G.doorsLeft > 0) {
    G.doorsLeft -= dt;
    if (G.doorsLeft <= 0) { G.doorsLeft = 0; G.locked = new Set(); this.all({ k: 'sabmsg', s: 'doorsup' }); }
  }
  const s = G.sab;
  if (s && s.k === 'reactor') {
    for (const st of ['melt_a', 'melt_b']) {
      const id = s.holds[st];
      if (!id) continue;
      const q = this.players.get(id);
      if (!q || !q.alive || q.gone || !q.conn || q.vent >= 0 || !near(q, BS.ST[st], C.USE_RANGE + 40)) s.holds[st] = 0;
    }
    if (s.holds.melt_a && s.holds.melt_b) this.endSab();
    else { s.left -= dt; if (s.left <= 0) this.endGame('imp', 'sabotage'); }
  }
};

H.dropPlayer = function (p) {
  if (p.gone) return;
  p.gone = true; p.alive = false; p.conn = false; p.open = null; p.vent = -1;
  this.releaseHold(p);
  const G = this.G;
  if (G && G.meet) delete G.meet.votes[p.id];
  this.all({ k: 'gone', id: p.id });
  this.maybeEnd();
};

/* --------------------------------------------------------- snapshots */
H.snapshots = function () {
  const G = this.G, S = this.settings, lights = !!(G.sab && G.sab.k === 'lights');
  const sab = G.sab ? { k: G.sab.k, left: Math.ceil(G.sab.left || 0), h: G.sab.holds ? [G.sab.holds.melt_a ? 1 : 0, G.sab.holds.melt_b ? 1 : 0] : null } : null;
  const dr = [...G.locked];
  for (const r of this.players.values()) {
    if (!r.conn) continue;
    const ghost = !r.alive, R = BS.visionOf(r.role, r.alive, S, lights) + 16;
    const see = (x, y) => ghost || (Math.hypot(x - r.x, y - r.y) <= R && BS.los(r.x, r.y, x, y, G.locked));
    const pl = [];
    for (const q of this.players.values()) {
      if (q === r || q.gone || q.vent >= 0 || (!q.alive && !ghost) || !see(q.x, q.y)) continue;
      pl.push([q.id, Math.round(q.x), Math.round(q.y),
        (q.alive ? 0 : 1) | (q.face < 0 ? 2 : 0) | (q.moving ? 4 : 0) |
        (q.alive && q.open && VISUAL.has(q.open.st) ? 8 : 0) | (r.role === 'imp' && q.role === 'imp' ? 16 : 0)]);
    }
    const m = { k: 's', pl, bd: G.bodies.filter(b => see(b.x, b.y)).map(b => [b.id, b.x, b.y]), sab, dr, ecd: Math.ceil(G.emergCd) };
    const ev = G.events.filter(e => see(e.x, e.y)).map(e => [e.k, e.x, e.y, e.c]);
    if (ev.length) m.ev = ev;
    if (r.role === 'imp') { m.kcd = Math.ceil(r.killCd); m.scd = Math.ceil(G.sabCd); m.dcd = Math.ceil(G.doorCd); }
    this.send(r, m);
  }
  G.events.length = 0;
};
})(typeof window !== 'undefined' ? window : globalThis);
