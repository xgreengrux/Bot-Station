/* Bot Station - authoritative host, part 3: meetings, voting, win conditions. */
(function (g) {
'use strict';
const BS = g.BS, H = BS.Host.prototype;
const RESULT_TIME = 9;

H.progress = function () {
  let d = 0, t = 0;
  for (const p of this.players.values()) {
    if (p.role !== 'crew' || p.gone) continue;
    for (const tk of p.tasks) for (const x of tk.done) { t++; if (x) d++; }
  }
  return t ? d / t : 0;
};

H.winState = function () {
  let imps = 0, crew = 0, ejectedImp = false;
  for (const p of this.players.values()) {
    if (p.role === 'imp' && p.ejected) ejectedImp = true;
    if (p.gone || !p.alive) continue;
    if (p.role === 'imp') imps++; else crew++;
  }
  if (imps === 0) return ['crew', ejectedImp ? 'votes' : 'leave'];
  if (imps >= crew) return ['imp', 'kills'];
  if (this.progress() >= 1) return ['crew', 'tasks'];
  return null;
};

H.maybeEnd = function () {
  if (this.phase === 'over' || this.phase === 'meeting' || !this.G) return;
  const w = this.winState();
  if (w) this.endGame(w[0], w[1]);
};

H.endGame = function (winner, why) {
  if (this.phase === 'over' || !this.G) return;
  this.phase = 'over';
  const roles = {};
  for (const p of this.players.values()) roles[p.id] = p.role;
  this.G.over = { k: 'over', winner, why, roles };
  this.all(this.G.over);
};

/* ----------------------------------------------------------- meetings */
H.meetPlayers = function () {
  return [...this.players.values()].filter(p => !p.gone).map(p => [p.id, p.alive ? 1 : 0, p.conn ? 1 : 0]);
};

H.meetMsg = function () {
  const M = this.G.meet;
  return {
    k: 'meet', st: M.st, left: Math.max(0, Math.round(M.left * 10) / 10), caller: M.caller, body: M.body,
    voted: Object.keys(M.votes).map(Number), players: this.meetPlayers(), tp: this.G.tpShown, result: M.result
  };
};

H.startMeeting = function (caller, bodyId) {
  const G = this.G, S = this.settings;
  this.phase = 'meeting';
  for (const p of this.players.values()) { p.open = null; p.moving = false; p.vent = -1; }
  if (G.sab && G.sab.holds) G.sab.holds = { melt_a: 0, melt_b: 0 };
  G.locked = new Set(); G.doorsLeft = 0;
  if (S.tbar === 'meetings') G.tpShown = this.progress();
  G.meet = {
    caller: caller.id, body: bodyId, st: S.discuss > 0 ? 'discuss' : 'vote',
    left: S.discuss > 0 ? S.discuss : S.voteTime, votes: {}, result: null, allIn: false
  };
  this.all(this.meetMsg());
};

H.m_vote = function (p, m) {
  const M = this.G && this.G.meet;
  if (!M || this.phase !== 'meeting' || M.st !== 'vote' || !p.alive || p.gone) return;
  if (M.votes[p.id] !== undefined) return;
  const t = m.t | 0;                                   // 0 = skip
  if (t !== 0) { const q = this.players.get(t); if (!q || !q.alive || q.gone) return; }
  M.votes[p.id] = t;
  this.all({ k: 'voted', id: p.id });
};

H.tickMeeting = function (dt) {
  const G = this.G, M = G.meet, S = this.settings;
  M.left -= dt;
  if (M.st === 'discuss') {
    if (M.left <= 0) { M.st = 'vote'; M.left = S.voteTime; this.all(this.meetMsg()); }
  } else if (M.st === 'vote') {
    if (!M.allIn) {
      const el = [...this.players.values()].filter(p => p.alive && !p.gone && p.conn);
      if (el.length && el.every(p => M.votes[p.id] !== undefined)) { M.allIn = true; M.left = Math.min(M.left, 2); this.all(this.meetMsg()); }
    }
    if (M.left <= 0) this.resolveMeeting();
  } else if (M.st === 'result' && M.left <= 0) this.endMeeting();
};

H.resolveMeeting = function () {
  const G = this.G, M = G.meet, S = this.settings;
  const tally = {};
  for (const v of Object.values(M.votes)) tally[v] = (tally[v] || 0) + 1;
  let max = 0, top = [];
  for (const k of Object.keys(tally)) {
    const n = tally[k];
    if (n > max) { max = n; top = [+k]; } else if (n === max) top.push(+k);
  }
  const ejected = top.length === 1 && top[0] !== 0 ? top[0] : 0;
  let wasImp = null, left = null;
  if (ejected) {
    const e = this.players.get(ejected);
    e.alive = false; e.ejected = true;
    if (S.confirm) wasImp = e.role === 'imp';
  }
  if (S.confirm) left = [...this.players.values()].filter(p => p.alive && !p.gone && p.role === 'imp').length;
  M.st = 'result'; M.left = RESULT_TIME;
  M.result = { ejected, tie: top.length > 1, counts: tally, votes: S.anon ? null : Object.assign({}, M.votes), wasImp, left };
  this.all(this.meetMsg());
};

H.endMeeting = function () {
  const G = this.G, S = this.settings;
  G.meet = null; this.phase = 'play';
  const w = this.winState();
  if (w) return this.endGame(w[0], w[1]);
  G.bodies = []; G.events = []; G.emergCd = S.emergCd;
  if (G.sab && G.sab.k === 'reactor') G.sab.left += 10;      // a little grace after the meeting
  let i = 0;
  for (const p of this.players.values()) {
    if (p.gone) continue;
    const spot = BS.RING[i++ % BS.RING.length], s = BS.nearestStand(spot[0], spot[1]);
    p.x = s[0]; p.y = s[1]; p.posAt = this.time; p.ignoreUntil = this.time + 0.3; p.open = null; p.vent = -1;
    if (p.role === 'imp') p.killCd = S.killCd;
    this.send(p, { k: 'resume', x: Math.round(p.x), y: Math.round(p.y), alive: p.alive });
  }
};
})(typeof window !== 'undefined' ? window : globalThis);
