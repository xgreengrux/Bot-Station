/* Bot Station - in-game screens: intro, meetings/voting, ejection, results, task panel, map, HUD lists, sound. */
(function (g) {
'use strict';
const BS = g.BS, UI = BS.UI, el = BS.el, $ = UI.$, col = UI.col, R = BS.R;
const nameOf = (S, id) => (S.players.get(id) || {}).name || '???';
const colOf = (S, id) => col((S.players.get(id) || {}).color | 0);
const rname = r => BS.ROOMS[r].name;

/* ------------------------------------------------------------------ sound */
const AC = g.AudioContext || g.webkitAudioContext; let actx;
BS.Sfx = {
  muted: false,
  play(n) {
    if (this.muted || !AC) return;
    try {
      actx = actx || new AC(); const t0 = actx.currentTime;
      const tone = (f, at, d, type, v) => { const o = actx.createOscillator(), gn = actx.createGain(); o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0 + at);
        gn.gain.setValueAtTime(0.0001, t0 + at); gn.gain.exponentialRampToValueAtTime(v || 0.12, t0 + at + 0.02); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + at + d);
        o.connect(gn); gn.connect(actx.destination); o.start(t0 + at); o.stop(t0 + at + d + 0.05); };
      if (n === 'task') { tone(660, 0, 0.12); tone(990, 0.1, 0.18); }
      else if (n === 'meeting') { for (let i = 0; i < 4; i++) tone(i % 2 ? 520 : 780, i * 0.16, 0.14, 'square', 0.08); }
      else if (n === 'kill') { tone(130, 0, 0.3, 'sawtooth', 0.2); tone(70, 0.05, 0.4, 'square', 0.15); }
      else if (n === 'sab') { for (let i = 0; i < 4; i++) tone(i % 2 ? 440 : 620, i * 0.22, 0.2, 'sawtooth', 0.09); }
      else if (n === 'vote') tone(440, 0, 0.1, 'triangle');
      else if (n === 'win') { [523, 659, 784, 1046].forEach((f, i) => tone(f, i * 0.14, 0.3, 'triangle', 0.12)); }
      else if (n === 'lose') { [392, 330, 262, 196].forEach((f, i) => tone(f, i * 0.2, 0.35, 'sawtooth', 0.1)); }
      else if (n === 'vent') tone(200, 0, 0.18, 'square', 0.08);
      else if (n === 'go') { tone(440, 0, 0.1); tone(880, 0.1, 0.2); }
    } catch (e) { /* audio unavailable */ }
  }
};

/* -------------------------------------------------------------- the panel */
UI.panel = (title, hint, onClose) => {
  const p = $('panel'); p.classList.remove('hidden'); p.innerHTML = '';
  const card = el('div', 'pcard2', null, p), head = el('div', 'phead', null, card);
  el('b', null, title, head); const x = el('button', 'x', '✕', head); x.onclick = onClose;
  const box = el('div', 'pbody', null, card); if (hint) el('div', 'phint', hint, card);
  return box;
};
UI.closePanel = () => { const p = $('panel'); p.classList.add('hidden'); p.innerHTML = ''; };

/* --------------------------------------------------------------- HUD lists */
UI.tasks = S => {
  const box = $('tasks'); box.innerHTML = '';
  if (S.sab && S.sab.k === 'comms') { el('div', 'th bad', 'COMMS DOWN', box); el('div', 'tl', 'Tasks unavailable until the dish is repaired.', box); return; }
  if (!box._init) { box._init = 1; if (g.matchMedia && g.matchMedia('(max-width:820px)').matches) box.classList.add('collapsed'); }
  const hd = el('div', 'th', S.role === 'imp' ? 'Fake tasks (blend in)' : 'Tasks', box); hd.onclick = () => box.classList.toggle('collapsed');
  S.tasks.forEach(tk => {
    const def = BS.TASKS.find(d => d.id === tk.id), n = tk.done.filter(Boolean).length, all = n === tk.done.length;
    const rooms = [...new Set(def.steps.filter((s, i) => !tk.done[i]).map(s => rname(BS.ST[s.st].room)))].join(', ');
    const row = el('div', 'tl' + (all && S.role !== 'imp' ? ' done' : ''), null, box);
    el('span', null, def.name + (def.steps.length > 1 ? ' (' + n + '/' + def.steps.length + ')' : ''), row);
    if (!all || S.role === 'imp') el('small', null, rooms || '', row);
  });
};

UI.alert = S => {
  const a = $('alert'), s = S.sab; if (!s) { a.classList.add('hidden'); return; }
  a.classList.remove('hidden');
  if (s.k === 'reactor') a.textContent = '⚠ REACTOR MELTDOWN ' + s.left + 's — two players must hold the Core Consoles (' + (s.h[0] ? '✔' : '✖') + ' Reactor Core / ' + (s.h[1] ? '✔' : '✖') + ' Engine Bay)';
  else if (s.k === 'lights') a.textContent = '💡 Lights are out — fix the Lighting Breaker in the Power Room';
  else a.textContent = '📡 Communications down — repair the Dish Controls on the Comms Deck';
  a.className = 'alert' + (s.k === 'reactor' ? ' crit' : '');
};

UI.progress = tp => { $('tbar').firstChild.style.width = Math.round(tp * 100) + '%'; $('tbarTxt').textContent = 'TOTAL TASKS ' + Math.round(tp * 100) + '%'; };

/* ------------------------------------------------------------ role intro */
UI.intro = S => {
  const o = $('intro'); o.classList.remove('hidden'); o.innerHTML = '';
  const imp = S.role === 'imp';
  const t = el('div', 'role-title ' + (imp ? 'imp' : 'crew'), imp ? 'SABOTEUR' : 'TECHNICIAN', o);
  const imps = [...S.players.keys()].length;
  el('div', 'role-sub', imp ? (S.mates.length ? 'You and your partner' + (S.mates.length > 1 ? 's' : '') + ' must take them out.' : 'Eliminate the technicians. Trust no one.') : 'Finish your tasks. Find the saboteur.', o);
  const row = el('div', 'role-row', null, o);
  const ids = imp ? [S.id].concat(S.mates) : [...S.players.keys()];
  ids.forEach((id, i) => { const p = S.players.get(id); if (!p) return; const c = el('div', 'role-bot', null, row); c.style.animationDelay = i * 0.08 + 's'; c.appendChild(R.icon(col(p.color), p.hat, 70)); el('small', null, p.name, c); });
  void t; void imps;
};
UI.hideIntro = () => { const o = $('intro'); o.classList.add('hidden'); o.innerHTML = ''; };

UI.died = (S, by) => {
  const o = $('killov'); o.classList.remove('hidden'); o.innerHTML = '';
  el('div', 'kill-t', 'YOU WERE ELIMINATED', o); el('div', 'kill-s', nameOf(S, by) + ' was the saboteur. You can still finish tasks as a ghost.', o);
  setTimeout(() => { o.classList.add('hidden'); o.innerHTML = ''; }, 2600);
};

/* -------------------------------------------------------------- meetings */
UI.hideMeeting = () => { const r = $('meeting'); r.classList.add('hidden'); r.innerHTML = ''; clearInterval(UI._mtimer); clearTimeout(UI._ejT); UI._M = null; };

UI.meeting = (m, app) => {
  const S = app.S, root = $('meeting'); root.classList.remove('hidden');
  let M = UI._M;
  if (!M) {
    root.innerHTML = '';
    const card = el('div', 'meet-card', null, root), head = el('div', 'meet-head', null, card);
    const titles = el('div', null, null, head); M = UI._M = { sel: null, mine: undefined, voted: new Set(), left: 0, t0: 0, st: '', shown: false };
    M.title = el('h2', null, '', titles); M.sub = el('p', null, '', titles); M.timer = el('div', 'meet-timer', '', head);
    const body = el('div', 'meet-body', null, card); M.grid = el('div', 'meet-players', null, body);
    const cp = el('div', 'meet-chat', null, body); M.chat = UI.chatBox(cp, t => app.send({ k: 'chat', text: t }), { placeholder: S.alive ? 'Discuss…' : 'Ghost chat (only ghosts see this)…' });
    M.foot = el('div', 'meet-foot', null, card); M.skip = el('button', 'btn', 'Skip vote', M.foot); M.confirm = el('span', 'confirm', '', M.foot); M.status = el('span', 'mstatus', '', M.foot);
    M.skip.onclick = () => { if (!M.skip.disabled) { M.sel = 0; render(); } };
    clearInterval(UI._mtimer); UI._mtimer = setInterval(() => { const l = Math.max(0, M.left - (performance.now() - M.t0) / 1000); M.timer.textContent = M.st === 'result' ? '' : Math.ceil(l) + 's'; }, 200);
    BS.Sfx.play('meeting');
  }
  M.st = m.st; M.left = m.left; M.t0 = performance.now(); M.players = m.players; M.result = m.result;
  m.voted.forEach(i => M.voted.add(i));
  M.title.textContent = m.body ? 'Body reported' : 'Emergency meeting';
  M.sub.textContent = m.body ? nameOf(S, m.caller) + ' found ' + nameOf(S, m.body) + '’s body.' : nameOf(S, m.caller) + ' pressed the emergency button.';
  UI.progress(m.tp);
  function render() {
    const canVote = m.st === 'vote' && S.alive && !M.voted.has(S.id) && M.mine === undefined;
    M.grid.innerHTML = '';
    M.players.forEach(([id, alive, conn]) => {
      const p = S.players.get(id) || { color: 0, hat: 0, name: '?' };
      const c = el(canVote && alive ? 'button' : 'div', 'mcard' + (alive ? '' : ' dead') + (M.sel === id ? ' sel' : '') + (M.result && M.result.ejected === id ? ' ejected' : ''), null, M.grid);
      c.appendChild(R.icon(col(p.color), p.hat, 44, !alive));
      const nm = el('div', 'mn', p.name, c); if (id === S.id) el('small', null, ' (you)', nm);
      if (m.caller === id) el('span', 'mbadge', '📣', c);
      if (M.voted.has(id) && m.st !== 'result') el('span', 'mbadge voted', '✔', c);
      if (!conn && alive) el('small', 'off', 'offline', c);
      if (m.st === 'result' && M.result) {
        if (M.result.votes) { const dots = el('div', 'vdots', null, c); Object.keys(M.result.votes).forEach(v => { if (M.result.votes[v] === id) { const d = el('i', null, '', dots); d.style.background = colOf(S, +v); d.title = nameOf(S, +v); } }); }
        else if (M.result.counts[id]) el('div', 'vcount', '×' + M.result.counts[id], c);
      }
      if (canVote && alive) c.onclick = () => { M.sel = id; render(); };
    });
    M.skip.disabled = !canVote; M.skip.classList.toggle('sel', M.sel === 0);
    M.confirm.innerHTML = '';
    if (canVote && M.sel !== null) {
      el('span', null, M.sel === 0 ? 'Skip this vote? ' : 'Vote for ' + nameOf(S, M.sel) + '? ', M.confirm);
      const ok = el('button', 'btn primary', '✔ Confirm', M.confirm), no = el('button', 'btn', '✖', M.confirm);
      ok.onclick = () => { M.mine = M.sel; app.send({ k: 'vote', t: M.sel }); BS.Sfx.play('vote'); render(); }; no.onclick = () => { M.sel = null; render(); };
    }
    M.status.textContent = m.st === 'discuss' ? 'Discussion — voting opens when the timer ends.' : m.st === 'vote'
      ? (!S.alive ? 'You are a ghost — you cannot vote.' : M.voted.has(S.id) || M.mine !== undefined ? 'Vote cast. Waiting for the others…' : 'Click a player (or Skip), then confirm.')
      : (M.result && M.result.votes === null ? 'Votes are anonymous.' : '');
    if (m.st === 'result' && M.result && M.result.counts[0]) el('span', 'skipcount', 'Skipped: ' + M.result.counts[0], M.status);
  }
  M.render = render; render();
  if (m.st === 'result' && !M.shown) { M.shown = true; clearTimeout(UI._ejT); UI._ejT = setTimeout(() => UI.eject(m.result, S), Math.max(0, (m.left - 5.6) * 1000)); }
};
UI.meetVoted = id => { if (UI._M) { UI._M.voted.add(id); UI._M.render && UI._M.render(); } };
UI.meetChat = (S, m) => { if (UI._M) UI._M.chat.add(nameOf(S, m.from), colOf(S, m.from), m.text, m.ghost); };

/* -------------------------------------------------------------- ejection */
UI.hideEject = () => { const o = $('eject'); o.classList.add('hidden'); cancelAnimationFrame(UI._ejRaf); };
UI.eject = (res, S) => {
  const o = $('eject'); o.classList.remove('hidden'); $('meeting').classList.add('hidden');
  const cv = $('ecv'), c = cv.getContext('2d'); cv.width = g.innerWidth; cv.height = g.innerHeight;
  const tx = $('etext'); tx.innerHTML = '';
  const lines = [];
  if (res.ejected) {
    lines.push(nameOf(S, res.ejected) + ' was ejected.');
    if (res.wasImp !== null) lines.push(nameOf(S, res.ejected) + (res.wasImp ? ' WAS' : ' was NOT') + ' a saboteur.');
  } else lines.push('No one was ejected.', res.tie ? '(Tie)' : '(Skipped)');
  if (res.left !== null && res.left !== undefined) lines.push(res.left + ' saboteur' + (res.left === 1 ? '' : 's') + ' remain' + (res.left === 1 ? 's' : '') + '.');
  const p = res.ejected ? S.players.get(res.ejected) : null, t0 = performance.now(), stars = Array.from({ length: 90 }, () => ({ x: Math.random(), y: Math.random(), s: Math.random() * 2 + 0.5, v: Math.random() * 0.6 + 0.2 }));
  const shown = [];
  const loop = now => {
    const t = (now - t0) / 1000, w = cv.width, h = cv.height;
    c.fillStyle = '#02030a'; c.fillRect(0, 0, w, h); c.fillStyle = '#fff';
    stars.forEach(s => { const x = ((s.x - t * s.v * 0.25) % 1 + 1) % 1; c.globalAlpha = 0.4 + s.s / 4; c.fillRect(x * w, s.y * h, s.s, s.s); }); c.globalAlpha = 1;
    if (p) { const x = -100 + (t / 4.2) * (w + 200), y = h * 0.42 + Math.sin(t * 2) * 12; c.save(); c.translate(x, y); c.rotate(t * 2.2); c.scale(2.6, 2.6); R.drawBot(c, 0, 0, { color: col(p.color), hat: p.hat, face: 1, t }); c.restore(); }
    lines.forEach((ln, i) => { if (t > 0.6 + i * 0.9 && shown.length <= i) { shown.push(1); el('div', 'eline', ln, tx); } });
    UI._ejRaf = requestAnimationFrame(loop);
  };
  cancelAnimationFrame(UI._ejRaf); UI._ejRaf = requestAnimationFrame(loop);
};

/* ----------------------------------------------------------------- game over */
UI.hideOver = () => { const o = $('over'); o.classList.add('hidden'); o.innerHTML = ''; };
UI.over = (m, app) => {
  const S = app.S, o = $('over'); o.classList.remove('hidden'); o.innerHTML = '';
  UI.hideEject(); UI.hideMeeting(); UI.closePanel(); UI.closeMap();
  const mine = S.role === 'imp' ? 'imp' : 'crew', win = m.winner === mine;
  const card = el('div', 'over-card', null, o);
  el('div', 'over-t ' + (win ? 'win' : 'lose'), win ? 'VICTORY' : 'DEFEAT', card);
  el('div', 'over-s', (m.winner === 'crew' ? 'Technicians win! ' : 'Saboteurs win! ') + ({ tasks: 'Every task was completed.', votes: 'All saboteurs were ejected.', kills: 'The saboteurs outnumber the technicians.', sabotage: 'The reactor melted down.', leave: 'The saboteurs left the game.' }[m.why] || ''), card);
  const row = el('div', 'over-row', null, card);
  [...S.players.values()].forEach(p => { const c = el('div', 'obot ' + (m.roles[p.id] === 'imp' ? 'imp' : ''), null, row); c.appendChild(R.icon(col(p.color), p.hat, 56)); el('b', null, p.name, c); el('small', null, m.roles[p.id] === 'imp' ? 'Saboteur' : 'Technician', c); });
  const foot = el('div', 'over-foot', null, card);
  if (S.id === S.leader) { const b = el('button', 'btn big primary', 'Back to lobby', foot); b.onclick = () => app.send({ k: 'again' }); } else el('div', 'lb-note', 'Waiting for the party leader to return to the lobby…', foot);
  const lv = el('button', 'btn', 'Leave party', foot); lv.onclick = () => app.leave();
  BS.Sfx.play(win ? 'win' : 'lose');
};

/* ------------------------------------------------------------------- map */
UI.closeMap = () => { const m = $('mapov'); m.classList.add('hidden'); m.innerHTML = ''; clearInterval(UI._mapT); UI._mapMode = null; };
UI.map = (app, mode) => {
  const S = app.S, root = $('mapov'); root.classList.remove('hidden'); root.innerHTML = ''; UI._mapMode = mode;
  const card = el('div', 'map-card', null, root), head = el('div', 'phead', null, card);
  el('b', null, mode === 'sab' ? 'Sabotage' : mode === 'admin' ? 'Admin table — occupancy' : 'Station map', head);
  const x = el('button', 'x', '✕', head); x.onclick = () => app.closeOverlays();
  // On a phone the sabotage menu is a plain button panel (system sabotages + a 3x3 grid of door locks laid out like the
  // station) instead of icons floating over a tiny map.
  const small = mode === 'sab' && (g.innerWidth < 640 || g.innerHeight < 520);
  let c = null, btns = null, sc = 1;
  if (!small) {
    const wrap = el('div', 'mapwrap', null, card), cv = el('canvas', null, null, wrap); cv.width = 870; cv.height = 740;
    c = cv.getContext('2d'); btns = el('div', 'mapbtns', null, wrap);
    // when the map is drawn small, scale label text and dots up so they stay readable
    sc = Math.max(1, 0.62 * 870 / (cv.clientWidth || 860));
  } else card.classList.add('compact');
  const k = 0.5;
  const place = (b, x0, y0) => { b.style.left = (x0 / BS.C.W * 100) + '%'; b.style.top = (y0 / BS.C.H * 100) + '%'; };
  const draw = () => {
    if (!c) return;
    c.fillStyle = '#070a14'; c.fillRect(0, 0, 870, 740);
    c.fillStyle = '#39415f'; BS.HALLS.forEach(h => c.fillRect(h.x * k, h.y * k, h.w * k, h.h * k));
    BS.ROOMS.forEach(r => { c.fillStyle = '#2b3350'; c.fillRect(r.x * k, r.y * k, r.w * k, r.h * k); c.strokeStyle = '#59658c'; c.lineWidth = 2; c.strokeRect(r.x * k, r.y * k, r.w * k, r.h * k);
      const fs = Math.round(14 * sc); c.fillStyle = 'rgba(255,255,255,.75)'; c.font = 'bold ' + fs + 'px system-ui'; c.textAlign = 'center'; c.fillText(r.name, (r.x + r.w / 2) * k, r.y * k + fs + 5); });
    S.doors.forEach(id => { const d = BS.DOORS[id]; c.fillStyle = '#ef4444'; c.fillRect(d.x * k - 2, d.y * k - 2, d.w * k + 4, d.h * k + 4); });
    const pulse = (Math.sin(performance.now() / 160) + 1) / 2, dot = (x1, y1, colr, r) => { c.fillStyle = colr; c.strokeStyle = '#0b1020'; c.lineWidth = 2; c.beginPath(); c.arc(x1 * k, y1 * k, r * sc, 0, 7); c.fill(); c.stroke(); };
    if (mode === 'map') {
      if (S.tasksVisible) S.tasks.forEach(tk => { const def = BS.TASKS.find(d => d.id === tk.id); def.steps.forEach((s, i) => { if (!tk.done[i]) dot(BS.ST[s.st].x, BS.ST[s.st].y, '#ffd34d', 7); }); });
      if (S.sab) (S.sab.k === 'reactor' ? ['melt_a', 'melt_b'] : S.sab.k === 'lights' ? ['lights_panel'] : ['comms_panel']).forEach(id => dot(BS.ST[id].x, BS.ST[id].y, 'rgba(255,70,70,' + (0.5 + pulse / 2) + ')', 9 + pulse * 4));
      dot(S.x, S.y, col(S.color), 9);
    } else if (mode === 'admin') {
      BS.ROOMS.forEach((r, i) => { c.fillStyle = '#6ee7f9'; c.font = 'bold 34px system-ui'; c.fillText(S.admin && S.admin.rooms ? S.admin.rooms[i] : '–', (r.x + r.w / 2) * k, (r.y + r.h / 2 + 14) * k); });
      if (S.admin && S.admin.off) { c.fillStyle = 'rgba(0,0,0,.7)'; c.fillRect(0, 300, 870, 120); c.fillStyle = '#f87171'; c.font = 'bold 40px system-ui'; c.fillText('OFFLINE — comms are down', 435, 375); }
    }
  };
  const refreshers = [];
  if (mode === 'sab') {
    let sysBox = btns, doorBox = btns;
    if (small) {
      const panel = el('div', 'sabpanel', null, card);
      const a = el('div', 'sabcol', null, panel), b = el('div', 'sabcol', null, panel);
      el('div', 'sablabel', 'Systems', a); sysBox = el('div', 'sabrow', null, a);
      el('div', 'sablabel', 'Lock a room', b); doorBox = el('div', 'doorgrid', null, b);
    }
    [['reactor', 'melt_a', '☢ Reactor'], ['lights', 'lights_panel', '💡 Lights'], ['comms', 'comms_panel', '📡 Comms']].forEach(([s, st, label]) => {
      const rm = BS.ROOMS[BS.ST[st].room], b = el('button', 'sabbtn' + (small ? ' row' : ''), label, sysBox); if (!small) place(b, rm.x + rm.w / 2, rm.y + rm.h / 2 - 70);
      b.onclick = () => { app.send({ k: 'sab', s }); app.closeOverlays(); };
      refreshers.push(() => { b.disabled = S.scd > 0 || !!S.sab || S.doors.size > 0; b.textContent = label + (S.scd > 0 && !S.sab ? ' (' + Math.ceil(S.scd) + 's)' : ''); });
    });
    BS.ROOMS.forEach(r => {
      const b = el('button', 'sabbtn door' + (small ? ' cell' : ''), '', doorBox); if (!small) place(b, r.x + r.w / 2, r.y + r.h / 2 + 60);
      b.onclick = () => { app.send({ k: 'sab', s: 'doors', room: r.id }); app.closeOverlays(); };
      refreshers.push(() => { b.disabled = !!S.sab || S.dcd > 0 || S.doors.size > 0; b.textContent = '🔒 ' + (small ? r.name : '') + (S.dcd > 0 ? (small ? ' ' : '') + Math.ceil(S.dcd) + 's' : small ? '' : 'Lock'); });
    });
  }
  const tick = () => { draw(); refreshers.forEach(f => f()); };
  tick(); clearInterval(UI._mapT); UI._mapT = setInterval(tick, 150);
};
})(window);
