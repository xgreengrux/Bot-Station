# Bot Station

An online social-deduction party game for 4–10 players in the style of Among Us, with an original robot theme.
No bots, no server to run: one player hosts a party, friends join with a 5-letter code, an invite link, or by picking the party from the public list.

## Play / deploy on GitHub Pages
1. Put `index.html` in the root of a GitHub repo (it is fully self-contained).
2. Repo → Settings → Pages → "Deploy from a branch" → `main` / `(root)`.
3. Open the Pages URL, enter a name, press **Create party**, then share the code or press **Copy invite link**.
4. Friends open the link (or type the code and press **Join**, or use **Browse public parties**). The party leader presses **START GAME** once 4+ players are in.

## Browse public parties (the server selector)
**🔍 Browse public parties** on the title screen shows every active public party, live:
- the party code, its leader, a status (**In lobby**, **Starting…**, **In game**, **Full**), how many players it has, and everyone's name and robot;
- **search for people**: type a name (or just the start of one) and only the parties those players are in stay on screen, with the matching players highlighted. Separate several names with commas and choose **Any name** (parties with at least one of them) or **All names** (parties with every one of them). The start of a party code works as a search too;
- **Join** puts you into that party (enter your name at the top first). Parties that are full or already playing are listed, so you can see where your friends are, but cannot be joined;
- the list updates by itself: parties appear, fill up, start and vanish while you watch (a party whose leader's tab dies is removed within seconds).

New parties are **public by default**. Tick **Private party** on the title screen, or use the **Public / Private** chip in the lobby (leader only), to keep a party out of the list. A private party never contacts the list service at all; friends can still join with the code or invite link.

### How the list works (and its limits)
There is no game server, so the list lives on free public **MQTT brokers** used as a bulletin board (`js/mqtt.js` is a small MQTT-over-WebSocket client, `js/registry.js` the list logic):
- a public party's leader publishes a small *retained* message (code, status, player names/colours) to `botstation/v1/parties/<CODE>`, refreshes it every 25 s and whenever something changes, and registers a *last will* that makes the broker clear it if the leader's connection dies;
- the browse screen subscribes to `botstation/v1/parties/+`, receives the current retained messages at once and then live changes. Two brokers are used at the same time and merged, so one being down does not empty the list (`wss://broker.emqx.io:8084/mqtt`, `wss://broker.hivemq.com:8884/mqtt`);
- joining still goes through PeerJS exactly like joining by code; the list is only discovery. If no broker is reachable the screen says "Offline" and you can still join friends with their code.

Things to know:
- Public brokers are shared and unauthenticated. **Anyone who opens the list can see the names of the players in public parties**, and anyone can publish a fake entry (trying to join one just says no such party exists). Everything read from a broker is sanitised, but do not use real names, and use **Private party** for anything you do not want listed.
- You can point the list at your own broker: set `BS.REGISTRY_BROKERS = [{ url: 'wss://example.com:8884/mqtt', username: '…', password: '…' }]` before the game scripts load (see the top of `js/registry.js`).
- Listings that nobody refreshed for 75 s are dropped by the browser, at most 200 parties are kept, and 40 rows are drawn at once with a **Show more** button (searching always looks at all of them).

## How the online part works
- The party leader's browser is the game server. Everyone else connects to it peer-to-peer (WebRTC) through PeerJS and the free public PeerJS broker (loaded from the jsDelivr CDN).
- If the leader closes their tab the party ends; other players can leave/refresh and rejoin (they are held for 25 s).
- The free setup uses public STUN only. Some strict NATs / school or corporate networks need a TURN server: set `BS.PEER_OPTIONS` (see `js/net.js`) to your own PeerServer/TURN config.
- Adding `?local` to the URL swaps the network for a same-computer transport (several tabs of one browser), including the party list. The tests use it. `?broker=ws://localhost:PORT/mqtt` points the party list at a local test broker (loopback addresses only).

## Develop
`node build.js` rebuilds `index.html` from `index.src.html`, `css/` and `js/`.

Tests (run them one after another; the browser ones are heavy for small machines):
- `node test/map.test.js`, `node test/sim.test.js` – map and game rules;
- `node test/mqtt.test.js` (MQTT client against spec vectors and a mock broker), `node test/registry.test.js` (party list logic, search, expiry, reconnects);
- with Playwright installed: `node test/e2e.js`, `node test/e2e2.js` (a whole game in browser tabs), `node test/peer.e2e.js` (PeerJS code path with a stand-in for its API), `node test/e2e3.js` (party browser over the same-computer transport), `node test/e2e4.js` (party browser over MQTT with the mock broker in `test/mockbroker.js`).

The real public brokers and the real PeerJS cloud cannot be reached from the test environment, so those two network paths are verified against the specs and stand-ins rather than against the live services.
