// Bundles css + js into one self-contained index.html (plus keeps the sources readable).
const fs = require('fs'), path = require('path');
const root = __dirname;
const order = ['shared', 'host', 'host_game', 'host_meet', 'net', 'mqtt', 'registry', 'render', 'minigames', 'ui_menu', 'ui_browser', 'ui_game', 'client', 'play'];
const js = order.map(n => '/* ---- ' + n + '.js ---- */\n' + fs.readFileSync(path.join(root, 'js', n + '.js'), 'utf8')
  // the host files export for node tests; harmless in the browser but strip to keep the bundle clean
  .replace(/\nif \(typeof module !== 'undefined'\) module\.exports = Host;/, '')).join('\n');
const css = fs.readFileSync(path.join(root, 'css', 'style.css'), 'utf8');
let html = fs.readFileSync(path.join(root, 'index.src.html'), 'utf8');
if (js.includes('</script>')) throw new Error('script contains </script>');
html = html.replace('/*CSS*/', () => css).replace('/*JS*/', () => js);
fs.writeFileSync(path.join(root, 'index.html'), html);
console.log('index.html', (html.length / 1024).toFixed(1) + ' KB');
