/* Exercises the real-network code path (PeerJS) using a stand-in implementation of its API.
   Run: node test/peer.e2e.js */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), fake = require('./fakepeer.js');
let bad = 0;
const ok = (c, m) => { if (!c) bad++; console.log(c ? '  ok  :' : '  FAIL:', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const server = http.createServer((req, res) => { fs.readFile(path.join(root, 'index.html'), (e, d) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end(d); }); });

(async () => {
  await new Promise(r => server.listen(0, r));
  const url = 'http://localhost:' + server.address().port + '/';        // note: no ?local -> real PeerJS code path
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 1000, height: 700 } });
  await ctx.route(/peerjs/, r => r.abort());
  await ctx.addInitScript(fake);
  const errors = [], mk = async (name, pre) => { const p = await ctx.newPage(); if (pre) await p.addInitScript(pre); p.on('pageerror', e => errors.push(name + ': ' + e.message)); await p.goto(url); return p; };
  try {
    console.log('- party creation retries when a code is already taken');
    const A = await mk('A', 'window.__FAKE_FAIL_FIRST = true');
    await A.fill('#tName', 'Alice'); await A.click('#tCreate');
    await A.waitForSelector('#lobby:not(.hidden)', { timeout: 8000 });
    await A.waitForFunction(() => /^[A-Z]{5}$/.test(document.getElementById('lbCode').textContent));
    const code = (await A.textContent('#lbCode')).trim();
    ok(await A.evaluate(() => window.__FAKE_FAILED === 1), 'first code collided and a new one was generated: ' + code);

    console.log('- friends join over connections');
    const B = await mk('B'); await B.fill('#tName', 'Bob'); await B.fill('#tCode', code.toLowerCase()); await B.click('#tJoin');
    await B.waitForSelector('#lobby:not(.hidden)', { timeout: 8000 });
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 2);
    ok(true, 'Bob joined using the lower-case code');
    await B.fill('#lobby .chatform input', 'hi from bob'); await B.press('#lobby .chatform input', 'Enter');
    await A.waitForFunction(() => document.querySelector('#lobby .chatlog').textContent.includes('hi from bob'));
    ok(true, 'chat crosses the connection');
    await A.fill('#lobby .chatform input', 'hi from alice'); await A.press('#lobby .chatform input', 'Enter');
    await B.waitForFunction(() => document.querySelector('#lobby .chatlog').textContent.includes('hi from alice'));
    ok(true, 'chat works in the other direction too');

    console.log('- a wrong code gives a clear error');
    const C = await mk('C'); await C.fill('#tName', 'Cleo'); await C.fill('#tCode', 'ZZZZZ'); await C.click('#tJoin');
    await C.waitForFunction(() => /No party found/.test(document.getElementById('tMsg').textContent), null, { timeout: 6000 });
    ok(!(await C.evaluate(() => document.getElementById('tJoin').disabled)), 'title screen is usable again after the error');
    ok(await C.evaluate(() => !document.getElementById('title').classList.contains('hidden')), 'still on the title screen');

    console.log('- joining via an invite link');
    const D = await ctx.newPage(); D.on('pageerror', e => errors.push('D: ' + e.message)); await D.goto(url + '#' + code);
    ok((await D.inputValue('#tCode')) === code, 'invite link pre-fills the party code');
    await D.fill('#tName', 'Dan'); await D.click('#tJoin'); await D.waitForSelector('#lobby:not(.hidden)', { timeout: 8000 });
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 3);
    ok(true, 'Dan joined through the link (3 players)');

    console.log('- a player who vanishes is dropped, a refresh rejoins');
    await B.reload();                                   // same tab: token + party code survive in sessionStorage
    await B.waitForSelector('#lobby:not(.hidden)', { timeout: 10000 });
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 3);
    ok(await B.evaluate(() => document.getElementById('lbName').value === 'Bob'), 'Bob refreshed and is back in the party as Bob');
    await D.close();                                    // no goodbye message sent
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 2, null, { timeout: 25000 });
    ok(true, 'a silently disconnected player is removed after the idle timeout');

    console.log('- leader leaving closes the party');
    await A.click('.lb-actions .btn.danger');
    await B.waitForFunction(() => /leader left/.test(document.getElementById('tMsg').textContent), null, { timeout: 8000 });
    ok(true, 'remaining players are returned to the title screen with a message');
    ok(errors.length === 0, 'no page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  } catch (e) { bad++; console.log('  EXCEPTION:', e.message.split('\n')[0]); }
  await browser.close(); server.close();
  console.log(bad ? '\n' + bad + ' PROBLEM(S)' : '\nPEER PATH PASSED');
  process.exit(bad ? 1 : 0);
})();
