/* End-to-end: 4 headless browser tabs play a full party through the real UI (same-browser transport).
   Run: node test/e2e.js   (needs the globally installed playwright + chromium) */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const OUT = process.env.SHOTS || '/tmp/claude-0/-home-claude/657a804d-6327-5469-81d5-b8ece5fafb4b/scratchpad/shots';
fs.mkdirSync(OUT, { recursive: true });

let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('  FAIL:', m); } else console.log('  ok  :', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const server = http.createServer((req, res) => {
  const u = req.url.split('?')[0], f = path.join(root, u === '/' ? 'index.html' : u);
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'text/plain' }); res.end(d); });
});

(async () => {
  await new Promise(r => server.listen(0, r));
  const url = 'http://localhost:' + server.address().port + '/?local';
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 700 } });
  await ctx.route(/peerjs/, r => r.abort());
  const errors = [], pages = [], names = ['Alice', 'Bob', 'Cleo', 'Dan'];
  for (let i = 0; i < 4; i++) {
    const p = await ctx.newPage();
    p.on('pageerror', e => errors.push(names[i] + ': ' + e.message));
    p.on('console', m => { if (m.type() === 'error' && !/peerjs|Failed to load resource/.test(m.text())) errors.push(names[i] + ' console: ' + m.text()); });
    await p.goto(url); pages.push(p);
  }
  const [A, B] = pages;
  const shot = async (i, name) => pages[i].screenshot({ path: path.join(OUT, name + '.png') });
  const S = (p, expr) => p.evaluate(`(() => { const S = window.__BS.S; return ${expr}; })()`);
  const wait = (p, sel, timeout) => p.waitForSelector(sel, { timeout: timeout || 15000, state: /\.hidden/.test(sel) && !/not\(\.hidden\)/.test(sel) ? 'attached' : 'visible' });
  const hostEval = (expr) => A.evaluate(`(() => { const h = window.__BS.S.host; return ${expr}; })()`);
  const place = async (i, x, y) => {
    const id = await S(pages[i], 'S.id');
    await hostEval(`(() => { const p = h.players.get(${id}); p.x = ${x}; p.y = ${y}; p.ignoreUntil = 0; })()`);
    await pages[i].evaluate(`(() => { const S = window.__BS.S; S.x = ${x}; S.y = ${y}; })()`);
  };

  try {
    console.log('- title screen & party creation');
    await shot(0, '01-title');
    await A.fill('#tName', 'Alice'); await A.click('#tCreate');
    await wait(A, '#lobby:not(.hidden)');
    await A.waitForFunction(() => document.getElementById('lbCode').textContent.length === 5 && !/-/.test(document.getElementById('lbCode').textContent));
    const code = (await A.textContent('#lbCode')).trim();
    ok(/^[A-Z]{5}$/.test(code), 'party code generated: ' + code);

    console.log('- friends join with the code');
    for (let i = 1; i < 4; i++) {
      await pages[i].fill('#tName', names[i]); await pages[i].fill('#tCode', code); await pages[i].click('#tJoin');
      await wait(pages[i], '#lobby:not(.hidden)');
    }
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 4);
    ok(true, 'all four players appear in the party');
    const cols = await A.evaluate(() => [...document.querySelectorAll('#lbColors .sw.sel')].length);
    ok(cols === 1, 'exactly one colour selected for me');
    const leaderBadges = await B.evaluate(() => document.querySelectorAll('#lbPlayers .crown').length);
    ok(leaderBadges === 1, 'one party leader crown');
    ok(await B.evaluate(() => document.getElementById('lbStart').disabled), 'non-leader cannot start');
    ok(await B.evaluate(() => [...document.querySelectorAll('#lbSettings .mini')].every(b => b.disabled)), 'non-leader settings are read-only');
    ok(!(await A.evaluate(() => document.getElementById('lbStart').disabled)), 'leader can start with 4 players');
    await A.click('#lbSettings .srow:nth-child(2) .mini:last-child');   // killCd + step
    await sleep(300);
    ok((await B.textContent('#lbSettings .srow:nth-child(2) b')).includes('35'), 'leader changing a setting shows on other screens');
    await B.click('#lbColors .sw:not(.taken):not(.sel)');
    await sleep(300);
    ok(await A.evaluate(() => new Set([...document.querySelectorAll('#lbPlayers .pcard canvas')].map(c => c.toDataURL())).size >= 3), 'players have distinct looks');
    await B.fill('#lobby .chatform input', 'hello party'); await B.press('#lobby .chatform input', 'Enter');
    await A.waitForFunction(() => document.querySelector('#lobby .chatlog').textContent.includes('hello party'));
    ok(true, 'lobby chat reaches the leader');
    await shot(0, '02-lobby');

    console.log('- start, countdown, role reveal');
    await hostEval('(h.settings.discuss = 0, h.settings.voteTime = 15, 1)');
    await A.click('#lbStart');
    await wait(B, '#lbCd:not(.hidden)', 4000);
    ok(true, 'countdown shown to everyone');
    for (const p of pages) await wait(p, '#intro:not(.hidden)', 15000);
    ok(true, 'role reveal shown to everyone');
    await shot(1, '03-intro');
    for (const p of pages) await wait(p, '#intro.hidden', 12000);
    const roles = []; for (const p of pages) roles.push(await S(p, 'S.role'));
    ok(roles.filter(r => r === 'imp').length === 1 && roles.filter(r => r === 'crew').length === 3, 'one saboteur and three technicians: ' + roles.join());
    const iI = roles.indexOf('imp'), crewI = [0, 1, 2, 3].filter(i => i !== iI);
    const [c1, c2, c3] = crewI;
    ok((await S(pages[c1], 'S.tasks.length')) === 4 && (await S(pages[iI], 'S.tasks.every(t => t.fake)')), 'tasks assigned (saboteur gets fakes)');

    console.log('- movement is accepted by the host');
    await place(c1, 700, 640);
    await pages[c1].keyboard.down('d'); await sleep(450); await pages[c1].keyboard.up('d'); await sleep(300);
    const x1 = await S(pages[c1], 'S.x'), hx = await hostEval(`h.players.get(${await S(pages[c1], 'S.id')}).x`);
    ok(x1 > 740 && Math.abs(x1 - hx) < 30, 'walking works and matches the host (' + Math.round(x1) + ' vs ' + Math.round(hx) + ')');
    await place(c2, 900, 640); await sleep(300);
    ok((await S(pages[c1], 'S.others.size')) >= 1, 'nearby players are visible');

    console.log('- doing a task');
    const id1 = await S(pages[c1], 'S.id');
    await hostEval(`(h.players.get(${id1}).tasks = [{ id: 's_filter', done: [false], fake: false }], 1)`);
    await pages[c1].evaluate(`(() => { const S = window.__BS.S; S.tasks = [{ id: 's_filter', done: [false], fake: false }]; BS.UI.tasks(S); })()`);
    await place(c1, 1050, 140);
    await pages[c1].waitForFunction(() => !document.getElementById('bUse').disabled);
    await shot(c1, '04-near-task');
    await pages[c1].keyboard.press('e');
    await wait(pages[c1], '#panel:not(.hidden) .leaf');
    await shot(c1, '05-minigame');
    await sleep(1300);
    for (const l of await pages[c1].$$('.leaf')) await l.dispatchEvent('pointerdown');
    await wait(pages[c1], '#panel.hidden');
    await sleep(300);
    ok((await hostEval('h.progress()')) > 0, 'host counted the finished task');
    ok((await S(pages[c3], 'S.tp')) > 0 || (await B.textContent('#tbarTxt')).length > 0, 'task bar updates for everyone');

    console.log('- reactor sabotage needs two players');
    await hostEval('(h.G.sabCd = 0, 1)'); await sleep(400);
    await pages[iI].keyboard.press('x');
    await wait(pages[iI], '#mapov:not(.hidden) .sabbtn');
    await shot(iI, '06-sabotage-menu');
    await pages[iI].click('.sabbtn:has-text("Reactor")');
    await wait(pages[c2], '#alert:not(.hidden)');
    ok((await pages[c2].textContent('#alert')).includes('REACTOR'), 'meltdown alert shown to technicians');
    await place(c1, 1300, 360); await place(c2, 440, 360);
    for (const i of [c1, c2]) { await pages[i].waitForFunction(() => document.getElementById('bUse').textContent === 'STABILIZE'); await pages[i].keyboard.press('e'); await wait(pages[i], '#panel:not(.hidden) .holdbtn'); }
    await shot(c1, '07-reactor-panel');
    const b1 = await (await pages[c1].$('.holdbtn')).boundingBox(), b2 = await (await pages[c2].$('.holdbtn')).boundingBox();
    await pages[c1].mouse.move(b1.x + b1.width / 2, b1.y + b1.height / 2); await pages[c1].mouse.down();
    await sleep(700);
    ok((await hostEval('!!h.G.sab')), 'one holder alone does not stop the meltdown');
    await pages[c2].mouse.move(b2.x + b2.width / 2, b2.y + b2.height / 2); await pages[c2].mouse.down();
    await sleep(600);
    ok(!(await hostEval('!!h.G.sab')), 'two simultaneous holders stabilise the reactor');
    await pages[c1].mouse.up(); await pages[c2].mouse.up();
    await sleep(400);
    for (const i of [c1, c2]) if (await pages[i].$('#panel:not(.hidden)')) await pages[i].click('#panel .x');

    console.log('- lights sabotage and repair');
    await hostEval('(h.G.sabCd = 0, 1)'); await sleep(400);
    await pages[iI].keyboard.press('x'); await wait(pages[iI], '#mapov:not(.hidden) .sabbtn');
    await pages[iI].click('.sabbtn:has-text("Lights")');
    await pages[c3].waitForFunction(() => !document.getElementById('alert').classList.contains('hidden'));
    await place(c3, 1050, 1360);
    await pages[c3].waitForFunction(() => document.getElementById('bUse').textContent === 'FIX LIGHTS');
    await pages[c3].keyboard.press('e'); await wait(pages[c3], '#panel .swbtn');
    await sleep(1000);
    for (let k = 0; k < 6; k++) for (const b of await pages[c3].$$('.swbtn:not(.on)')) await b.click().catch(() => {});
    await sleep(800);
    ok(!(await hostEval('!!h.G.sab')), 'breaker panel repairs the lights');
    await place(c3, 250, 700);

    console.log('- elimination, report, vote');
    await hostEval(`(h.players.get(${await S(pages[iI], 'S.id')}).killCd = 0, 1)`);
    await pages[iI].evaluate('window.__BS.S.kcd = 0');
    const victim = c1, witness = c2;
    await place(iI, 300, 700); await place(victim, 340, 700); await place(witness, 255, 700);
    await place(c3, 1500, 1300); await sleep(400);
    await pages[iI].waitForFunction(() => !document.getElementById('bKill').disabled);
    await shot(iI, '08-before-kill');
    await pages[iI].keyboard.press('q');
    await wait(pages[victim], '#killov:not(.hidden)');
    ok(await S(pages[victim], '!S.alive'), 'victim is eliminated and sees the overlay');
    await shot(victim, '09-eliminated');
    await sleep(500);
    ok((await S(pages[witness], 'S.bodies.length')) === 1, 'a nearby technician sees the body');
    await pages[witness].waitForFunction(() => !document.getElementById('bReport').disabled);
    await pages[witness].keyboard.press('r');
    for (const p of pages) await wait(p, '#meeting:not(.hidden) .mcard');
    ok(true, 'reporting calls a meeting for everyone');
    await shot(witness, '10-meeting');
    await pages[witness].fill('#meeting .chatform input', 'it was ' + names[iI]); await pages[witness].press('#meeting .chatform input', 'Enter');
    await pages[c3].waitForFunction(() => document.querySelector('#meeting .chatlog').textContent.includes('it was'));
    ok(true, 'meeting chat works');
    ok(!(await pages[victim].evaluate(() => [...document.querySelectorAll('#meeting button.mcard')].length)), 'the ghost cannot vote');
    const voteFor = async (i, name) => {
      await pages[i].waitForFunction(() => document.querySelectorAll('#meeting button.mcard').length > 0, null, { timeout: 8000 });
      if (name) await pages[i].click(`#meeting button.mcard:has-text("${name}")`); else await pages[i].click('#meeting .meet-foot .btn:has-text("Skip")');
      await pages[i].click('#meeting .confirm .primary');
    };
    await voteFor(witness, names[iI]); await voteFor(c3, names[iI]); await voteFor(iI, null);
    await wait(pages[witness], '#meeting .vdots i', 8000);
    ok(true, 'votes are revealed');
    await shot(witness, '11-votes');
    for (const p of pages) await wait(p, '#eject:not(.hidden) .eline', 8000);
    await sleep(2200);
    await shot(witness, '12-eject');
    ok((await witness === undefined) || (await pages[witness].textContent('#etext')).includes('ejected'), 'ejection screen announces the result');
    for (const p of pages) await wait(p, '#over:not(.hidden)', 12000);
    const verdict = []; for (const p of pages) verdict.push((await p.textContent('#over .over-t')).trim());
    ok(verdict[iI] === 'DEFEAT' && crewI.every(i => verdict[i] === 'VICTORY'), 'technicians win, saboteur loses: ' + verdict.join());
    await shot(0, '13-gameover');

    console.log('- back to the lobby and a rematch');
    await A.click('#over .btn.primary');
    for (const p of pages) await wait(p, '#lobby:not(.hidden) .pcard', 8000);
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 4);
    ok(true, 'the party returns to the lobby intact');
    await A.click('#lbStart');
    for (const p of pages) await wait(p, '#intro:not(.hidden)', 15000);
    ok(true, 'a second game starts');
    for (const p of pages) await wait(p, '#intro.hidden', 12000);
    await sleep(500);
    await shot(0, '14-second-game');
    ok(await hostEval('h.errors === 0'), 'host raised no exceptions');
  } catch (e) {
    bad++; console.log('  EXCEPTION:', e.message.split('\n')[0]);
    for (let i = 0; i < pages.length; i++) await shot(i, 'fail-' + i).catch(() => {});
  }
  if (errors.length) { bad++; console.log('  page errors:\n   ' + [...new Set(errors)].join('\n   ')); } else ok(true, 'no page errors or console errors');
  await browser.close(); server.close();
  console.log(bad ? '\n' + bad + ' PROBLEM(S) — screenshots in ' + OUT : '\nE2E PASSED (' + n + ' checks) — screenshots in ' + OUT);
  process.exit(bad ? 1 : 0);
})();
