// A stand-in for the PeerJS browser API (Peer + DataConnection), carried over BroadcastChannel.
// Used only by test/peer.e2e.js to exercise js/net.js's real-network code path without internet access.
module.exports = `(function () {
  const bc = new BroadcastChannel('fakepeer');
  const peers = new Map();
  let seq = 0;
  class Emitter { constructor() { this._h = {}; } on(e, f) { (this._h[e] = this._h[e] || []).push(f); return this; } emit(e, ...a) { (this._h[e] || []).slice().forEach(f => f(...a)); } }
  class Conn extends Emitter {
    constructor(peer, remote, cid) { super(); this.peer = remote; this._p = peer; this._cid = cid; this.open = false; }
    send(d) { if (this.open) bc.postMessage({ t: 'data', to: this.peer, from: this._p.id, cid: this._cid, d: JSON.parse(JSON.stringify(d)) }); }
    close() { if (!this.open) return; this.open = false; bc.postMessage({ t: 'bye', to: this.peer, from: this._p.id, cid: this._cid }); this.emit('close'); }
  }
  class Peer extends Emitter {
    constructor(id, opts) {
      super();
      this.id = typeof id === 'string' ? id : 'anon-' + Math.random().toString(36).slice(2);
      this.named = typeof id === 'string'; this.conns = new Map(); peers.set(this.id, this);
      setTimeout(() => {
        if (window.__FAKE_FAIL_FIRST && !window.__FAKE_FAILED && this.named) { window.__FAKE_FAILED = 1; this.emit('error', { type: 'unavailable-id' }); return; }
        this.emit('open', this.id);
      }, 10);
    }
    connect(dest) {
      const cid = ++seq + '-' + Math.random().toString(36).slice(2), c = new Conn(this, dest, cid); this.conns.set(cid, c);
      bc.postMessage({ t: 'hello', to: dest, from: this.id, cid });
      setTimeout(() => { if (!c.open) this.emit('error', { type: 'peer-unavailable' }); }, 700);
      return c;
    }
    destroy() { this.conns.forEach(c => c.close()); peers.delete(this.id); this.emit('close'); }
    reconnect() {}
  }
  bc.onmessage = e => {
    const m = e.data, p = peers.get(m.to);
    if (!p) return;
    if (m.t === 'hello') {
      const c = new Conn(p, m.from, m.cid); p.conns.set(m.cid, c); p.emit('connection', c); c.open = true;
      bc.postMessage({ t: 'ack', to: m.from, from: p.id, cid: m.cid }); setTimeout(() => c.emit('open'), 0);
      return;
    }
    const c = p.conns.get(m.cid); if (!c) return;
    if (m.t === 'ack') { c.open = true; setTimeout(() => c.emit('open'), 0); }
    else if (m.t === 'data') c.emit('data', m.d);
    else if (m.t === 'bye' && c.open) { c.open = false; c.emit('close'); }
  };
  window.Peer = Peer;
})();`;
