/* Tests for js/mqtt.js: byte-level golden vectors from the MQTT 3.1.1 spec, stream parsing, and the client talking
   to the spec-following mock broker (retained, last-will, keep-alive, framing). Run: node test/mqtt.test.js */
const path = require('path');
require(path.join(__dirname, '..', 'js', 'mqtt.js'));
const { Client, Parser, encode: E } = globalThis.BS.Mqtt, broker = require('./mockbroker.js');
let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) bad++; console.log(c ? '  ok  :' : '  FAIL:', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (f, ms) => { const t = Date.now(); while (Date.now() - t < (ms || 3000)) { if (f()) return true; await sleep(15); } return f(); };
const hex = u => [...u].map(b => b.toString(16).padStart(2, '0')).join(' ');
const bytes = s => new Uint8Array(s.split(' ').map(h => parseInt(h, 16)));

function golden() {
  console.log('- packets match the byte layouts in the MQTT 3.1.1 spec');
  ok(hex(E.connect({ clientId: 'abc', keepalive: 60 })) === '10 0f 00 04 4d 51 54 54 04 02 00 3c 00 03 61 62 63', 'CONNECT (clean session, keep-alive 60, id "abc")');
  ok(hex(E.connect({ clientId: 'abc', keepalive: 60, will: { topic: 'w/t', payload: '', retain: true } })) === '10 16 00 04 4d 51 54 54 04 26 00 3c 00 03 61 62 63 00 03 77 2f 74 00 00', 'CONNECT with a retained, empty last-will (flags 0x26)');
  ok(hex(E.connect({ clientId: 'a', keepalive: 5, username: 'u', password: 'p' })) === '10 13 00 04 4d 51 54 54 04 c2 00 05 00 01 61 00 01 75 00 01 70', 'CONNECT with user name and password (flags 0xc2)');
  ok(hex(E.publish('a/b', 'hi', true)) === '31 07 00 03 61 2f 62 68 69', 'PUBLISH QoS 0 retained');
  ok(hex(E.publish('a/b', '', false)) === '30 05 00 03 61 2f 62', 'PUBLISH with an empty payload');
  ok(hex(E.subscribe(1, 'a/#')) === '82 08 00 01 00 03 61 2f 23 00', 'SUBSCRIBE packet id 1, filter a/#, QoS 0 (fixed header 0x82)');
  ok(hex(E.pingreq()) === 'c0 00' && hex(E.disconnect()) === 'e0 00', 'PINGREQ and DISCONNECT');
  const big = E.publish('t', 'x'.repeat(200), false);
  ok(big[1] === 0xcb && big[2] === 0x01 && big.length === 3 + 203, 'remaining length uses the 2-byte varint above 127 (203 = cb 01)');
  const huge = E.publish('t', 'x'.repeat(20000), false);
  ok(huge[1] === (20003 % 128 | 128) && huge[2] === ((Math.floor(20003 / 128) % 128) | 128) && huge[3] === 1 && huge.length === 4 + 20003, '3-byte varint for a 20 KB payload');
  ok(hex(E.publish('é/ü', 'ñ', false)) === '30 09 00 05 c3 a9 2f c3 bc c3 b1', 'UTF-8 strings are length-prefixed in bytes');
}

function parser() {
  console.log('- the parser copes with split and merged frames');
  const got = [], p = new Parser((b0, body) => got.push([b0, hex(body)]));
  const a = E.publish('a', 'one', false), b = E.publish('b', 'two', true), all = new Uint8Array([...a, ...b, 0xd0, 0]);
  for (const x of all) p.push(new Uint8Array([x]));
  ok(got.length === 3 && got[0][0] === 0x30 && got[1][0] === 0x31 && got[2][0] === 0xd0, 'three packets delivered one byte at a time');
  got.length = 0; p.push(all);
  ok(got.length === 3, 'three packets in one chunk');
  got.length = 0; p.push(new Uint8Array([0x30, 0xff, 0xff, 0xff, 0x7f]));
  ok(got.length === 0, 'the largest legal declared length (4 bytes) just waits for data');
  let threw = false; try { new Parser(() => {}).push(new Uint8Array([0x30, 0x80, 0x80, 0x80, 0x80, 0x01])); } catch (e) { threw = true; }
  ok(threw, 'a length of more than four bytes is rejected');
}

const mk = (url, o) => {
  const c = { msgs: [], open: false, closed: null, subs: [] };
  c.client = new Client(url, Object.assign({ clientId: 'c' + Math.random().toString(36).slice(2, 9), keepalive: 30, onOpen: () => { c.open = true; }, onMessage: (t, p, r) => c.msgs.push({ t, p, r }), onClose: why => { c.closed = why; c.open = false; }, onSub: v => c.subs.push(v) }, o));
  return c;
};

async function suite(label, bopts) {
  console.log('- client <-> broker (' + label + ')');
  const B = await broker.start(bopts), url = B.url;
  const pub = mk(url, {}), sub = mk(url, {});
  ok(await until(() => pub.open && sub.open), 'both clients connect (CONNACK accepted)');
  pub.client.publish('bs/p/AAAAA', '{"n":1}', true);
  pub.client.publish('bs/p/BBBBB', 'ünï ✓', true);
  await until(() => B.retained.size === 2);
  sub.client.subscribe('bs/p/+');
  ok(await until(() => sub.msgs.length === 2), 'a late subscriber receives both retained messages');
  ok(sub.msgs.every(m => m.r === true), 'retained deliveries carry RETAIN=1');
  ok(sub.msgs.find(m => m.t === 'bs/p/BBBBB').p === 'ünï ✓', 'unicode payloads survive');
  ok(sub.subs[0] === true, 'SUBACK reports success');
  sub.msgs.length = 0;
  pub.client.publish('bs/p/AAAAA', '{"n":2}', true);
  ok(await until(() => sub.msgs.length === 1) && sub.msgs[0].r === false && sub.msgs[0].p === '{"n":2}', 'a live update arrives with RETAIN=0');
  pub.client.publish('bs/p/AAAAA', '', true);
  ok(await until(() => sub.msgs.length === 2 && sub.msgs[1].p === ''), 'an empty retained publish is forwarded');
  ok(!B.retained.has('bs/p/AAAAA'), 'and it deletes the retained message on the broker');
  const late = mk(url, {}); await until(() => late.open); late.client.subscribe('bs/p/#');
  await until(() => late.msgs.length >= 1); await sleep(80);
  ok(late.msgs.length === 1 && late.msgs[0].t === 'bs/p/BBBBB', 'a new subscriber only sees what is still retained');
  const none = mk(url, {}); await until(() => none.open); none.client.subscribe('other/#'); await sleep(120);
  ok(none.msgs.length === 0, 'topic filters are respected');
  none.client.subscribe('bad/#/x'); await until(() => none.subs.length === 2);
  ok(none.subs[1] === false, 'an invalid filter is refused in the SUBACK');

  console.log('- last-will (' + label + ')');
  const w = mk(url, { will: { topic: 'bs/p/WILLY', payload: '', retain: true } });
  await until(() => w.open); w.client.publish('bs/p/WILLY', '{"alive":1}', true);
  await until(() => B.retained.has('bs/p/WILLY')); sub.msgs.length = 0;
  B.dropAll(c => c.id === w.client.o.clientId);
  ok(await until(() => !B.retained.has('bs/p/WILLY')), 'a dropped connection fires the last-will and clears the retained entry');
  ok(await until(() => sub.msgs.some(m => m.t === 'bs/p/WILLY' && m.p === '')), 'subscribers are told the party is gone');
  ok(await until(() => w.closed !== null), 'the dropped client learns its connection closed (' + w.closed + ')');
  const g = mk(url, { will: { topic: 'bs/p/GRACE', payload: '', retain: true } });
  await until(() => g.open); g.client.publish('bs/p/GRACE', 'x', true); await until(() => B.retained.has('bs/p/GRACE'));
  sub.msgs.length = 0; g.client.close(true); await sleep(250);
  ok(B.retained.has('bs/p/GRACE') && !sub.msgs.some(m => m.t === 'bs/p/GRACE'), 'a graceful DISCONNECT discards the will (nothing is published)');

  console.log('- keep-alive and take-over (' + label + ')');
  const k = mk(url, { keepalive: 2, will: { topic: 'bs/p/KEEPA', payload: '', retain: true } });
  await until(() => k.open); k.client.publish('bs/p/KEEPA', 'alive', true);
  await sleep(4500);
  ok(k.open && B.retained.has('bs/p/KEEPA'), 'a client that pings stays connected well past 1.5x its keep-alive');
  const q = mk(url, { keepalive: 1, will: { topic: 'bs/p/QUIET', payload: '', retain: true } });
  await until(() => q.open); q.client.publish('bs/p/QUIET', 'alive', true); q.client.pulse = () => {};   // goes silent
  ok(await until(() => !B.retained.has('bs/p/QUIET'), 4000), 'a silent client is dropped after 1.5x keep-alive and its will fires');
  const same = 'dup-' + Math.random().toString(36).slice(2, 6);
  const d1 = mk(url, { clientId: same, will: { topic: 'bs/p/DUPES', payload: '', retain: true } }); await until(() => d1.open);
  const d2 = mk(url, { clientId: same }); await until(() => d2.open);
  ok(await until(() => d1.closed !== null) && d2.open, 'a second connection with the same client id takes over');

  console.log('- big payloads (' + label + ')');
  const bigText = JSON.stringify({ p: Array.from({ length: 400 }, (_, i) => ['Player ' + i, i % 12, i % 6, 1]) });
  pub.client.publish('bs/p/BIGGY', bigText, true); sub.msgs.length = 0;
  ok(await until(() => sub.msgs.some(m => m.t === 'bs/p/BIGGY' && m.p === bigText)), 'a ' + bigText.length + '-byte payload round-trips (multi-byte remaining length)');

  [pub, sub, late, none, g, k, q, d2].forEach(c => c.client.close(true));
  await B.close();
}

async function failures() {
  console.log('- failures are reported');
  const B = await broker.start({ auth: { user: 'me', pass: 'secret' } });
  const bad1 = mk(B.url, {}); ok(await until(() => bad1.closed !== null) && /refused:4/.test(bad1.closed), 'wrong credentials: CONNACK 4 -> "' + bad1.closed + '"');
  const good = mk(B.url, { username: 'me', password: 'secret' }); ok(await until(() => good.open), 'correct credentials are accepted');
  good.client.close(true);
  const url = B.url; await B.close();
  const gone = mk(url, {}); ok(await until(() => gone.closed !== null), 'a broker that is down -> onClose("' + gone.closed + '")');
  const B2 = await broker.start({ refuse: true });
  const ref = mk(B2.url, {}); ok(await until(() => ref.closed !== null), 'a broker that refuses the upgrade -> onClose("' + ref.closed + '")');
  await B2.close();
  const nowhere = mk('ws://127.0.0.1:1/mqtt', {}); ok(await until(() => nowhere.closed !== null), 'an unreachable port -> onClose("' + nowhere.closed + '")');
}

(async () => {
  golden(); parser();
  await suite('plain', {});
  await suite('packets split across frames', { split: true });
  await suite('packets merged into one frame', { coalesce: true });
  await failures();
  console.log(bad ? '\n' + bad + ' of ' + n + ' CHECKS FAILED' : '\nMQTT: all ' + n + ' checks passed');
  process.exit(bad ? 1 : 0);
})();
