/* Party browser, end to end in real browser tabs over the same-computer transport (?local):
   public/private parties, live list, name search, joining from the list, closing, in-game status.
   Run: node test/e2e3.js */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const OUT = process.env.SHOTS || '/tmp/claude-0/-home-claude/657a804d-6327-5469-81d5-b8ece5fafb4b/scratchpad/shots';
fs.mkdirSync(OUT, { recursive: true });
let bad = 0;
const ok = (c, m) => { if (!c) bad++; console.log(c ? '  ok  :' : '  FAIL:', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const server = http.createServer((req, res) => { fs.readFile(path.join(root, 'index.html'), (e, d) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end(d); }); });

(async () => {
  await new Promise(r => server.listen(0, r));
  const url = 'http://localhost:' + server.address().port + '/?local';
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 1100, height: 760 } });
  await ctx.route(/peerjs/, r => r.abort());
  const errors = [], mk = async name => { const p = await ctx.newPage(); p.on('pageerror', e => errors.push(name + ': ' + e.message)); await p.goto(url); return p; };
  const waitSel = (p, sel, t) => p.waitForSelector(sel, { timeout: t || 8000, state: /\.hidden/.test(sel) && !/not\(\.hidden\)/.test(sel) ? 'attached' : 'visible' });
  const count = (p, sel) => p.evaluate(s => document.querySelectorAll(s).length, sel);
  const cards = p => p.evaluate(() => [...document.querySelectorAll('#bwList .bparty')].map(c => c.dataset.code));
  const until = (p, fn, arg, t) => p.waitForFunction(fn, arg, { timeout: t || 6000 });
  const shot = (p, n) => p.screenshot({ path: path.join(OUT, n + '.png') });
  const create = async (p, name, priv) => { await p.fill('#tName', name); if (priv) await p.check('#tPrivate'); else await p.uncheck('#tPrivate'); await p.click('#tCreate'); await waitSel(p, '#lobby:not(.hidden)'); await until(p, () => /^[A-Z]{5}$/.test(document.getElementById('lbCode').textContent)); return (await p.textContent('#lbCode')).trim(); };
  const joinCode = async (p, name, code) => { await p.fill('#tName', name); await p.fill('#tCode', code); await p.click('#tJoin'); await waitSel(p, '#lobby:not(.hidden)'); };
  const openBrowser = async p => { await p.click('#tBrowse'); await waitSel(p, '#browser:not(.hidden)'); };
  try {
    const [A, B, C, D, E] = [await mk('A'), await mk('B'), await mk('C'), await mk('D'), await mk('E')];

    console.log('- a public party appears in the browser');
    const code = await create(A, 'Alice');
    ok((await A.textContent('#lbVis')).includes('Public'), 'new parties are public by default (lobby shows "Public party")');
    await openBrowser(B);
    await waitSel(B, '#bwList .bparty[data-code="' + code + '"]');
    ok(true, 'Bob opens Browse parties and sees party ' + code);
    ok((await B.textContent('#bwList .bparty .bp-leader')).includes('Alice'), 'with its leader');
    ok((await B.textContent('#bwList .bparty .pill')).includes('In lobby · 1/10'), 'its status and player count');
    ok((await B.textContent('#bwLive')).includes('Live'), 'the screen says it is live');
    ok(!(await B.$eval('#bwList .bparty .btn', b => b.disabled)), 'and Join is available');
    await until(B, () => /1 public party · 1 player/.test(document.getElementById('bwCount').textContent));
    ok(true, 'the footer counts parties and players');

    console.log('- searching for people');
    await B.fill('#bwQuery', 'ali');
    await until(B, () => document.querySelectorAll('#bwList .chip.hit').length === 1);
    ok((await B.textContent('#bwList .chip.hit')).trim() === 'Alice', 'typing part of a name keeps the party and highlights that player');
    await B.fill('#bwQuery', 'zzz');
    await until(B, () => document.querySelectorAll('#bwList .bparty').length === 0);
    ok(/No public party matches/.test(await B.textContent('#bwList .bw-empty')), 'no match -> a clear message');
    await B.click('#bwList .bw-empty .btn');
    await waitSel(B, '#bwList .bparty');
    ok((await B.inputValue('#bwQuery')) === '', 'the message offers a one-click "Clear search"');
    await B.fill('#bwQuery', code.slice(0, 3).toLowerCase());
    await waitSel(B, '#bwList .bp-code.hit');
    ok(true, 'the start of the party code works as a search too');
    await B.click('#bwClear'); await waitSel(B, '#bwList .bparty');

    console.log('- the list is live');
    await joinCode(C, 'Cleo', code);
    await until(B, () => document.querySelectorAll('#bwList .bparty .chip').length === 2);
    ok((await B.textContent('#bwList .bparty .pill')).includes('2/10'), 'Cleo joins the party and Bob\'s list updates by itself');
    await B.fill('#bwQuery', 'cleo, nobody');
    await waitSel(B, '#bwList .bparty');
    ok(true, 'several names with commas: "Any" finds the party if one of them is in it');
    await B.click('.seg-b[data-mode="all"]');
    await until(B, () => document.querySelectorAll('#bwList .bparty').length === 0);
    ok(true, '"All" hides it because "nobody" is not in it');
    await B.fill('#bwQuery', 'alice, cleo');
    await until(B, () => document.querySelectorAll('#bwList .chip.hit').length === 2);
    ok(true, '"All" with two people who are both in the party shows it with both highlighted');
    await shot(B, '40-browser-search');
    await B.click('.seg-b[data-mode="any"]'); await B.click('#bwClear'); await waitSel(B, '#bwList .bparty');

    console.log('- private parties stay hidden, and the leader can switch');
    const pcode = await create(D, 'Dan', true);
    ok((await D.textContent('#lbVis')).includes('Private'), 'a party created as private says "Private party"');
    await sleep(2600);
    ok((await cards(B)).join() === code, 'a private party is not listed (' + (await cards(B)).join() + ')');
    await D.click('#lbVis');
    await until(B, c => [...document.querySelectorAll('#bwList .bparty')].some(x => x.dataset.code === c), pcode);
    ok((await D.textContent('#lbVis')).includes('Public'), 'the leader makes it public from the lobby and it shows up');
    await B.fill('#bwQuery', 'dan');
    await until(B, () => document.querySelectorAll('#bwList .bparty').length === 1);
    ok((await cards(B)).join() === pcode, 'searching for Dan finds Dan\'s party only');
    await B.fill('#bwQuery', '');
    await D.click('#lbVis');
    await until(B, () => document.querySelectorAll('#bwList .bparty').length === 1);
    ok(true, 'making it private again removes it');
    ok(!(await A.$eval('#lbVis', b => b.disabled)), 'the leader\'s Public/Private chip is clickable');
    ok(await C.$eval('#lbVis', b => b.disabled), 'Cleo (not the leader) cannot change it');

    console.log('- joining from the list');
    await B.fill('#bwName', '');
    await B.click('#bwList .bparty .btn');
    ok(/Pick a name/.test(await B.textContent('#bwMsg')) && (await B.$eval('#browser', e => !e.classList.contains('hidden'))), 'Join without a name asks for one and stays on the list');
    await B.fill('#bwName', 'Bob');
    await B.click('#bwList .bparty .btn');
    await waitSel(B, '#lobby:not(.hidden)');
    await until(A, () => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 3);
    ok(true, 'Bob joined from the list: the party has Alice, Cleo and Bob');
    ok(await B.evaluate(() => window.__BS.S.watch === null), 'and the list connection was closed');

    console.log('- closing a party removes it');
    await openBrowser(E);
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 1 || document.querySelectorAll('#bwList .bparty').length === 2);
    await D.click('#lbVis');
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 2);
    ok(true, 'a second public party shows up for Eve');
    await D.click('.lb-actions .btn.danger');
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 1, null, 8000);
    ok(true, 'when Dan leaves his party it disappears from Eve\'s list');

    console.log('- a running game');
    await waitSel(D, '#title:not(.hidden)'); await joinCode(D, 'Dan', code);
    await until(A, () => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 4);
    await until(E, () => /4\/10/.test(document.querySelector('#bwList .bparty .pill').textContent));
    await A.click('#lbStart');
    await until(E, () => /Starting/.test(document.querySelector('#bwList .bparty .pill').textContent), null, 8000);
    ok(true, 'the list shows "Starting…" during the countdown');
    await until(E, () => /In game · 4\/10/.test(document.querySelector('#bwList .bparty .pill').textContent), null, 20000);
    ok(true, 'and "In game · 4/10" once it has begun');
    ok(await E.$eval('#bwList .bparty .btn', b => b.disabled && /In game/.test(b.textContent)), 'with a disabled Join button');
    await E.fill('#bwQuery', 'dan');
    await until(E, () => document.querySelectorAll('#bwList .chip.hit').length === 1);
    ok(true, 'you can still search for friends who are in a running game');
    await shot(E, '41-browser-ingame');
    await E.fill('#bwQuery', ''); await E.fill('#bwName', 'Eve');
    await E.evaluate(c => window.__BS.App.joinFromBrowser(c, 'Eve'), code);
    await until(E, () => /already in progress/.test(document.getElementById('bwMsg').textContent), null, 8000);
    ok(await E.$eval('#browser', e => !e.classList.contains('hidden')), 'a rejected join returns to the list with the reason');
    ok(await E.evaluate(() => window.__BS.S.watch !== null), 'and the live list is running again');

    console.log('- a long list');
    const F = await mk('F');
    await F.evaluate(() => {
      const L = 'ABCDEFGHJKLMNPQRSTUVWXYZ', pubs = [];
      for (let i = 0; i < 45; i++) {
        const c = 'ZZ' + L[Math.floor(i / 24)] + L[i % 24] + 'Q', ld = 'Fake' + i;
        const pub = BS.Registry.publish(c, () => ({ c, ph: 'lobby', n: 2, max: 10, min: 4, ld, p: [[ld, i % 12, i % 6, 1], ['Pal' + i, (i + 3) % 12, 0, 1]] }));
        pub.tick(); pubs.push(pub);
      }
      window.__pubs = pubs;
    });
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 40 && !!document.querySelector('#bwList .bw-more'), null, 12000);
    ok(true, '45 more parties show up: 40 rows are drawn and a "Show more" button holds the rest');
    ok(/Show 6 more/.test(await E.textContent('#bwList .bw-more')), 'it says how many more it will show (' + (await E.textContent('#bwList .bw-more')).trim() + ')');
    ok((await E.textContent('#bwCount')).includes('46 public parties'), 'the footer still counts all of them (' + (await E.textContent('#bwCount')).trim() + ')');
    await shot(E, '42-browser-long');
    const first = await E.evaluate(() => { window.__row = document.querySelector('#bwList .bparty'); return window.__row.dataset.code; });
    const q0 = await E.evaluate(c => window.__BS.S.browse.list.find(p => p.code === c).q, first);
    await F.evaluate(() => { BS.Registry.now = () => Date.now() + 30000; window.__pubs.forEach(p => p.tick()); });     // every party sends a heartbeat
    await until(E, a => window.__BS.S.browse.list.find(p => p.code === a[0]).q > a[1], [first, q0], 8000);
    await sleep(200);
    ok(await E.evaluate(() => document.querySelector('#bwList .bparty') === window.__row), 'a heartbeat leaves the row alone (a click in progress is never swallowed by a rebuild)');
    await E.fill('#bwQuery', 'alice');
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 1);
    ok((await cards(E)).join() === code, 'searching reaches parties that are not drawn yet (Alice\'s running game)');
    await E.fill('#bwQuery', 'fake12');
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 1 && !document.querySelector('#bwList .bw-more'));
    ok(true, 'a narrow search has no "Show more" button');
    await E.fill('#bwQuery', '');
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 40 && !!document.querySelector('#bwList .bw-more'));
    await E.click('#bwList .bw-more');
    await until(E, () => document.querySelectorAll('#bwList .bparty').length === 46 && !document.querySelector('#bwList .bw-more'));
    ok(true, '"Show more" draws the rest');

    ok(errors.length === 0, 'no page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  } catch (e) { bad++; console.log('  EXCEPTION:', e.message.split('\n').slice(0, 3).join(' | ')); if (errors.length) console.log('  page errors:', errors.join(' | ')); }
  await browser.close(); server.close();
  console.log(bad ? '\n' + bad + ' PROBLEM(S)' : '\nE2E-3 PASSED');
  process.exit(bad ? 1 : 0);
})();
