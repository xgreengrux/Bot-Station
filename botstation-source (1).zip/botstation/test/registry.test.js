/* Tests for js/registry.js: search, sanitising, sorting, and the publisher/browser over the real MQTT client
   (against the mock broker) and over the same-computer BroadcastChannel transport. Run: node test/registry.test.js */
const path = require('path');
const js = f => path.join(__dirname, '..', 'js', f);
require(js('mqtt.js')); require(js('registry.js'));
const BS = globalThis.BS, R = BS.Registry, broker = require('./mockbroker.js');
let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) bad++; console.log(c ? '  ok  :' : '  FAIL:', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (f, ms) => { const t = Date.now(); while (Date.now() - t < (ms || 4000)) { if (f()) return true; await sleep(15); } return f(); };
let fake = Date.now(); R.now = () => fake;                      // a clock the tests can wind forward
const adv = ms => { fake += ms; };

const wire = (code, extra) => JSON.stringify(Object.assign({ v: 1, q: 1, ph: 'lobby', n: 2, max: 10, min: 4, ld: 'Alice', p: [['Alice', 1, 2, 1], ['Bob', 3, 0, 1]] }, extra));
const party = (code, names, extra) => R.sanitize({ v: 1, q: 1, ph: 'lobby', max: 10, ld: names[0], p: names.map((x, i) => [x, i, 0, 1]) }, code) && Object.assign(R.sanitize({ v: 1, q: 1, ph: 'lobby', max: 10, ld: names[0], p: names.map((x, i) => [x, i, 0, 1]) }, code), extra || {});

function helpers() {
  console.log('- sanitising what other browsers publish');
  const p = R.sanitize(JSON.parse(wire('AAAAA')), 'AAAAA');
  ok(p && p.code === 'AAAAA' && p.players.length === 2 && p.players[1].name === 'Bob' && p.leader === 'Alice' && p.phase === 'lobby', 'a normal announcement becomes a party record');
  ok(R.sanitize({ v: 2, p: [['x']] }, 'AAAAA') === null && R.sanitize(null, 'AAAAA') === null && R.sanitize({ v: 1, p: [] }, 'AAAAA') === null && R.sanitize({ v: 1 }, 'AAAAA') === null, 'wrong version, empty or missing players are rejected');
  const evil = R.sanitize({ v: 1, ph: 'weird', max: 99, ld: '<img src=x onerror=alert(1)>'.repeat(3), p: Array.from({ length: 40 }, (_, i) => ['<b>' + 'N'.repeat(50) + '</b>"&', 999, -5, 1]) }, 'ZZZZZ');
  ok(evil.players.length === 10 && evil.players.every(x => x.name.length <= 12 && !/[<>&"]/.test(x.name)), 'names are truncated and stripped of markup, at most 10 players');
  ok(evil.players[0].color === 11 && evil.players[0].hat === 0 && evil.phase === 'game' && evil.max === 10 && !/[<>&"]/.test(evil.leader), 'colours/hats are clamped, unknown phases count as in-game');
  ok(R.sanitize({ v: 1, ph: 'lobby', p: [[null, 'x', 'y', 0]] }, 'AAAAA').players[0].name === '?', 'garbage player fields do not throw');

  console.log('- joinable and ordering');
  const open = party('BBBBB', ['A', 'B', 'C']), full = party('CCCCC', Array.from({ length: 10 }, (_, i) => 'P' + i)), game = party('DDDDD', ['A', 'B', 'C', 'D', 'E'], { phase: 'game' }), small = party('AAAAA', ['A', 'B']), cd = party('EEEEE', ['A', 'B', 'C', 'D'], { phase: 'countdown' });
  ok(R.joinable(open) && R.joinable(cd) && !R.joinable(full) && !R.joinable(game), 'lobby/countdown with room is joinable; full or in-game is not');
  ok(R.sort([game, small, full, open, cd]).map(x => x.code).join('') === 'EEEEEBBBBBAAAAACCCCCDDDDD', 'open parties first (fullest first), then full, then in-game');

  console.log('- searching for people');
  const parties = [party('KQXZR', ['Alice', 'Bob', 'Cleo']), party('MNOPQ', ['Dan', 'alice2']), party('RSTUV', ['Eve', 'Frank'])];
  const find = (q, mode) => parties.filter(x => R.match(x, R.terms(q), mode).ok).map(x => x.code).join(',');
  ok(find('') === 'KQXZR,MNOPQ,RSTUV', 'an empty search shows everything');
  ok(find('alice') === 'KQXZR,MNOPQ', 'partial, case-insensitive name match (alice matches Alice and alice2)');
  ok(find('  BOB ') === 'KQXZR', 'extra spaces and capitals are ignored');
  ok(find('alice, frank') === 'KQXZR,MNOPQ,RSTUV', 'comma-separated names: any of them (default)');
  ok(find('alice, bob', 'all') === 'KQXZR' && find('alice, dan', 'all') === 'MNOPQ' && find('bob, dan', 'all') === '', '"all" needs every name in the same party');
  ok(find('nobody') === '', 'no match -> no parties');
  ok(find('kqx') === 'KQXZR' && find('KQXZR') === 'KQXZR' && find('kq') === '', 'a party code matches by prefix once you typed 3+ letters');
  ok(find(',,') === 'KQXZR,MNOPQ,RSTUV', 'only commas behaves like an empty search');
  const m = R.match(parties[0], R.terms('cleo, bob'), 'any');
  ok(m.hits.join() === '1,2' && m.code === false, 'the match reports which players to highlight (' + m.hits + ')');
  ok(R.match(parties[0], R.terms('kqx'), 'any').code === true, 'and whether the code matched');
  ok(R.topicMatch('a/+', 'a/b') && !R.topicMatch('a/+', 'a/b/c') && R.topicMatch('a/#', 'a/b/c') && !R.topicMatch('a/b', 'a/c'), 'topic filters (+ and #) work for the local transport');
}

const info = (names, ph) => () => ({ c: 'x', ph: ph || 'lobby', n: names.length, max: 10, min: 4, ld: names[0], p: names.map((x, i) => [x, i, 0, 1]) });

async function mqttPath() {
  console.log('- publisher and browser over MQTT (mock broker)');
  const B = await broker.start({ coalesce: true });
  const cfg = [{ url: B.url }], seen = []; let latest = [], st = null;
  const w = R.watch({ onChange: (l, s) => { latest = l; st = s; seen.push(l.map(x => x.code).join()); } }, { brokers: cfg });
  ok(await until(() => st && st.state === 'live' && st.ready), 'the browser connects and reports "live" and "ready" with nothing listed');
  ok(latest.length === 0, 'an empty board lists no parties');

  let names = ['Alice', 'Bob'];
  const pub = R.publish('KQXZR', () => ({ c: 'KQXZR', ph: 'lobby', n: names.length, max: 10, min: 4, ld: names[0], p: names.map((x, i) => [x, i, 0, 1]) }), { brokers: cfg });
  adv(1100); pub.tick(); await until(() => pub.up() === 1);
  ok(await until(() => latest.length === 1 && latest[0].code === 'KQXZR'), 'a public party appears on the board');
  ok(latest[0].players.map(x => x.name).join() === 'Alice,Bob' && latest[0].leader === 'Alice' && latest[0].phase === 'lobby', 'with its players, leader and status');
  const q1 = pub.seq; adv(1100); pub.tick(); await sleep(60);
  ok(pub.seq === q1 && B.log.filter(l => l.startsWith('pub bs')).length === 0 && B.log.filter(l => l.startsWith('pub botstation')).length === 1, 'nothing is re-sent while nothing changes (seq ' + pub.seq + ')');
  names = ['Alice', 'Bob', 'Cleo']; adv(1100); pub.tick();
  ok(await until(() => latest[0] && latest[0].players.length === 3) && pub.seq === q1 + 1, 'a new player shows up within one check');
  adv(R.HEARTBEAT + 100); pub.tick(); ok(pub.seq === q1 + 2, 'a heartbeat is sent even when nothing changed');

  console.log('- cleaning up');
  const w2 = R.watch({ onChange: () => {} }, { brokers: cfg });
  ok(await until(() => w2.list().length === 1), 'a browser opened later receives the retained announcement immediately');
  const mine = [...B.clients].find(c => c.will && c.will.topic === R.ROOT + 'KQXZR');
  B.dropAll(c => c === mine);
  ok(await until(() => latest.length === 0), 'if the leader\'s connection dies the last-will removes the listing');
  ok(await until(() => latest.length === 1 && latest[0].code === 'KQXZR', 5000), 'and when the leader reconnects (backoff) the party is announced again');
  const retainedBefore = B.retained.size; adv(1100);
  names = ['Alice']; pub.tick();
  ok(await until(() => latest[0] && latest[0].players.length === 1), 'players leaving updates the listing');
  let isPrivate = false; const priv = R.publish('MNOPQ', () => (isPrivate ? null : { c: 'MNOPQ', ph: 'lobby', n: 1, max: 10, min: 4, ld: 'Zed', p: [['Zed', 2, 0, 1]] }), { brokers: cfg });
  adv(1100); priv.tick(); await until(() => priv.up() === 1);
  ok(await until(() => latest.length === 2), 'a second party is listed too');
  isPrivate = true; adv(1100); priv.tick();
  ok(priv.conns.length === 0, 'a private party holds no broker connection');
  ok(await until(() => latest.length === 1 && latest[0].code === 'KQXZR') && !B.retained.has(R.ROOT + 'MNOPQ'), 'switching a party to private removes it right away');
  isPrivate = false; adv(1100); priv.tick();
  ok(await until(() => latest.length === 2), 'and switching back lists it again');
  priv.close();
  ok(await until(() => latest.length === 1) && !B.retained.has(R.ROOT + 'MNOPQ'), 'closing a party removes the listing');
  ok(!B.log.some(l => /^will botstation\/v1\/parties\/MNOPQ/.test(l)), 'a clean close does not rely on the last-will');

  console.log('- the board is untrusted');
  const raw = new BS.Mqtt.Client(B.url, { clientId: 'junk', keepalive: 30 });
  await until(() => raw.connected);
  const put = (code, text, retain) => raw.publish(R.ROOT + code, text, retain !== false);
  put('abcde', wire()); put('ABCDEF', wire()); put('JUNKA', 'not json'); put('JUNKB', '{"v":2}'); put('JUNKC', wire(null, { p: [] })); raw.publish('other/topic', wire(), true);
  await sleep(300);
  ok(latest.length === 1 && latest[0].code === 'KQXZR', 'bad codes, bad JSON, wrong version, no players and foreign topics are ignored');
  put('STALE', wire(null, { q: 5, p: [['New', 1, 0, 1]] })); await until(() => latest.some(x => x.code === 'STALE'));
  put('STALE', wire(null, { q: 3, p: [['Old', 1, 0, 1]] })); await sleep(250);
  ok(latest.find(x => x.code === 'STALE').players[0].name === 'New', 'an older copy that arrives late (lower seq) does not overwrite a newer one');
  put('STALE', '', true); await until(() => !latest.some(x => x.code === 'STALE'));
  put('STALE', wire(null, { q: 5, p: [['Dup', 1, 0, 1]] })); await sleep(250);
  ok(!latest.some(x => x.code === 'STALE'), 'a late duplicate of what was just cleared cannot bring a party back');
  put('STALE', wire(null, { q: 6, p: [['Newer', 1, 0, 1]] }));
  ok(await until(() => latest.some(x => x.code === 'STALE' && x.players[0].name === 'Newer')), 'but a newer announcement (what a reconnecting leader sends) is accepted at once');
  put('GHOST', '', true); await sleep(100); put('GHOST', wire(null, { q: 9, p: [['Ghost', 1, 0, 1]] })); await sleep(250);
  ok(!latest.some(x => x.code === 'GHOST'), 'for a party we never saw, anything right after "gone" is ignored (no ghosts)');
  adv(R.TOMB + 500); put('GHOST', wire(null, { q: 10, p: [['Ghost', 1, 0, 1]] }));
  ok(await until(() => latest.some(x => x.code === 'GHOST')), 'and accepted again after the quiet period');
  put('GHOST', '', true); await until(() => !latest.some(x => x.code === 'GHOST'));

  console.log('- listings nobody refreshes expire');
  put('STALE', wire(null, { q: 7, p: [['Fresh', 1, 0, 1]] })); await until(() => w.list().some(x => x.code === 'STALE' && x.players[0].name === 'Fresh'));
  adv(R.TTL - 1000); w.sweep(); ok(latest.length >= 1 && w.list().some(x => x.code === 'STALE'), 'still listed shortly before the timeout');
  adv(2000); w.sweep();
  ok(await until(() => w.list().length === 0 && latest.length === 0), 'dropped once 75 s pass without a heartbeat (' + w.list().length + ' left)');
  const flood = []; for (let i = 0; i < 230; i++) flood.push(String.fromCharCode(65 + (i % 26)) + String.fromCharCode(65 + ((i / 26) | 0) % 26) + 'ABC');
  [...new Set(flood)].forEach(c => put(c, wire())); await sleep(500);
  ok(w.list().length <= 200, 'a flood of announcements is capped (' + w.list().length + ' kept)');

  raw.close(true); pub.close(); w.close(); w2.close();
  await B.close();
}

async function twoBrokers() {
  console.log('- two brokers at once');
  const B1 = await broker.start({}), B2 = await broker.start({}), cfg = [{ url: B1.url }, { url: B2.url }];
  let latest = [], st = null;
  const w = R.watch({ onChange: (l, s) => { latest = l; st = s; } }, { brokers: cfg });
  const pub = R.publish('TWOBR', info(['Ann', 'Ben']), { brokers: cfg });
  adv(1100); pub.tick(); await until(() => pub.up() === 2 && st && st.up === 2);
  ok(await until(() => latest.length === 1), 'a party announced on both brokers is listed once');
  ok(B1.retained.has(R.ROOT + 'TWOBR') && B2.retained.has(R.ROOT + 'TWOBR'), 'and is stored on both');
  const only1 = R.watch({ onChange: () => {} }, { brokers: [cfg[0]] }), only2 = R.watch({ onChange: () => {} }, { brokers: [cfg[1]] });
  ok(await until(() => only1.list().length === 1 && only2.list().length === 1), 'a browser that can only reach one of them still sees it');
  await B1.close();
  ok(await until(() => st.up === 1 && st.state === 'live'), 'with one broker down the browser stays live (' + st.up + '/' + st.total + ')');
  ok(latest.length === 1, 'and keeps showing the party');
  adv(1100); const q = pub.seq; info; pub.tick(); ok(pub.up() === 1, 'the publisher keeps going on the broker that is left');
  const late = R.publish('LATEX', info(['Zoe']), { brokers: cfg });
  adv(1100); late.tick(); await until(() => late.up() === 1);
  ok(await until(() => latest.some(x => x.code === 'LATEX')), 'a party created while one broker is down is announced on the other');
  late.close(); pub.close(); w.close(); only1.close(); only2.close(); await B2.close();

  console.log('- no broker reachable');
  const down = R.watch({ onChange: (l, s) => { st = s; } }, { brokers: [{ url: 'ws://127.0.0.1:1/mqtt' }, { url: 'ws://127.0.0.1:2/mqtt' }] });
  ok(await until(() => st && st.state === 'error' && st.ready, 3000), 'the browser reports an error once every broker has failed');
  const B3 = await broker.start({ port: 0 }); down.close();
  const retry = R.watch({ onChange: (l, s) => { st = s; } }, { brokers: [{ url: B3.url }] });
  ok(await until(() => st && st.state === 'live'), 'and a working broker goes live straight away');
  retry.close(); await B3.close();
}

async function localPath() {
  console.log('- same-computer transport (BroadcastChannel)');
  const cfg = [{ url: 'local' }]; let a = [], b = [];
  const pub = R.publish('LOCAL', info(['Tab', 'Two']), { brokers: cfg });
  adv(1100); pub.tick(); await sleep(50);
  const w1 = R.watch({ onChange: l => { a = l; } }, { brokers: cfg });
  ok(await until(() => a.length === 1 && a[0].code === 'LOCAL'), 'another tab sees a public party');
  const w2 = R.watch({ onChange: l => { b = l; } }, { brokers: cfg });
  ok(await until(() => b.length === 1), 'a tab opened later gets it too (retained replay)');
  adv(1100); pub.close();
  ok(await until(() => a.length === 0 && b.length === 0), 'closing the party clears it everywhere');
  const pub2 = R.publish('CRASH', info(['Cr', 'Ash']), { brokers: cfg }); adv(1100); pub2.tick(); await sleep(50);
  ok(await until(() => a.length === 1), 'a second party is announced');
  pub2.conns[0].d.abort();
  ok(await until(() => a.length === 0), 'a tab that dies unexpectedly is cleared by its last-will stand-in');
  pub2.close(); w1.close(); w2.close();
}

(async () => {
  helpers();
  await mqttPath();
  await twoBrokers();
  await localPath();
  console.log(bad ? '\n' + bad + ' of ' + n + ' CHECKS FAILED' : '\nREGISTRY: all ' + n + ' checks passed');
  process.exit(bad ? 1 : 0);
})();
