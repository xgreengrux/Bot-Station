/* Drives the authoritative host with scripted fake clients. Run: node test/sim.test.js */
require('../js/shared.js'); require('../js/host.js'); require('../js/host_game.js'); require('../js/host_meet.js');
const BS = globalThis.BS, C = BS.C, Host = BS.Host;
let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('  FAIL:', m); } };
const section = s => console.log('-', s);
const clone = o => JSON.parse(JSON.stringify(o));

function connect(host, name, extra) {
  const c = { in: [], name, closedByHost: false };
  c.link = { send(m) { if (m.k === 'welcome') c._id = m.id; c.in.push(clone(m)); }, close() { c.closedByHost = true; } };
  host.addLink(c.link);
  c.say = m => c.link.onMessage(clone(m));
  c.drop = () => c.link.onClose();
  c.join = (x) => c.say(Object.assign({ k: 'join', name, token: 'tok-' + name, color: 0, hat: 0 }, extra, x));
  c.last = k => [...c.in].reverse().find(m => m.k === k);
  c.all = k => c.in.filter(m => m.k === k);
  c.clear = () => { c.in.length = 0; };
  c.id = () => c._id;
  return c;
}
const step = (h, s) => { for (let i = 0; i < Math.round(s * 30); i++) h.tick(1 / 30); };
const P = (h, c) => h.players.get(c.id());

function newGame(count, opts) {
  const h = new Host(Object.assign({ code: 'ABCDE', minPlayers: 4, idleTimeout: 0 }, opts));
  const cs = [];
  for (let i = 0; i < count; i++) { const c = connect(h, 'P' + (i + 1)); c.join(); cs.push(c); }
  cs[0].say({ k: 'start' }); step(h, 5.2);
  step(h, 5.2);                                       // intro
  const imp = cs.find(c => P(h, c).role === 'imp');
  return { h, cs, imp, crew: cs.filter(c => c !== imp) };
}
const put = (p, x, y) => { p.x = x; p.y = y; };
const nearStation = (p, id) => put(p, BS.ST[id].x, BS.ST[id].y + 10);

/* ------------------------------------------------------------------ lobby */
section('party / lobby');
{
  const h = new Host({ code: 'ABCDE' });
  const cs = [];
  for (let i = 0; i < 5; i++) { const c = connect(h, 'P' + (i + 1)); c.join(); cs.push(c); }
  ok(cs.map(c => c.id()).join() === '1,2,3,4,5', 'ids assigned 1..5');
  ok(h.leader === 1, 'first player is leader');
  const colors = new Set([...h.players.values()].map(p => p.color));
  ok(colors.size === 5, 'colours are unique even when all request the same one');
  cs[1].say({ k: 'settings', key: 'killCd', value: 55 });
  ok(h.settings.killCd === 30, 'non-leader cannot change settings');
  cs[0].say({ k: 'settings', key: 'killCd', value: 999 });
  ok(h.settings.killCd === 60, 'settings are clamped');
  cs[0].say({ k: 'settings', key: 'nope', value: 1 });
  ok(!('nope' in h.settings), 'unknown setting ignored');
  cs[1].say({ k: 'start' }); ok(h.phase === 'lobby', 'non-leader cannot start');
  cs[0].say({ k: 'start' }); ok(h.phase === 'countdown', 'leader starts countdown');
  step(h, 2);
  const c6 = connect(h, 'P6'); c6.join();
  ok(h.countdown === C.START_CD, 'a join resets the countdown');
  cs[0].say({ k: 'kick', id: c6.id() });
  ok(!h.players.has(c6.id()) && c6.last('kicked'), 'leader can kick');
  cs[4].drop(); ok(h.players.size === 4 && h.phase === 'countdown', 'leave in lobby removes player');
  cs[3].drop(); ok(h.phase === 'lobby', 'below minimum cancels the countdown');
  const late = connect(h, 'L'); late.join(); cs[0].say({ k: 'start' });
  const rej = (x => x)(0);
  cs[0].say({ k: 'chat', text: 'hello <b>' }); step(h, 1);
  ok(cs[1].last('chat') && cs[1].last('chat').text === 'hello b', 'chat is sanitised and broadcast');
  const h2 = new Host({ code: 'ZZZZZ' }); let closed = ''; h2.onClosed = w => { closed = w; };
  const a = connect(h2, 'A'); a.join(); const b = connect(h2, 'B'); b.join();
  a.drop(); ok(closed && b.last('closed'), 'leader leaving closes the party');
}

/* ------------------------------------------------------------- game start */
section('game start');
let G1 = newGame(5);
{
  const { h, cs, imp } = G1;
  ok(h.phase === 'play', 'play begins after the intro (phase=' + h.phase + ')');
  ok(cs.filter(c => P(h, c).role === 'imp').length === 1, 'exactly one saboteur with 5 players');
  const b = imp.last('begin');
  ok(b && b.role === 'imp' && b.tasks.length === 4 && b.tasks.every(t => t.fake), 'saboteur gets 4 fake tasks');
  const cb = G1.crew[0].last('begin');
  ok(cb.tasks.length === 4 && !cb.tasks.some(t => t.fake) && cb.mates.length === 0, 'technician gets 4 real tasks, no mates');
  ok(new Set(G1.crew.map(c => c.last('begin').tasks[0].id)).size === 1, 'everyone shares the same common task');
  ok(cs.every(c => c.last('go')), 'go message sent');
  const late = connect(h, 'Late'); late.join();
  ok(late.last('reject'), 'cannot join a game in progress');
  const snaps = G1.crew[0].all('s').length;
  step(h, 1); ok(G1.crew[0].all('s').length - snaps >= 13, 'snapshots flow at ~15 Hz');
  ok(G1.crew[0].last('s').pl.length === 4, 'all four others visible in the starting ring');
}

/* --------------------------------------------------------------- movement */
section('movement validation');
{
  const { h, crew } = G1, c = crew[0], p = P(h, c);
  put(p, 870, 860); step(h, 0.1); c.clear();
  c.say({ k: 'pos', x: 875, y: 860, f: 0, m: 1 });
  ok(p.x === 875 && !c.last('fix'), 'small legal move accepted');
  step(h, 0.1);
  c.say({ k: 'pos', x: 1500, y: 860, f: 0, m: 1 });
  ok(p.x === 875 && c.last('fix'), 'teleport rejected with a correction');
  step(h, 0.1);
  c.say({ k: 'pos', x: 880, y: 500, f: 0, m: 1 });         // inside no room
  ok(c.last('fix') && p.y === 860, 'walking into a wall is rejected');
}

/* ------------------------------------------------------------- visibility */
section('visibility');
{
  const { h, crew } = G1, [a, b] = crew, pa = P(h, a), pb = P(h, b);
  put(pa, 150, 300); put(pb, 1500, 1300); step(h, 0.2);
  ok(!a.last('s').pl.some(r => r[0] === pb.id), 'far player is not sent (no wall-hacking)');
  put(pb, 150, 400); step(h, 0.2);
  ok(a.last('s').pl.some(r => r[0] === pb.id), 'near player with line of sight is sent');
  put(pb, 560, 240); put(pa, 160, 240); step(h, 0.2);       // same row, but across the hallway: still LOS
  put(pb, 880, 330); put(pa, 880, 450); step(h, 0.2);       // hallway gap below Greenhouse
  put(pa, 700, 300); put(pb, 150, 300); step(h, 0.2);       // different rooms, wall between
  ok(!a.last('s').pl.some(r => r[0] === pb.id), 'walls block sight');
}

/* ------------------------------------------------------------------ tasks */
section('tasks');
{
  const { h, crew } = newGame(5), c = crew[0], p = P(h, c);
  p.tasks = [{ id: 'l_fuel', done: [false, false], fake: false }, { id: 's_filter', done: [false], fake: false }];
  nearStation(p, 'fuel_engine'); c.say({ k: 'open', st: 'fuel_engine' }); step(h, 6); c.say({ k: 'done', task: 'l_fuel', step: 1 });
  ok(!p.tasks[0].done[1], 'ordered task: step 2 before step 1 is rejected');
  nearStation(p, 'filter_green'); c.say({ k: 'open', st: 'filter_green' }); c.say({ k: 'done', task: 's_filter', step: 0 });
  ok(!p.tasks[1].done[0], 'finishing instantly is rejected');
  step(h, 3); c.say({ k: 'done', task: 's_filter', step: 0 });
  ok(p.tasks[1].done[0] && c.last('task'), 'task completes after real time at the right station');
  const before = h.progress();
  nearStation(p, 'fuel_cargo'); c.say({ k: 'open', st: 'fuel_cargo' }); step(h, 6); c.say({ k: 'done', task: 'l_fuel', step: 0 });
  ok(h.progress() > before && c.last('tp'), 'progress updates and broadcasts');
  put(p, 150, 300); c.say({ k: 'done', task: 'l_fuel', step: 1 });
  ok(!p.tasks[0].done[1], 'cannot finish a step away from its station');
}
{
  const { h, crew, imp } = newGame(5);
  const ip = P(h, imp);
  nearStation(ip, 'wire_engine'); imp.say({ k: 'open', st: 'wire_engine' }); step(h, 3); imp.say({ k: 'done', task: ip.tasks[0].id, step: 0 });
  ok(h.progress() === 0, 'saboteur fake tasks never count');
  // finish every real task for a win
  let last;
  for (const c of crew) {
    const p = P(h, c);
    for (const tk of p.tasks) TASK_LOOP: for (let si = 0; si < tk.done.length; si++) {
      const def = BS.TASKS.find(t => t.id === tk.id), st = def.steps[si].st;
      nearStation(p, st); c.say({ k: 'open', st }); step(h, 10); c.say({ k: 'done', task: tk.id, step: si });
    }
  }
  ok(h.phase === 'over' && crew[0].last('over').winner === 'crew' && crew[0].last('over').why === 'tasks', 'all tasks done => technicians win');
  ok(crew[0].last('over').roles[imp.id()] === 'imp', 'roles are revealed at the end');
  crew[1].say({ k: 'again' }); ok(h.phase === 'over', 'only the leader can return to the lobby');
  h.players.get(1) && h.players.get(1).role;
  const lead = crew.concat([imp]).find(c => c.id() === 1);
  lead.say({ k: 'again' }); ok(h.phase === 'lobby' && lead.last('lobby').phase === 'lobby', 'leader returns the party to the lobby');
  lead.say({ k: 'start' }); step(h, 5.2); ok(h.phase === 'intro', 'party can play again');
}

/* --------------------------------------------------- kill / report / vote */
section('eliminate, report, vote');
{
  const { h, cs, crew, imp } = newGame(5), ip = P(h, imp), [a, b, c3] = crew.map(c => P(h, c));
  put(ip, 150, 300); put(a, 190, 300); put(b, 700, 300); put(c3, 1500, 1300);
  ip.killCd = 0; step(h, 0.2); crew.forEach(c => c.clear());
  imp.say({ k: 'kill', t: b.id });
  ok(b.alive, 'cannot eliminate out of range');
  imp.say({ k: 'kill', t: a.id });
  ok(!a.alive && crew[0].last('died'), 'adjacent technician eliminated');
  ok(Math.hypot(ip.x - a.x, ip.y - a.y) < 20, 'saboteur moves onto the body');
  imp.say({ k: 'kill', t: b.id }); put(b, ip.x + 20, ip.y);
  imp.say({ k: 'kill', t: b.id }); ok(b.alive, 'kill cooldown enforced');
  step(h, 0.3);
  ok(imp.last('s').bd.length === 1, 'saboteur sees the body');
  ok(crew[2].last('s').bd.length === 0, 'far player does not see the body');
  ok(crew[0].last('s').pl.length === cs.length - 1, 'ghost sees every living player');
  // report by b (alive, near body)
  put(b, ip.x + 40, ip.y); put(ip, ip.x - 100, ip.y);
  step(h, 0.1); cs.forEach(c => c.clear());
  crew[1].say({ k: 'report' });
  ok(h.phase === 'meeting' && cs.every(c => c.last('meet')), 'report starts a meeting for everyone');
  const m = cs[0].last('meet');
  ok(m.body === a.id && m.caller === b.id && m.st === 'discuss', 'meeting names caller and victim');
  crew[1].say({ k: 'vote', t: ip.id }); ok(!cs[0].last('voted'), 'no voting during discussion');
  crew[1].say({ k: 'chat', text: 'it was them' }); step(h, 0.5);
  crew[0].say({ k: 'chat', text: 'boo' });
  ok(cs.some(c => c.last('chat') && c.last('chat').text === 'it was them'), 'living chat is delivered in meetings');
  ok(!imp.all('chat').some(x => x.text === 'boo'), 'ghost chat is hidden from the living');
  step(h, 15.5);
  ok(h.G.meet.st === 'vote', 'discussion rolls into voting');
  crew[0].say({ k: 'vote', t: ip.id }); ok(h.G.meet.votes[a.id] === undefined, 'ghosts cannot vote');
  crew[1].say({ k: 'vote', t: ip.id }); crew[1].say({ k: 'vote', t: 0 }); ok(h.G.meet.votes[b.id] === ip.id, 'votes are final');
  crew[2].say({ k: 'vote', t: ip.id }); crew[3].say({ k: 'vote', t: ip.id }); imp.say({ k: 'vote', t: b.id });
  step(h, 2.2);
  const r = cs[1].last('meet');
  ok(r.st === 'result' && r.result.ejected === ip.id && r.result.wasImp === true, 'majority ejects the saboteur and reveals the role');
  step(h, 9.2);
  ok(h.phase === 'over' && cs[1].last('over').why === 'votes', 'ejecting the saboteur ends the game');
}
{
  const { h, cs, crew, imp } = newGame(6), ip = P(h, imp);
  const ps = crew.map(c => P(h, c));
  put(ip, 150, 300); put(ps[0], 190, 300); ip.killCd = 0; step(h, 0.2);
  imp.say({ k: 'kill', t: ps[0].id });
  crew[1].say({ k: 'report' });                                   // reporter far away: ignored
  ok(h.phase === 'play', 'cannot report from far away');
  put(ps[1], ip.x + 50, ip.y); crew[1].say({ k: 'report' }); ok(h.phase === 'meeting', 'report within range');
  step(h, 15.5);
  cs.forEach(c => c.say({ k: 'vote', t: 0 }));
  step(h, 2.2); step(h, 9.2);
  ok(h.phase === 'play' && cs.every(c => c.last('resume')), 'skip vote returns to play with a resume');
  ok(h.G.bodies.length === 0 && ip.killCd > h.settings.killCd - 1, 'bodies cleared and kill cooldown reset after meeting');
  const rp = crew[1].last('resume'); ok(Math.hypot(rp.x - 870, rp.y - 740) < 200, 'players are placed back around the table');
  // emergency button
  put(ps[2], BS.ST.button.x, BS.ST.button.y + 20); step(h, 15.5);
  crew[2].say({ k: 'button' }); ok(h.phase === 'meeting' && h.G.meet.body === 0, 'emergency button works near the table');
  step(h, 15.5); cs.forEach(c => c.say({ k: 'vote', t: 0 })); step(h, 11.5);
  put(ps[2], BS.ST.button.x, BS.ST.button.y + 20); step(h, 15.5); crew[2].say({ k: 'button' });
  ok(h.phase === 'play', 'emergency meetings are limited');
}
{ // imps outnumber => saboteur win
  const { h, crew, imp } = newGame(4), ip = P(h, imp), ps = crew.map(c => P(h, c));
  put(ip, 150, 300); ip.killCd = 0; put(ps[0], 190, 300); step(h, 0.1);
  imp.say({ k: 'kill', t: ps[0].id }); ok(h.phase === 'play', 'game continues at 1v2');
  put(ps[1], ip.x + 30, ip.y); ip.killCd = 0; imp.say({ k: 'kill', t: ps[1].id });
  ok(h.phase === 'over' && imp.last('over').winner === 'imp' && imp.last('over').why === 'kills', 'saboteur wins when they match the technicians');
}

/* -------------------------------------------------------------- sabotage */
section('sabotage');
{
  const { h, cs, crew, imp } = newGame(6), ip = P(h, imp), ps = crew.map(c => P(h, c));
  imp.say({ k: 'sab', s: 'lights' }); ok(!h.G.sab, 'sabotage on cooldown at the start');
  h.G.sabCd = 0;
  crew[0].say({ k: 'sab', s: 'lights' }); ok(!h.G.sab, 'technicians cannot sabotage');
  imp.say({ k: 'sab', s: 'lights' }); ok(h.G.sab && h.G.sab.k === 'lights', 'lights sabotage starts');
  h.G.sab = null; put(ps[0], 300, 240); put(ps[1], 560, 240); step(h, 0.2);
  ok(crew[0].last('s').pl.some(r => r[0] === ps[1].id), 'same pair is visible with the lights on');
  h.G.sab = { k: 'lights' }; step(h, 0.2);
  ok(!crew[0].last('s').pl.some(r => r[0] === ps[1].id), 'lights out shrinks technician vision');
  put(ip, 300, 240); step(h, 0.2);
  ok(imp.last('s').pl.some(r => r[0] === ps[1].id), 'saboteur vision is unaffected by lights');
  nearStation(ps[2], 'lights_panel'); crew[2].say({ k: 'open', st: 'lights_panel' });
  crew[2].say({ k: 'done', fix: 'lights' }); ok(h.G.sab, 'lights cannot be fixed instantly');
  step(h, 2); crew[2].say({ k: 'done', fix: 'lights' }); ok(!h.G.sab, 'lights fixed at the breaker');
  imp.say({ k: 'sab', s: 'comms' }); ok(!h.G.sab && h.G.sabCd > 0, 'cooldown after a fix');
  h.G.sabCd = 0; imp.say({ k: 'sab', s: 'comms' }); ok(h.G.sab.k === 'comms', 'comms sabotage starts');
  const p3 = ps[3]; p3.tasks = [{ id: 's_filter', done: [false], fake: false }];
  nearStation(p3, 'filter_green'); crew[3].say({ k: 'open', st: 'filter_green' }); step(h, 3);
  crew[3].say({ k: 'done', task: 's_filter', step: 0 }); ok(!p3.tasks[0].done[0] && crew[3].last('deny'), 'tasks are disabled while comms are down');
  h.G.sab = null; h.G.sabCd = 0;
  // reactor: two holders fix it
  imp.say({ k: 'sab', s: 'reactor' }); ok(h.G.sab.k === 'reactor', 'reactor meltdown starts');
  nearStation(ps[0], 'melt_a'); nearStation(ps[1], 'melt_b');
  crew[0].say({ k: 'hold', st: 'melt_a', on: true }); step(h, 1);
  ok(h.G.sab && h.G.sab.holds.melt_a === ps[0].id, 'one hold is not enough');
  crew[1].say({ k: 'hold', st: 'melt_b', on: true }); step(h, 0.2);
  ok(!h.G.sab, 'two simultaneous holds fix the reactor');
  // emergency button blocked during sabotage
  h.G.sabCd = 0; imp.say({ k: 'sab', s: 'lights' }); put(ps[4], BS.ST.button.x, BS.ST.button.y + 20); h.G.emergCd = 0;
  crew[4].say({ k: 'button' }); ok(h.phase === 'play', 'no emergency meetings during a sabotage');
  h.G.sab = null;
  // reactor runs out
  h.G.sabCd = 0; imp.say({ k: 'sab', s: 'reactor' }); step(h, C.REACTOR_TIME + 1);
  ok(h.phase === 'over' && cs[0].last('over').why === 'sabotage' && cs[0].last('over').winner === 'imp', 'unfixed reactor => saboteur wins');
}
{ // doors
  const { h, crew, imp } = newGame(5), ip = P(h, imp), c = P(h, crew[0]);
  put(c, 1050, 300); put(ip, 700, 300); h.G.sab = null;
  imp.say({ k: 'sab', s: 'doors', room: 1 });
  ok(h.G.locked.size === BS.ROOM_DOORS[1].length, 'doors lock around the chosen room');
  step(h, 0.1); ok(crew[0].last('s').dr.length === h.G.locked.size, 'locked doors are broadcast');
  put(c, 1090, 240); h.G.doorsLeft = 5;                       // standing in a closing doorway
  imp.say({ k: 'sab', s: 'doors', room: 1 }); ok(h.G.doorCd > 0, 'door cooldown running');
  step(h, 5.2); ok(h.G.locked.size === 0, 'doors reopen after a few seconds');
  imp.say({ k: 'sab', s: 'doors', room: 4 }); ok(h.G.locked.size === 0, 'door cooldown blocks immediate reuse');
}

/* ------------------------------------------------------------------ vents */
section('vents');
{
  const { h, crew, imp } = newGame(5), ip = P(h, imp), c = P(h, crew[0]);
  put(c, 190, 150); put(ip, 115 + 30, 115 + 30); step(h, 0.1); crew[0].clear();
  imp.say({ k: 'vent' }); ok(ip.vent === 0 && imp.last('vent'), 'saboteur enters a vent');
  step(h, 0.2);
  ok(!crew[0].last('s').pl.some(r => r[0] === ip.id), 'vented player is invisible');
  ok(crew[0].all('s').some(s => (s.ev || []).some(e => e[0] === 'vent')), 'nearby players see the vent pop');
  imp.say({ k: 'vent', to: 1 }); ok(ip.vent === 1 && Math.abs(ip.x - 300) < 1, 'saboteur travels through linked vents');
  imp.say({ k: 'vent', to: 5 }); ok(ip.vent === 1, 'cannot hop to an unlinked vent');
  imp.say({ k: 'pos', x: 400, y: 700, f: 0, m: 1 }); ok(ip.x === 300, 'cannot walk while in a vent');
  imp.say({ k: 'vent', to: -1 }); ok(ip.vent === -1, 'saboteur exits the vent');
  crew[0].say({ k: 'vent' }); ok(c.vent === -1, 'technicians cannot vent');
}

/* ----------------------------------------------------------- reconnection */
section('disconnects');
{
  const { h, cs, crew, imp } = newGame(6);
  const c = crew[0], p = P(h, c), id = p.id, tasks = JSON.stringify(p.tasks);
  c.drop(); ok(!p.conn && cs[2].last('drop').id === id, 'drop is announced, player kept during grace');
  step(h, 5);
  const c2 = connect(h, 'P-again'); c2.join({ name: c.name, token: 'tok-' + c.name });
  const b = c2.last('begin');
  ok(b && b.rejoin && b.me === id && JSON.stringify(b.tasks.map(t => ({ id: t.id, done: t.done, fake: t.fake }))) === tasks, 'rejoin restores role and tasks');
  ok(P(h, c) && h.players.get(id).conn, 'player is connected again');
  c2.drop(); step(h, C.GRACE + 1);
  ok(h.players.get(id).gone && cs[2].last('gone').id === id, 'player removed after the grace period');
  const c3 = connect(h, 'x'); c3.join({ token: 'tok-' + c.name }); ok(c3.last('reject'), 'removed player cannot rejoin');
  // leaving every saboteur ends the game for technicians
  imp.drop(); step(h, C.GRACE + 1);
  ok(h.phase === 'over' && cs[2].last('over').winner === 'crew', 'saboteur leaving ends the game');
  const late = connect(h, 'q'); late.join({ token: 'tok-' + crew[1].name }); ok(late.last('over'), 'reconnecting after the end replays the result');
}
{ // reconnect during a meeting
  const { h, cs, crew, imp } = newGame(5), ps = crew.map(c => P(h, c));
  put(ps[0], BS.ST.button.x, BS.ST.button.y + 20); step(h, 15.2); crew[0].say({ k: 'button' });
  crew[1].drop(); const r = connect(h, 'm'); r.join({ token: 'tok-' + crew[1].name });
  ok(r.last('begin') && r.last('meet') && r.last('meet').st === 'discuss', 'rejoining mid-meeting restores the meeting');
}

/* ------------------------------------------------------------ idle timeout */
section('idle timeout');
{
  const h = new Host({ code: 'IDLEX', minPlayers: 2, idleTimeout: 5 });
  const a = connect(h, 'A'); a.join(); const b = connect(h, 'B'); b.join();
  for (let i = 0; i < 4; i++) { step(h, 2); a.say({ k: 'ping', t: i }); }
  ok(a.last('pong') && a.last('pong').t === 3, 'ping gets a pong');
  ok(!h.players.has(b.id()) && b.closedByHost, 'a silent remote player is dropped after the idle timeout');
  ok(h.players.has(a.id()), 'the leader is never timed out');
}

/* ----------------------------------------------------------------- errors */
ok(true, 'done'); ok(globalThis.__hostErrors === undefined, 'no host exceptions');
console.log(bad ? '\n' + bad + ' of ' + n + ' checks FAILED' : '\nALL ' + n + ' CHECKS PASSED');
process.exit(bad ? 1 : 0);
