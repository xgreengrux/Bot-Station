/* A small MQTT 3.1.1 broker spoken over WebSocket, for tests only (no dependencies: http + crypto).
   Implements what the registry relies on, following the spec: retained messages (empty payload clears,
   RETAIN=1 only for messages delivered at subscribe time), last-will on abnormal close (discarded on DISCONNECT),
   keep-alive timeout at 1.5x, session take-over on a duplicate client id, SUBACK/PINGRESP.
   start({ split, coalesce, refuse }) -> { url, port, retained, clients, log, dropAll(pred), close() } */
const http = require('http'), crypto = require('crypto');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

const matches = (filter, topic) => {
  const f = filter.split('/'), t = topic.split('/');
  for (let i = 0; i < f.length; i++) {
    if (f[i] === '#') return i === f.length - 1;
    if (i >= t.length) return false;
    if (f[i] !== '+' && f[i] !== t[i]) return false;
  }
  return f.length === t.length;
};
const validFilter = f => { const p = f.split('/'); return f.length > 0 && p.every((s, i) => s === '#' ? i === p.length - 1 : s === '+' || !/[+#]/.test(s)); };
const enc = s => { const b = Buffer.from(s, 'utf8'); const l = Buffer.alloc(2); l.writeUInt16BE(b.length); return Buffer.concat([l, b]); };
const varint = n => { const o = []; do { let d = n % 128; n = Math.floor(n / 128); if (n > 0) d |= 128; o.push(d); } while (n > 0); return Buffer.from(o); };
const pkt = (b0, body) => Buffer.concat([Buffer.from([b0]), varint(body.length), body]);

function start(opts) {
  opts = opts || {};
  const B = { retained: new Map(), clients: new Set(), log: [], connects: 0, refuse: !!opts.refuse };
  const server = http.createServer((q, r) => { r.writeHead(426); r.end('upgrade required'); });

  class Conn {
    constructor(socket) {
      this.socket = socket; this.wsbuf = Buffer.alloc(0); this.mqbuf = Buffer.alloc(0);
      this.id = null; this.will = null; this.subs = []; this.ka = 0; this.lastRx = Date.now(); this.graceful = false; this.dead = false; this.connected = false;
      socket.on('data', d => { try { this.onData(d); } catch (e) { B.log.push('error ' + e.message); this.kill(); } });
      socket.on('close', () => this.kill());
      socket.on('error', () => this.kill());
      this.timer = setInterval(() => { if (this.ka && Date.now() - this.lastRx > this.ka * 1500) { B.log.push('keepalive timeout ' + this.id); this.kill(); } }, 100);
    }
    /* ---- websocket framing (client frames are masked, server frames are not) ---- */
    frame(op, data) {
      let h;
      if (data.length < 126) h = Buffer.from([0x80 | op, data.length]);
      else if (data.length < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(data.length, 2); }
      else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(data.length), 2); }
      if (!this.dead) this.socket.write(Buffer.concat([h, data]));
    }
    send(buf) {                                   // optionally cut a packet over two WebSocket frames
      if (opts.split && buf.length > 3) { const k = Math.floor(buf.length / 2); this.frame(2, buf.subarray(0, k)); this.frame(2, buf.subarray(k)); } else this.frame(2, buf);
    }
    onData(chunk) {
      this.wsbuf = Buffer.concat([this.wsbuf, chunk]);
      for (;;) {
        const b = this.wsbuf;
        if (b.length < 2) return;
        const op = b[0] & 15, masked = b[1] & 0x80; let len = b[1] & 127, p = 2;
        if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); p = 4; }
        else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); p = 10; }
        if (!masked) return this.kill();
        if (b.length < p + 4 + len) return;
        const mask = b.subarray(p, p + 4), data = Buffer.alloc(len);
        for (let i = 0; i < len; i++) data[i] = b[p + 4 + i] ^ mask[i & 3];
        this.wsbuf = b.subarray(p + 4 + len);
        if (op === 8) return this.kill();
        if (op === 9) { this.frame(10, data); continue; }
        if (op === 2 || op === 0) this.mq(data);
      }
    }
    /* ---- mqtt ---- */
    mq(data) {
      this.lastRx = Date.now();
      this.mqbuf = Buffer.concat([this.mqbuf, data]);
      for (;;) {
        const b = this.mqbuf;
        if (b.length < 2) return;
        let mult = 1, len = 0, i = 1, d, n = 0;
        do { if (i >= b.length) return; d = b[i++]; len += (d & 127) * mult; mult *= 128; if (++n > 4) return this.kill(); } while (d & 128);
        if (b.length < i + len) return;
        const b0 = b[0], body = b.subarray(i, i + len);
        this.mqbuf = b.subarray(i + len);
        this.packet(b0, body);
        if (this.dead) return;
      }
    }
    packet(b0, body) {
      const type = b0 >> 4;
      if (!this.connected && type !== 1) return this.kill();          // first packet must be CONNECT
      if (type === 1) return this.onConnect(body);
      if (type === 3) return this.onPublish(b0, body);
      if (type === 8) return this.onSubscribe(b0, body);
      if (type === 12) return this.send(Buffer.from([0xd0, 0]));
      if (type === 14) { this.graceful = true; B.log.push('disconnect ' + this.id); return this.kill(); }
      B.log.push('ignored packet type ' + type);
    }
    onConnect(b) {
      let p = 0; const str = () => { const l = b.readUInt16BE(p); const s = b.toString('utf8', p + 2, p + 2 + l); p += 2 + l; return s; };
      const proto = str(), level = b[p++], flags = b[p++], ka = b.readUInt16BE(p); p += 2;
      if (proto !== 'MQTT' || level !== 4) { this.send(Buffer.from([0x20, 2, 0, 1])); return this.kill(); }
      if (flags & 1) return this.kill();                               // reserved bit must be 0
      const clean = !!(flags & 2), willFlag = !!(flags & 4), wq = (flags >> 3) & 3, wr = !!(flags & 0x20), hasUser = !!(flags & 0x80), hasPass = !!(flags & 0x40);
      if ((!willFlag && (wq || wr)) || wq === 3 || (hasPass && !hasUser)) return this.kill();
      let id = str();
      if (!id && !clean) { this.send(Buffer.from([0x20, 2, 0, 2])); return this.kill(); }
      if (!id) id = 'auto-' + crypto.randomBytes(4).toString('hex');
      if (willFlag) { const topic = str(); const l = b.readUInt16BE(p); const payload = b.toString('utf8', p + 2, p + 2 + l); p += 2 + l; this.will = { topic, payload, retain: wr }; }
      const user = hasUser ? str() : null, pass = hasPass ? str() : null;
      if (opts.auth && (user !== opts.auth.user || pass !== opts.auth.pass)) { this.send(Buffer.from([0x20, 2, 0, 4])); return this.kill(); }
      for (const c of B.clients) if (c !== this && c.id === id) { B.log.push('takeover ' + id); c.kill(); }   // [MQTT-3.1.4-2]
      this.id = id; this.ka = ka; this.connected = true; B.clients.add(this); B.connects++;
      B.log.push('connect ' + id + (this.will ? ' will=' + this.will.topic : ''));
      this.send(Buffer.from([0x20, 2, 0, 0]));
    }
    onPublish(b0, body) {
      const qos = (b0 >> 1) & 3, retain = !!(b0 & 1), tl = body.readUInt16BE(0), topic = body.toString('utf8', 2, 2 + tl);
      let p = 2 + tl;
      if (qos > 0) { const id = body.readUInt16BE(p); p += 2; if (qos === 1) this.send(Buffer.from([0x40, 2, id >> 8, id & 255])); }
      B.publish(topic, body.subarray(p), retain, this);
    }
    onSubscribe(b0, body) {
      if ((b0 & 15) !== 2) return this.kill();                        // [MQTT-3.8.1-1]
      const id = body.readUInt16BE(0); let p = 2; const codes = [], out = [];
      while (p < body.length) {
        const l = body.readUInt16BE(p), filter = body.toString('utf8', p + 2, p + 2 + l); p += 2 + l + 1;
        if (!validFilter(filter)) { codes.push(0x80); continue; }
        codes.push(0); this.subs.push(filter);
        for (const [topic, payload] of B.retained) if (matches(filter, topic)) out.push(pkt(0x31, Buffer.concat([enc(topic), payload])));   // RETAIN=1 at subscribe time
      }
      const ack = pkt(0x90, Buffer.from([id >> 8, id & 255, ...codes]));
      if (opts.coalesce) this.send(Buffer.concat([ack, ...out])); else { this.send(ack); out.forEach(o => this.send(o)); }
    }
    deliver(topic, payload) { if (this.connected && this.subs.some(f => matches(f, topic))) this.send(pkt(0x30, Buffer.concat([enc(topic), payload]))); }   // RETAIN=0 when forwarded
    kill() {
      if (this.dead) return;
      this.dead = true; clearInterval(this.timer); B.clients.delete(this);
      try { this.socket.destroy(); } catch (e) { /* ignore */ }
      if (this.will && !this.graceful && this.connected) { const w = this.will; this.will = null; B.log.push('will ' + w.topic); B.publish(w.topic, Buffer.from(w.payload, 'utf8'), w.retain, this); }
    }
  }

  B.publish = (topic, payload, retain, from) => {
    B.log.push('pub ' + topic + (retain ? ' R' : '') + ' ' + payload.length + 'b');
    if (retain) { if (payload.length === 0) B.retained.delete(topic); else B.retained.set(topic, Buffer.from(payload)); }
    for (const c of [...B.clients]) c.deliver(topic, payload);          // 3.1.1 has no no-local: the sender gets its own message too if subscribed
  };
  B.dropAll = pred => { for (const c of [...B.clients]) if (!pred || pred(c)) c.socket.destroy(); };   // network failure: no DISCONNECT, wills fire
  B.retainedText = () => Object.fromEntries([...B.retained].map(([k, v]) => [k, v.toString('utf8')]));

  server.on('upgrade', (req, socket) => {
    const key = req.headers['sec-websocket-key'], protos = String(req.headers['sec-websocket-protocol'] || '').split(',').map(s => s.trim());
    if (B.refuse || !key || !protos.includes('mqtt')) { socket.destroy(); return; }
    const acc = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\nSec-WebSocket-Protocol: mqtt\r\n\r\n');
    new Conn(socket);
  });
  B.close = () => new Promise(r => { B.dropAll(); server.close(() => r()); server.closeAllConnections && server.closeAllConnections(); });
  return new Promise(r => server.listen(opts.port || 0, '127.0.0.1', () => { B.port = server.address().port; B.url = 'ws://127.0.0.1:' + B.port + '/mqtt'; r(B); }));
}
module.exports = { start, matches };
