/* Second end-to-end scenario: vents, doors, admin table, map, emergency button, ghosts, mid-game refresh.
   Run: node test/e2e2.js */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const OUT = process.env.SHOTS || '/tmp/claude-0/-home-claude/657a804d-6327-5469-81d5-b8ece5fafb4b/scratchpad/shots';
fs.mkdirSync(OUT, { recursive: true });
let bad = 0;
const ok = (c, m) => { if (!c) bad++; console.log(c ? '  ok  :' : '  FAIL:', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const server = http.createServer((req, res) => { fs.readFile(path.join(root, 'index.html'), (e, d) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end(d); }); });

(async () => {
  await new Promise(r => server.listen(0, r));
  const url = 'http://localhost:' + server.address().port + '/?local';
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 1100, height: 700 } });
  await ctx.route(/peerjs/, r => r.abort());
  const names = ['Alice', 'Bob', 'Cleo', 'Dan'], errors = [], pages = [];
  for (let i = 0; i < 4; i++) { const p = await ctx.newPage(); p.on('pageerror', e => errors.push(names[i] + ': ' + e.message)); await p.goto(url); pages.push(p); }
  const A = pages[0];
  const S = (p, e) => p.evaluate(`(() => { const S = window.__BS.S; return ${e}; })()`);
  const hostEval = e => A.evaluate(`(() => { const h = window.__BS.S.host; return ${e}; })()`);
  const shot = (i, n) => pages[i].screenshot({ path: path.join(OUT, n + '.png') });
  const place = async (i, x, y) => { const id = await S(pages[i], 'S.id'); await hostEval(`(() => { const p = h.players.get(${id}); p.x = ${x}; p.y = ${y}; p.ignoreUntil = 0; })()`); await pages[i].evaluate(`(() => { const S = window.__BS.S; S.x = ${x}; S.y = ${y}; })()`); };
  const waitSel = (p, sel, t) => p.waitForSelector(sel, { timeout: t || 12000, state: /\.hidden/.test(sel) && !/not\(\.hidden\)/.test(sel) ? 'attached' : 'visible' });
  try {
    await A.fill('#tName', 'Alice'); await A.click('#tCreate'); await waitSel(A, '#lobby:not(.hidden)');
    await A.waitForFunction(() => /^[A-Z]{5}$/.test(document.getElementById('lbCode').textContent));
    const code = (await A.textContent('#lbCode')).trim();
    for (let i = 1; i < 4; i++) { await pages[i].fill('#tName', names[i]); await pages[i].fill('#tCode', code); await pages[i].click('#tJoin'); await waitSel(pages[i], '#lobby:not(.hidden)'); }
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 4);
    await hostEval('(h.settings.discuss = 0, h.settings.voteTime = 15, 1)');
    await A.click('#lbStart');
    for (const p of pages) { await waitSel(p, '#intro:not(.hidden)', 15000); }
    for (const p of pages) await waitSel(p, '#intro.hidden', 12000);
    const roles = []; for (const p of pages) roles.push(await S(p, 'S.role'));
    const iI = roles.indexOf('imp'), [c1, c2, c3] = [0, 1, 2, 3].filter(i => i !== iI);
    console.log('game running; saboteur is', names[iI]);

    console.log('- vents');
    await place(iI, 140, 100); await place(c1, 230, 110); await sleep(300);
    await pages[iI].waitForFunction(() => !document.getElementById('bVent').disabled);
    await pages[iI].keyboard.press('v');
    await pages[iI].waitForFunction(() => window.__BS.S.vent === 0);
    await waitSel(pages[iI], '#ventbar:not(.hidden) .btn');
    await shot(iI, '20-in-vent');
    ok((await pages[iI].textContent('#ventbar')).includes('Sickbay'), 'vent bar offers the linked vent room');
    await sleep(400);
    ok(!(await S(pages[c1], `S.others.has(${await S(pages[iI], 'S.id')})`)), 'a vented saboteur is invisible to others');
    await pages[iI].click('#ventbar .btn:has-text("Sickbay")');
    await pages[iI].waitForFunction(() => window.__BS.S.vent === 1 && Math.abs(window.__BS.S.x - 300) < 3);
    ok(true, 'travelled to the linked vent in Sickbay');
    await pages[iI].click('#ventbar .btn:has-text("Exit")');
    await pages[iI].waitForFunction(() => window.__BS.S.vent === -1);
    ok(true, 'exited the vent');
    ok(!(await S(pages[c1], 'S.alive === false')), 'technician near the first vent saw nothing fatal');

    console.log('- locked doors');
    await place(c2, 700, 740); await place(iI, 870, 640); await sleep(300);
    await pages[iI].keyboard.press('x'); await waitSel(pages[iI], '#mapov:not(.hidden) .sabbtn.door');
    await (await pages[iI].$$('.sabbtn.door'))[4].click();
    await pages[c2].waitForFunction(() => window.__BS.S.doors.size === 4, null, { timeout: 5000 });
    ok(true, 'locking the Hub closes its four doors for everyone');
    await pages[c2].keyboard.down('a'); await sleep(1500); await pages[c2].keyboard.up('a');
    const xBlocked = await S(pages[c2], 'S.x');
    ok(xBlocked > 645, 'walking into a locked door is blocked (x=' + Math.round(xBlocked) + ')');
    await shot(c2, '21-locked-door');
    await pages[c2].waitForFunction(() => window.__BS.S.doors.size === 0, null, { timeout: 14000 });
    await pages[c2].keyboard.down('a'); await sleep(1100); await pages[c2].keyboard.up('a');
    ok((await S(pages[c2], 'S.x')) < 630, 'doors reopen and the player can leave the Hub');

    console.log('- admin table and map');
    await place(c3, 700, 625); await sleep(300);
    await pages[c3].waitForFunction(() => document.getElementById('bUse').textContent === 'ADMIN');
    await pages[c3].keyboard.press('e');
    await waitSel(pages[c3], '#mapov:not(.hidden)');
    await pages[c3].waitForFunction(() => window.__BS.S.admin && window.__BS.S.admin.rooms, null, { timeout: 5000 });
    const sum = await S(pages[c3], 'S.admin.rooms.reduce((a, b) => a + b, 0)');
    ok(sum >= 3, 'admin table counts players per room (' + sum + ' counted)');
    await sleep(300); await shot(c3, '22-admin');
    await pages[c3].keyboard.press('Escape'); await waitSel(pages[c3], '#mapov.hidden');
    await pages[c3].keyboard.press('m'); await waitSel(pages[c3], '#mapov:not(.hidden)');
    ok((await pages[c3].textContent('#mapov .phead')).includes('Station map'), 'the M key opens the station map');
    await shot(c3, '23-map'); await pages[c3].keyboard.press('m'); await waitSel(pages[c3], '#mapov.hidden');
    ok(true, 'M toggles the map closed again');

    console.log('- emergency button');
    await hostEval('(h.G.emergCd = 0, 1)'); await place(c1, 870, 830); await sleep(300);
    await pages[c1].waitForFunction(() => document.getElementById('bUse').textContent === 'EMERGENCY' && !document.getElementById('bUse').disabled);
    await pages[c1].keyboard.press('e');
    for (const p of pages) await waitSel(p, '#meeting:not(.hidden) .mcard');
    ok((await pages[c2].textContent('#meeting h2')).includes('Emergency'), 'pressing the button calls an emergency meeting');
    for (const i of [0, 1, 2, 3]) { await pages[i].click('#meeting .meet-foot .btn:has-text("Skip")'); await pages[i].click('#meeting .confirm .primary'); }
    for (const p of pages) await p.waitForFunction(() => window.__BS.S.phase === 'play', null, { timeout: 20000 });
    ok((await S(pages[c1], "S.phase")) === 'play', 'nobody ejected on skip; play resumes');
    await place(c1, 870, 830); await pages[c1].keyboard.press('e'); await sleep(500);
    ok((await S(pages[c1], "S.phase")) === 'play', 'the one-use emergency button is spent');

    console.log('- ghosts');
    await hostEval(`(h.players.get(${await S(pages[iI], 'S.id')}).killCd = 0, 1)`); await pages[iI].evaluate('window.__BS.S.kcd = 0');
    await place(iI, 300, 700); await place(c3, 340, 700); await place(c1, 1500, 1300); await place(c2, 1500, 1350); await sleep(400);
    await pages[iI].keyboard.press('q');
    await pages[c3].waitForFunction(() => window.__BS.S.alive === false);
    await waitSel(pages[c3], '#ghostchat:not(.hidden)');
    await pages[c3].fill('#ghostchat input', 'boo'); await pages[c3].press('#ghostchat input', 'Enter');
    await pages[c3].waitForFunction(() => document.querySelector('#ghostchat .chatlog').textContent.includes('boo'));
    ok(true, 'a ghost can chat with ghosts');
    ok(await pages[c1].evaluate(() => document.getElementById('ghostchat').classList.contains('hidden')), 'living players do not get the ghost chat');
    ok(!(await pages[c1].evaluate(() => document.getElementById('ghostchat').textContent.includes('boo'))), 'and never see ghost messages');
    // the ghost finishes a task
    const g3 = await S(pages[c3], 'S.id');
    await hostEval(`(h.players.get(${g3}).tasks = [{ id: 's_filter', done: [false], fake: false }], 1)`);
    await pages[c3].evaluate(`(() => { const S = window.__BS.S; S.tasks = [{ id: 's_filter', done: [false], fake: false }]; BS.UI.tasks(S); })()`);
    const before = await hostEval('h.progress()');
    await place(c3, 1050, 140); await sleep(300);
    await pages[c3].keyboard.press('e'); await waitSel(pages[c3], '#panel:not(.hidden) .leaf');
    await sleep(1300); for (const l of await pages[c3].$$('.leaf')) await l.dispatchEvent('pointerdown');
    await waitSel(pages[c3], '#panel.hidden'); await sleep(300);
    ok((await hostEval('h.progress()')) > before, 'ghosts can still finish tasks and they count');
    await shot(c3, '24-ghost');

    console.log('- refresh mid-game');
    const idBefore = await S(pages[c2], 'S.id'), tasksBefore = await S(pages[c2], 'JSON.stringify(S.tasks)');
    await pages[c2].reload();
    await pages[c2].waitForFunction(() => window.__BS && window.__BS.S.inGame && window.__BS.S.phase === 'play', null, { timeout: 12000 });
    ok((await S(pages[c2], 'S.id')) === idBefore && (await S(pages[c2], 'S.role')) === 'crew', 'refreshing puts the player straight back into the game');
    ok((await S(pages[c2], 'JSON.stringify(S.tasks)')) === tasksBefore, 'with their tasks and progress intact');
    ok(await hostEval('h.errors === 0'), 'host raised no exceptions');
    ok(errors.length === 0, 'no page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  } catch (e) { bad++; console.log('  EXCEPTION:', e.message.split('\n')[0]); for (let i = 0; i < 4; i++) await shot(i, 'fail2-' + i).catch(() => {}); if (errors.length) console.log('  page errors:', errors.join(' | ')); }
  await browser.close(); server.close();
  console.log(bad ? '\n' + bad + ' PROBLEM(S)' : '\nE2E-2 PASSED');
  process.exit(bad ? 1 : 0);
})();
