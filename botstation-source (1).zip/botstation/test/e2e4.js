/* The party browser over the real network code path: browsers talk MQTT-over-WebSocket to the mock broker
   (test/mockbroker.js) and PeerJS is replaced by a stand-in (test/fakepeer.js), exactly like test/peer.e2e.js.
   Covers publishing, last-will cleanup, reconnecting after a network drop, private parties and an unreachable broker.
   Run: node test/e2e4.js */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), fake = require('./fakepeer.js'), mock = require('./mockbroker.js');
const ROOT = 'botstation/v1/parties/';
let bad = 0;
const ok = (c, m) => { if (!c) bad++; console.log(c ? '  ok  :' : '  FAIL:', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (f, ms) => { const t = Date.now(); while (Date.now() - t < (ms || 8000)) { if (await f()) return true; await sleep(40); } return !!(await f()); };
const server = http.createServer((req, res) => { fs.readFile(path.join(root, 'index.html'), (e, d) => { res.writeHead(200, { 'content-type': 'text/html' }); res.end(d); }); });

(async () => {
  await new Promise(r => server.listen(0, r));
  const B = await mock.start({ coalesce: true });
  const base = 'http://localhost:' + server.address().port + '/', url = base + '?broker=' + encodeURIComponent(B.url);
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 1100, height: 760 } });
  await ctx.route(/peerjs/, r => r.abort()); await ctx.addInitScript(fake);
  const errors = [], mk = async (name, u) => { const p = await ctx.newPage(); p.on('pageerror', e => errors.push(name + ': ' + e.message)); await p.goto(u || url); return p; };
  const waitSel = (p, sel, t) => p.waitForSelector(sel, { timeout: t || 8000, state: 'visible' });
  const cards = p => p.evaluate(() => [...document.querySelectorAll('#bwList .bparty')].map(c => c.dataset.code));
  const retained = code => { const v = B.retained.get(ROOT + code); return v ? JSON.parse(v.toString('utf8')) : null; };
  const create = async (p, name, priv) => { await p.fill('#tName', name); if (priv) await p.check('#tPrivate'); else await p.uncheck('#tPrivate'); await p.click('#tCreate'); await waitSel(p, '#lobby'); await p.waitForFunction(() => /^[A-Z]{5}$/.test(document.getElementById('lbCode').textContent)); return (await p.textContent('#lbCode')).trim(); };
  const openBrowser = async p => { await p.click('#tBrowse'); await waitSel(p, '#browser'); };
  try {
    console.log('- a public party is announced on the broker');
    const A = await mk('A'), code = await create(A, 'Alice');
    ok(await until(() => retained(code)), 'the leader publishes a retained announcement for ' + code);
    const info = retained(code);
    ok(info.v === 1 && info.ph === 'lobby' && info.ld === 'Alice' && info.p.length === 1 && info.p[0][0] === 'Alice' && info.max === 10, 'with the leader, phase and players (' + JSON.stringify(info).slice(0, 90) + '…)');
    const will = [...B.clients].find(c => c.will && c.will.topic === ROOT + code);
    ok(will && will.will.retain && will.will.payload === '', 'and registers a retained, empty last-will on the same topic');

    console.log('- another browser finds it through the broker');
    const V = await mk('V'); await openBrowser(V);
    ok(await until(async () => (await cards(V)).join() === code), 'the party shows up in Browse parties');
    ok((await V.textContent('#bwLive')).includes('Live'), 'and the screen reports it is live');
    await V.fill('#bwQuery', 'ali'); await V.waitForFunction(() => document.querySelectorAll('#bwList .chip.hit').length === 1);
    ok(true, 'searching for a player works on broker data');
    await V.fill('#bwQuery', 'bob'); await V.waitForFunction(() => document.querySelectorAll('#bwList .bparty').length === 0);
    await V.fill('#bwQuery', '');
    await V.fill('#bwName', 'Vic'); await V.click('#bwList .bparty .btn');
    await waitSel(V, '#lobby');
    await A.waitForFunction(() => document.querySelectorAll('#lbPlayers .pcard:not(.empty)').length === 2);
    ok(true, 'Vic joins from the list (over the peer connection)');
    ok(await until(() => { const i = retained(code); return i && i.p.length === 2 && i.p[1][0] === 'Vic'; }), 'and the announcement is updated with the new player');

    console.log('- private parties never touch the broker');
    const before = B.connects, P = await mk('P'), pcode = await create(P, 'Priv', true);
    await sleep(2600);
    ok(!retained(pcode) && B.connects === before, 'a party created as private opens no broker connection (' + (B.connects - before) + ' new)');
    await P.click('#lbVis');
    ok(await until(() => retained(pcode)), 'switching it to public announces it');
    await P.click('#lbVis');
    ok(await until(() => !retained(pcode)), 'switching back clears the announcement');
    ok(await until(() => ![...B.clients].some(c => c.will && c.will.topic === ROOT + pcode)), 'and hangs up (no connection with its will remains)');
    ok(!B.log.some(l => l === 'will ' + ROOT + pcode), 'cleanly: the last-will was not needed');
    await P.click('.lb-actions .btn.danger');

    console.log('- a network drop: last-will, then recovery');
    const W = await mk('W'); await openBrowser(W);
    ok(await until(async () => (await cards(W)).join() === code), 'a third browser watches the party');
    let gone = false; const watch = (async () => { for (let i = 0; i < 160; i++) { if (!(await cards(W)).includes(code)) gone = true; await sleep(40); } })();
    B.dropAll(c => c.will && c.will.topic === ROOT + code);
    ok(await until(() => B.log.includes('will ' + ROOT + code)), 'the broker publishes the last-will when the leader\'s connection drops');
    ok(await until(() => retained(code), 9000), 'the leader reconnects by itself and announces the party again');
    await watch;
    ok(gone, 'a watching browser saw it vanish in between, then come back');
    ok(await until(async () => (await cards(W)).includes(code), 4000), 'it is listed again');

    console.log('- a leader who disappears');
    const X = await mk('X'), xcode = await create(X, 'Xena');
    const live = await until(async () => (await cards(W)).includes(xcode));
    if (!live) console.log('  debug: xcode', xcode, 'retained?', !!retained(xcode), 'W cards', JSON.stringify(await cards(W)), 'W live', await W.textContent('#bwLive'), '\n  debug log:', B.log.filter(l => !/^pub .* R$/.test(l) || true).slice(-14).join(' ; '));
    ok(live, 'a new party shows up live');
    await X.close();
    ok(await until(async () => !(await cards(W)).includes(xcode), 9000), 'closing the leader\'s tab removes it from the list');
    ok(await until(() => !retained(xcode)), 'and from the broker');

    console.log('- the list server is unreachable');
    const Z = await mk('Z', base + '?broker=' + encodeURIComponent('ws://127.0.0.1:1/mqtt'));
    await openBrowser(Z);
    await Z.waitForFunction(() => /reach the party list/.test(document.querySelector('#bwList .bw-empty') ? document.querySelector('#bwList .bw-empty').textContent : ''), null, { timeout: 12000 });
    ok(/Offline/.test(await Z.textContent('#bwLive')) && (await Z.$$('#bwList .bw-empty .btn')).length === 1, 'the browser says it is offline and offers "Try again"');
    await Z.click('#bwBack'); await waitSel(Z, '#title');
    const zc = await create(Z, 'Zed');
    ok(/^[A-Z]{5}$/.test(zc), 'creating and joining parties still works without the list (code ' + zc + ')');
    ok(errors.length === 0, 'no page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  } catch (e) { bad++; console.log('  EXCEPTION:', e.message.split('\n').slice(0, 3).join(' | ')); if (errors.length) console.log('  page errors:', errors.join(' | ')); console.log('  broker log tail:', B.log.slice(-8).join(' ; ')); }
  await browser.close(); await B.close(); server.close();
  console.log(bad ? '\n' + bad + ' PROBLEM(S)' : '\nE2E-4 PASSED');
  process.exit(bad ? 1 : 0);
})();
