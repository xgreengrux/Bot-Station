require('../js/shared.js');
const BS = globalThis.BS, C = BS.C;
let bad = 0; const fail = m => { bad++; console.log('FAIL', m); };

// grid flood fill from the hub ring
const step = 8, key = (x, y) => x + ',' + y;
const seen = new Set(), q = [[BS.RING[0][0] - BS.RING[0][0] % step, BS.RING[0][1] - BS.RING[0][1] % step]];
if (!BS.canStand(q[0][0], q[0][1])) { const s = BS.nearestStand(q[0][0], q[0][1]); q[0] = [Math.round(s[0] / step) * step, Math.round(s[1] / step) * step]; }
seen.add(key(...q[0]));
while (q.length) {
  const [x, y] = q.pop();
  for (const [dx, dy] of [[step, 0], [-step, 0], [0, step], [0, -step]]) {
    const nx = x + dx, ny = y + dy;
    if (!seen.has(key(nx, ny)) && BS.canStand(nx, ny)) { seen.add(key(nx, ny)); q.push([nx, ny]); }
  }
}
const reach = (x, y, r) => { for (let dx = -r; dx <= r; dx += step) for (let dy = -r; dy <= r; dy += step) { const px = Math.round((x + dx) / step) * step, py = Math.round((y + dy) / step) * step; if (seen.has(key(px, py)) && Math.hypot(px - x, py - y) <= r) return true; } return false; };

BS.RING.forEach((p, i) => { if (!BS.canStand(p[0], p[1])) fail('ring spot ' + i + ' blocked ' + p); });
for (const [id, s] of Object.entries(BS.ST)) {
  if (s.room < 0) fail('station not in a room: ' + id);
  if (!reach(s.x, s.y, C.USE_RANGE - 8)) fail('station unreachable: ' + id);
}
BS.VENTS.forEach(v => { if (!BS.canStand(v.x, v.y)) fail('vent blocked ' + v.id); if (!reach(v.x, v.y, C.VENT_RANGE - 10)) fail('vent unreachable ' + v.id); });
BS.ROOMS.forEach(r => { if (!reach(r.x + r.w / 2, r.y + r.h / 2, 90)) fail('room unreachable ' + r.name); });
const tasks = new Set(); BS.TASKS.forEach(t => t.steps.forEach(s => { if (!BS.ST[s.st]) fail('bad station ' + s.st); tasks.add(s.st); }));
['melt_a', 'melt_b', 'lights_panel', 'comms_panel', 'button', 'admin'].forEach(k => { if (!BS.ST[k]) fail('missing ' + k); });
// doors: every room has at least one, closing all of a room's doors isolates it
BS.ROOMS.forEach(r => { if (!BS.ROOM_DOORS[r.id].length) fail('no doors ' + r.name); });
const locked = new Set(BS.ROOM_DOORS[4]);   // lock the Hub
if (BS.canStand(BS.HALLS[0].x + 4, BS.HALLS[0].y + 45, locked) === false) {} 
console.log('walkable cells', seen.size, 'tasks', BS.TASKS.length, 'doors', BS.DOORS.length);
console.log(bad ? bad + ' problem(s)' : 'MAP OK');
process.exit(bad ? 1 : 0);
